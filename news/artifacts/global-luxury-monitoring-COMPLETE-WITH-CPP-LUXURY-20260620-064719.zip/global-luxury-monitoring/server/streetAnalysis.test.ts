import { describe, it, expect } from "vitest";

describe("StreetAnalysis", () => {
  // Mock street data for testing
  const mockStreetData = {
    zurich: {
      bahnhofstrasse: {
        stores: 8,
        brands: 4,
        recentOpenings: 5,
        avgRent: "CHF 3,500/m²",
        vacancy: "2.5%",
        categories: ["New Opening", "Renovation"],
      },
      rennweg: {
        stores: 3,
        brands: 2,
        recentOpenings: 1,
        avgRent: "CHF 2,800/m²",
        vacancy: "3.0%",
        categories: ["New Opening"],
      },
    },
    geneva: {
      "rue-du-rhone": {
        stores: 130,
        brands: 85,
        recentOpenings: 12,
        avgRent: "CHF 3,200/m²",
        vacancy: "3.0%",
        categories: ["New Opening", "Renovation", "Relocation"],
      },
    },
  };

  it("should have correct store counts for Bahnhofstrasse", () => {
    const bahnhofstrasse = mockStreetData.zurich.bahnhofstrasse;
    expect(bahnhofstrasse.stores).toBe(8);
  });

  it("should have correct brand counts for Bahnhofstrasse", () => {
    const bahnhofstrasse = mockStreetData.zurich.bahnhofstrasse;
    expect(bahnhofstrasse.brands).toBe(4);
  });

  it("should have correct recent openings for Bahnhofstrasse", () => {
    const bahnhofstrasse = mockStreetData.zurich.bahnhofstrasse;
    expect(bahnhofstrasse.recentOpenings).toBe(5);
  });

  it("should have valid rent prices for all streets", () => {
    Object.values(mockStreetData).forEach((city) => {
      Object.values(city).forEach((street) => {
        expect(street.avgRent).toMatch(/CHF \d+,\d+\/m²/);
      });
    });
  });

  it("should have valid vacancy percentages for all streets", () => {
    Object.values(mockStreetData).forEach((city) => {
      Object.values(city).forEach((street) => {
        const vacancy = parseFloat(street.vacancy);
        expect(vacancy).toBeGreaterThan(0);
        expect(vacancy).toBeLessThan(10);
      });
    });
  });

  it("should have Rue du Rhône as most expensive street", () => {
    const bahnhofstrasse = 3500;
    const rueRhone = 3200;
    expect(bahnhofstrasse).toBeGreaterThan(rueRhone);
  });

  it("should have correct categories for Bahnhofstrasse", () => {
    const bahnhofstrasse = mockStreetData.zurich.bahnhofstrasse;
    expect(bahnhofstrasse.categories).toContain("New Opening");
    expect(bahnhofstrasse.categories).toContain("Renovation");
  });

  it("should have Rue du Rhône with most stores", () => {
    const rueRhone = mockStreetData.geneva["rue-du-rhone"];
    const bahnhofstrasse = mockStreetData.zurich.bahnhofstrasse;
    expect(rueRhone.stores).toBeGreaterThan(bahnhofstrasse.stores);
  });

  it("should have Rue du Rhône with most brands", () => {
    const rueRhone = mockStreetData.geneva["rue-du-rhone"];
    const bahnhofstrasse = mockStreetData.zurich.bahnhofstrasse;
    expect(rueRhone.brands).toBeGreaterThan(bahnhofstrasse.brands);
  });

  it("should have correct total stores across all streets in Zurich", () => {
    const totalStores = Object.values(mockStreetData.zurich).reduce(
      (sum, street) => sum + street.stores,
      0
    );
    expect(totalStores).toBe(11); // 8 + 3
  });

  it("should have correct total stores across all streets in Geneva", () => {
    const totalStores = Object.values(mockStreetData.geneva).reduce(
      (sum, street) => sum + street.stores,
      0
    );
    expect(totalStores).toBe(130);
  });

  it("should have Rennweg with lowest vacancy in Zurich", () => {
    const bahnhofstrasse = parseFloat(
      mockStreetData.zurich.bahnhofstrasse.vacancy
    );
    const rennweg = parseFloat(mockStreetData.zurich.rennweg.vacancy);
    expect(rennweg).toBeGreaterThan(bahnhofstrasse);
  });

  it("should calculate correct percentage of new openings for Bahnhofstrasse", () => {
    const bahnhofstrasse = mockStreetData.zurich.bahnhofstrasse;
    const percentage = (bahnhofstrasse.recentOpenings / bahnhofstrasse.stores) * 100;
    expect(percentage).toBe(62.5); // 5 / 8 * 100
  });
});
