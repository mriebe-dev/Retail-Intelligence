import crypto from "crypto";
import { getDb } from "./db";
import { luxuryNews, type InsertLuxuryNews } from "../drizzle/schema";
import { eq } from "drizzle-orm";

/**
 * News Collector Service
 * Automatically collects luxury retail news from various sources
 * Prevents duplicates using URL hash
 */

interface NewsItem {
  brandName: string;
  city: string;
  country: string;
  street?: string;
  date: string;
  source: string;
  link: string;
  description: string;
  latitude?: string;
  longitude?: string;
  photoUrl?: string;
}

/**
 * Generate unique hash for URL to prevent duplicates
 */
export function generateUrlHash(url: string): string {
  return crypto.createHash("sha256").update(url).digest("hex");
}

/**
 * Add news to database with duplicate prevention
 */
export async function addNews(newsItem: NewsItem): Promise<boolean> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[News Collector] Database not available");
      return false;
    }

    const urlHash = generateUrlHash(newsItem.link);

    // Check if news already exists
    const existing = await db
      .select()
      .from(luxuryNews)
      .where(eq(luxuryNews.urlHash, urlHash))
      .limit(1);

    if (existing.length > 0) {
      console.log(`[News Collector] Duplicate news skipped: ${newsItem.link}`);
      return false;
    }

    // Insert new news
    const newsData: InsertLuxuryNews = {
      urlHash,
      brandName: newsItem.brandName,
      city: newsItem.city,
      country: newsItem.country,
      street: newsItem.street,
      date: newsItem.date,
      source: newsItem.source,
      link: newsItem.link,
      description: newsItem.description,
      latitude: newsItem.latitude,
      longitude: newsItem.longitude,
      photoUrl: newsItem.photoUrl,
      status: "new",
    };

    await db.insert(luxuryNews).values(newsData);
    console.log(
      `[News Collector] New news added: ${newsItem.brandName} at ${newsItem.city}`
    );
    return true;
  } catch (error) {
    console.error("[News Collector] Error adding news:", error);
    return false;
  }
}

/**
 * Get all news with optional filters
 */
export async function getNews(filters?: {
  city?: string;
  country?: string;
  brand?: string;
  status?: "new" | "archived" | "featured";
  startDate?: string;
  endDate?: string;
}) {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[News Collector] Database not available");
      return [];
    }

    let query = db.select().from(luxuryNews);

    // Apply filters
    if (filters?.city) {
      query = query.where(eq(luxuryNews.city, filters.city)) as any;
    }
    if (filters?.country) {
      query = query.where(eq(luxuryNews.country, filters.country)) as any;
    }
    if (filters?.brand) {
      query = query.where(eq(luxuryNews.brandName, filters.brand)) as any;
    }
    if (filters?.status) {
      query = query.where(eq(luxuryNews.status, filters.status)) as any;
    }

    // Return all news ordered by date descending
    const result = await query;
    return result;
  } catch (error) {
    console.error("[News Collector] Error fetching news:", error);
    return [];
  }
}

/**
 * Archive old news (older than 90 days)
 */
export async function archiveOldNews(): Promise<number> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[News Collector] Database not available");
      return 0;
    }

    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);

    console.log(`[News Collector] Archiving news older than ${ninetyDaysAgo}`);
    return 0;
  } catch (error) {
    console.error("[News Collector] Error archiving news:", error);
    return 0;
  }
}

/**
 * Remove duplicate news entries
 */
export async function removeDuplicates(): Promise<number> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[News Collector] Database not available");
      return 0;
    }

    const allNews = await getNews();

    // Group by URL hash and keep only the first entry
    const seen = new Set<string>();
    let duplicatesRemoved = 0;
    const idsToDelete: number[] = [];

    for (const news of allNews) {
      if (seen.has(news.urlHash)) {
        // Mark duplicate for deletion
        idsToDelete.push(news.id);
        duplicatesRemoved++;
      } else {
        seen.add(news.urlHash);
      }
    }

    // Delete duplicates
    for (const id of idsToDelete) {
      await db.delete(luxuryNews).where(eq(luxuryNews.id, id));
    }

    console.log(`[News Collector] Removed ${duplicatesRemoved} duplicates`);
    return duplicatesRemoved;
  } catch (error) {
    console.error("[News Collector] Error removing duplicates:", error);
    return 0;
  }
}

/**
 * Example: Collect news from LinkedIn
 * This is a placeholder for actual LinkedIn scraping
 */
export async function collectFromLinkedIn(): Promise<number> {
  console.log("[News Collector] Starting LinkedIn collection...");

  // Example news items
  const exampleNews: NewsItem[] = [
    {
      brandName: "J.Lindeberg",
      city: "Stockholm",
      country: "Sweden",
      street: "Stureplan",
      date: new Date().toISOString().split("T")[0],
      source: "LinkedIn",
      link: "https://www.linkedin.com/posts/retail-journal_retail-jlindeberg-sweden-activity-7428120789176070146",
      description:
        "J.Lindeberg opens new flagship store in Stockholm's premium shopping district Stureplan",
      latitude: "59.3365",
      longitude: "18.0822",
    },
  ];

  let addedCount = 0;
  for (const news of exampleNews) {
    if (await addNews(news)) {
      addedCount++;
    }
  }

  console.log(
    `[News Collector] LinkedIn collection complete: ${addedCount} new items`
  );
  return addedCount;
}

/**
 * Example: Collect news from Retail Journal
 */
export async function collectFromRetailJournal(): Promise<number> {
  console.log("[News Collector] Starting Retail Journal collection...");
  // TODO: Implement actual scraping
  return 0;
}

/**
 * Example: Collect news from WWD
 */
export async function collectFromWWD(): Promise<number> {
  console.log("[News Collector] Starting WWD collection...");
  // TODO: Implement actual scraping
  return 0;
}

/**
 * Run all collectors
 */
export async function runAllCollectors(): Promise<{
  linkedin: number;
  retailJournal: number;
  wwd: number;
  total: number;
}> {
  console.log("[News Collector] Starting all collectors...");

  const linkedin = await collectFromLinkedIn();
  const retailJournal = await collectFromRetailJournal();
  const wwd = await collectFromWWD();

  const total = linkedin + retailJournal + wwd;

  console.log(
    `[News Collector] All collectors complete: ${total} new items total`
  );

  return {
    linkedin,
    retailJournal,
    wwd,
    total,
  };
}
