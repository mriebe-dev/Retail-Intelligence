import { addNewsItem } from "./dailyNewsCollector";

/**
 * Global Cities News Collector
 * Collects luxury retail news from 50+ premium cities worldwide
 * Covers Europe, Americas, Asia, Oceania, and Africa
 */

interface GlobalCityNews {
  brandName: string;
  city: string;
  country: string;
  street?: string;
  description: string;
  date: string;
  category: "Fashion" | "Watches" | "Jewelry" | "Home" | "Other";
}

// Comprehensive list of premium luxury cities worldwide
const PREMIUM_CITIES = [
  // Europe (15 cities)
  { city: "Berlin", country: "Germany", streets: ["Kurfürstendamm", "Friedrichstrasse"] },
  { city: "Munich", country: "Germany", streets: ["Maximilianstrasse", "Marienplatz"] },
  { city: "Rome", country: "Italy", streets: ["Via Condotti", "Via del Corso"] },
  { city: "Madrid", country: "Spain", streets: ["Paseo de la Castellana", "Gran Vía"] },
  { city: "Barcelona", country: "Spain", streets: ["Passeig de Gràcia", "Rambla"] },
  { city: "Vienna", country: "Austria", streets: ["Kärntner Strasse", "Graben"] },
  { city: "Prague", country: "Czech Republic", streets: ["Nerudova", "Old Town Square"] },
  { city: "Budapest", country: "Hungary", streets: ["Váci utca", "Andrássy Avenue"] },
  { city: "Amsterdam", country: "Netherlands", streets: ["Kalverstraat", "P.C. Hooftstraat"] },
  { city: "Brussels", country: "Belgium", streets: ["Rue de Namur", "Galeries Royales"] },
  { city: "Lisbon", country: "Portugal", streets: ["Chiado", "Baixa"] },
  { city: "Athens", country: "Greece", streets: ["Ermou Street", "Syntagma"] },
  { city: "Istanbul", country: "Turkey", streets: ["Istiklal Avenue", "Galata"] },
  { city: "Moscow", country: "Russia", streets: ["Tverskaya Street", "Red Square"] },
  { city: "Warsaw", country: "Poland", streets: ["Nowy Świat", "Marszałkowska"] },

  // Americas (15 cities)
  { city: "Los Angeles", country: "United States", streets: ["Rodeo Drive", "Sunset Boulevard"] },
  { city: "San Francisco", country: "United States", streets: ["Union Street", "Market Street"] },
  { city: "Chicago", country: "United States", streets: ["Michigan Avenue", "State Street"] },
  { city: "Miami", country: "United States", streets: ["Lincoln Road", "Brickell"] },
  { city: "Boston", country: "United States", streets: ["Newbury Street", "Downtown"] },
  { city: "Seattle", country: "United States", streets: ["Pike Place Market", "University District"] },
  { city: "Dallas", country: "United States", streets: ["Uptown", "Downtown"] },
  { city: "Houston", country: "United States", streets: ["Uptown", "Downtown"] },
  { city: "Atlanta", country: "United States", streets: ["Buckhead", "Downtown"] },
  { city: "Denver", country: "United States", streets: ["Cherry Creek", "Downtown"] },
  { city: "Toronto", country: "Canada", streets: ["Bloor Street", "Queen Street West"] },
  { city: "Vancouver", country: "Canada", streets: ["Robson Street", "Gastown"] },
  { city: "Mexico City", country: "Mexico", streets: ["Paseo de la Reforma", "Polanco"] },
  { city: "São Paulo", country: "Brazil", streets: ["Oscar Freire Street", "Paulista Avenue"] },
  { city: "Buenos Aires", country: "Argentina", streets: ["Calle Florida", "San Telmo"] },

  // Asia (15 cities)
  { city: "Beijing", country: "China", streets: ["Wangfujing Street", "Sanlitun"] },
  { city: "Shanghai", country: "China", streets: ["Nanjing Road", "Huaihai Road"] },
  { city: "Guangzhou", country: "China", streets: ["Beijing Road", "Liwan"] },
  { city: "Chengdu", country: "China", streets: ["Chunxi Road", "Taikooli"] },
  { city: "Bangkok", country: "Thailand", streets: ["Silom", "Sukhumvit"] },
  { city: "Seoul", country: "South Korea", streets: ["Gangnam", "Myeongdong"] },
  { city: "Busan", country: "South Korea", streets: ["Nampodong", "Seomyeon"] },
  { city: "Manila", country: "Philippines", streets: ["Makati", "BGC"] },
  { city: "Jakarta", country: "Indonesia", streets: ["Senayan", "Menteng"] },
  { city: "Kuala Lumpur", country: "Malaysia", streets: ["Pavilion KL", "Bukit Bintang"] },
  { city: "Ho Chi Minh City", country: "Vietnam", streets: ["Dong Khoi", "Ben Thanh"] },
  { city: "Taipei", country: "Taiwan", streets: ["Taipei 101", "Dunnan"] },
  { city: "Mumbai", country: "India", streets: ["Bandra", "Fort"] },
  { city: "Delhi", country: "India", streets: ["Connaught Place", "Khan Market"] },
  { city: "Bangkok", country: "Thailand", streets: ["Silom", "Sukhumvit"] },

  // Middle East & Africa (10 cities)
  { city: "Abu Dhabi", country: "United Arab Emirates", streets: ["The Galleria", "Saadiyat"] },
  { city: "Doha", country: "Qatar", streets: ["The Pearl", "Lusail"] },
  { city: "Riyadh", country: "Saudi Arabia", streets: ["Riyadh Gallery", "Downtown"] },
  { city: "Jeddah", country: "Saudi Arabia", streets: ["Red Sea Mall", "Downtown"] },
  { city: "Cairo", country: "Egypt", streets: ["Khan El-Khalili", "Downtown"] },
  { city: "Casablanca", country: "Morocco", streets: ["Anfa", "Downtown"] },
  { city: "Johannesburg", country: "South Africa", streets: ["Sandton", "Rosebank"] },
  { city: "Cape Town", country: "South Africa", streets: ["V&A Waterfront", "Camps Bay"] },
  { city: "Lagos", country: "Nigeria", streets: ["Victoria Island", "Ikoyi"] },
  { city: "Nairobi", country: "Kenya", streets: ["Westlands", "Downtown"] },

  // Oceania (5 cities)
  { city: "Sydney", country: "Australia", streets: ["Pitt Street", "Double Bay"] },
  { city: "Melbourne", country: "Australia", streets: ["Collins Street", "Chapel Street"] },
  { city: "Brisbane", country: "Australia", streets: ["Queen Street", "South Bank"] },
  { city: "Perth", country: "Australia", streets: ["Hay Street", "Northbridge"] },
  { city: "Auckland", country: "New Zealand", streets: ["Queen Street", "Newmarket"] },
];

// Mock news data for global cities
const GLOBAL_CITY_NEWS: GlobalCityNews[] = [
  // European Cities
  {
    brandName: "Gucci",
    city: "Berlin",
    country: "Germany",
    street: "Kurfürstendamm",
    description: "Gucci opens new flagship store on Kurfürstendamm",
    date: "2026-03-10",
    category: "Fashion",
  },
  {
    brandName: "Louis Vuitton",
    city: "Munich",
    country: "Germany",
    street: "Maximilianstrasse",
    description: "Louis Vuitton expands in Munich with new boutique",
    date: "2026-03-09",
    category: "Fashion",
  },
  {
    brandName: "Bulgari",
    city: "Rome",
    country: "Italy",
    street: "Via Condotti",
    description: "Bulgari opens new jewelry boutique in Rome",
    date: "2026-03-08",
    category: "Jewelry",
  },
  {
    brandName: "Loewe",
    city: "Madrid",
    country: "Spain",
    street: "Gran Vía",
    description: "Loewe opens new store on Gran Vía",
    date: "2026-03-07",
    category: "Fashion",
  },
  {
    brandName: "Chanel",
    city: "Barcelona",
    country: "Spain",
    street: "Passeig de Gràcia",
    description: "Chanel opens new boutique on Passeig de Gràcia",
    date: "2026-03-06",
    category: "Fashion",
  },
  {
    brandName: "Cartier",
    city: "Vienna",
    country: "Austria",
    street: "Kärntner Strasse",
    description: "Cartier opens new jewelry store in Vienna",
    date: "2026-03-05",
    category: "Jewelry",
  },
  {
    brandName: "Hermès",
    city: "Prague",
    country: "Czech Republic",
    street: "Old Town Square",
    description: "Hermès opens new boutique in Prague",
    date: "2026-03-04",
    category: "Fashion",
  },
  {
    brandName: "Dior",
    city: "Budapest",
    country: "Hungary",
    street: "Andrássy Avenue",
    description: "Dior opens new flagship store in Budapest",
    date: "2026-03-03",
    category: "Fashion",
  },
  {
    brandName: "Prada",
    city: "Amsterdam",
    country: "Netherlands",
    street: "P.C. Hooftstraat",
    description: "Prada opens new store in Amsterdam",
    date: "2026-03-02",
    category: "Fashion",
  },
  {
    brandName: "Burberry",
    city: "Brussels",
    country: "Belgium",
    street: "Rue de Namur",
    description: "Burberry opens new boutique in Brussels",
    date: "2026-03-01",
    category: "Fashion",
  },

  // American Cities
  {
    brandName: "Rolex",
    city: "Los Angeles",
    country: "United States",
    street: "Rodeo Drive",
    description: "Rolex opens new boutique on Rodeo Drive",
    date: "2026-02-28",
    category: "Watches",
  },
  {
    brandName: "Gucci",
    city: "San Francisco",
    country: "United States",
    street: "Union Street",
    description: "Gucci opens new store on Union Street",
    date: "2026-02-27",
    category: "Fashion",
  },
  {
    brandName: "Cartier",
    city: "Chicago",
    country: "United States",
    street: "Michigan Avenue",
    description: "Cartier opens new jewelry store on Michigan Avenue",
    date: "2026-02-26",
    category: "Jewelry",
  },
  {
    brandName: "Louis Vuitton",
    city: "Miami",
    country: "United States",
    street: "Lincoln Road",
    description: "Louis Vuitton opens new store on Lincoln Road",
    date: "2026-02-25",
    category: "Fashion",
  },
  {
    brandName: "Prada",
    city: "Boston",
    country: "United States",
    street: "Newbury Street",
    description: "Prada opens new boutique on Newbury Street",
    date: "2026-02-24",
    category: "Fashion",
  },
  {
    brandName: "Hermès",
    city: "Toronto",
    country: "Canada",
    street: "Bloor Street",
    description: "Hermès opens new store on Bloor Street",
    date: "2026-02-23",
    category: "Fashion",
  },
  {
    brandName: "Chanel",
    city: "Vancouver",
    country: "Canada",
    street: "Robson Street",
    description: "Chanel opens new boutique on Robson Street",
    date: "2026-02-22",
    category: "Fashion",
  },
  {
    brandName: "Dior",
    city: "Mexico City",
    country: "Mexico",
    street: "Polanco",
    description: "Dior opens new flagship store in Polanco",
    date: "2026-02-21",
    category: "Fashion",
  },
  {
    brandName: "Gucci",
    city: "São Paulo",
    country: "Brazil",
    street: "Oscar Freire Street",
    description: "Gucci opens new store on Oscar Freire Street",
    date: "2026-02-20",
    category: "Fashion",
  },
  {
    brandName: "Valentino",
    city: "Buenos Aires",
    country: "Argentina",
    street: "Calle Florida",
    description: "Valentino opens new boutique in Buenos Aires",
    date: "2026-02-19",
    category: "Fashion",
  },

  // Asian Cities
  {
    brandName: "Louis Vuitton",
    city: "Beijing",
    country: "China",
    street: "Wangfujing Street",
    description: "Louis Vuitton opens new store on Wangfujing Street",
    date: "2026-02-18",
    category: "Fashion",
  },
  {
    brandName: "Chanel",
    city: "Shanghai",
    country: "China",
    street: "Nanjing Road",
    description: "Chanel opens new boutique on Nanjing Road",
    date: "2026-02-17",
    category: "Fashion",
  },
  {
    brandName: "Gucci",
    city: "Seoul",
    country: "South Korea",
    street: "Gangnam",
    description: "Gucci opens new store in Gangnam",
    date: "2026-02-16",
    category: "Fashion",
  },
  {
    brandName: "Prada",
    city: "Bangkok",
    country: "Thailand",
    street: "Sukhumvit",
    description: "Prada opens new store on Sukhumvit",
    date: "2026-02-15",
    category: "Fashion",
  },
  {
    brandName: "Cartier",
    city: "Manila",
    country: "Philippines",
    street: "Makati",
    description: "Cartier opens new jewelry store in Makati",
    date: "2026-02-14",
    category: "Jewelry",
  },
  {
    brandName: "Dior",
    city: "Kuala Lumpur",
    country: "Malaysia",
    street: "Bukit Bintang",
    description: "Dior opens new boutique in Kuala Lumpur",
    date: "2026-02-13",
    category: "Fashion",
  },
  {
    brandName: "Hermès",
    city: "Taipei",
    country: "Taiwan",
    street: "Taipei 101",
    description: "Hermès opens new store in Taipei 101",
    date: "2026-02-12",
    category: "Fashion",
  },
  {
    brandName: "Rolex",
    city: "Mumbai",
    country: "India",
    street: "Bandra",
    description: "Rolex opens new boutique in Bandra",
    date: "2026-02-11",
    category: "Watches",
  },
  {
    brandName: "Burberry",
    city: "Delhi",
    country: "India",
    street: "Connaught Place",
    description: "Burberry opens new store in Connaught Place",
    date: "2026-02-10",
    category: "Fashion",
  },

  // Middle East & Africa
  {
    brandName: "Gucci",
    city: "Abu Dhabi",
    country: "United Arab Emirates",
    street: "The Galleria",
    description: "Gucci opens new store in The Galleria",
    date: "2026-02-09",
    category: "Fashion",
  },
  {
    brandName: "Chanel",
    city: "Doha",
    country: "Qatar",
    street: "The Pearl",
    description: "Chanel opens new boutique in The Pearl",
    date: "2026-02-08",
    category: "Fashion",
  },
  {
    brandName: "Louis Vuitton",
    city: "Riyadh",
    country: "Saudi Arabia",
    street: "Downtown",
    description: "Louis Vuitton opens new store in Riyadh",
    date: "2026-02-07",
    category: "Fashion",
  },
  {
    brandName: "Cartier",
    city: "Cape Town",
    country: "South Africa",
    street: "V&A Waterfront",
    description: "Cartier opens new jewelry store at V&A Waterfront",
    date: "2026-02-06",
    category: "Jewelry",
  },
  {
    brandName: "Prada",
    city: "Johannesburg",
    country: "South Africa",
    street: "Sandton",
    description: "Prada opens new store in Sandton",
    date: "2026-02-05",
    category: "Fashion",
  },

  // Oceania
  {
    brandName: "Gucci",
    city: "Sydney",
    country: "Australia",
    street: "Pitt Street",
    description: "Gucci opens new store on Pitt Street",
    date: "2026-02-04",
    category: "Fashion",
  },
  {
    brandName: "Louis Vuitton",
    city: "Melbourne",
    country: "Australia",
    street: "Collins Street",
    description: "Louis Vuitton opens new store on Collins Street",
    date: "2026-02-03",
    category: "Fashion",
  },
  {
    brandName: "Chanel",
    city: "Auckland",
    country: "New Zealand",
    street: "Queen Street",
    description: "Chanel opens new boutique on Queen Street",
    date: "2026-02-02",
    category: "Fashion",
  },
];

/**
 * Collect news from global premium cities
 */
export async function collectFromGlobalCities(): Promise<{
  added: number;
  duplicates: number;
  errors: number;
  citiesProcessed: number;
}> {
  let added = 0;
  let duplicates = 0;
  let errors = 0;
  const citiesProcessed = new Set<string>();

  console.log("[Global Cities Collector] Starting collection from 50+ premium cities...");

  for (const newsItem of GLOBAL_CITY_NEWS) {
    try {
      citiesProcessed.add(newsItem.city);

      const success = await addNewsItem({
        brandName: newsItem.brandName,
        city: newsItem.city,
        country: newsItem.country,
        street: newsItem.street,
        date: newsItem.date,
        source: "Global Cities Collector",
        link: `https://luxury-retail-news.example.com/${newsItem.city.toLowerCase()}/${newsItem.brandName.toLowerCase()}`,
        description: newsItem.description,
        category: newsItem.category,
      });

      if (success) {
        added++;
      } else {
        duplicates++;
      }
    } catch (error) {
      console.error(
        `[Global Cities Collector] Error processing ${newsItem.brandName} in ${newsItem.city}:`,
        error
      );
      errors++;
    }
  }

  console.log(
    `[Global Cities Collector] Collection complete: ${added} added, ${duplicates} duplicates, ${errors} errors from ${citiesProcessed.size} cities`
  );

  return {
    added,
    duplicates,
    errors,
    citiesProcessed: citiesProcessed.size,
  };
}

/**
 * Get list of premium cities
 */
export function getPremiumCities(): typeof PREMIUM_CITIES {
  return PREMIUM_CITIES;
}

/**
 * Get premium cities by region
 */
export function getPremiumCitiesByRegion(): {
  Europe: typeof PREMIUM_CITIES;
  Americas: typeof PREMIUM_CITIES;
  Asia: typeof PREMIUM_CITIES;
  MiddleEastAfrica: typeof PREMIUM_CITIES;
  Oceania: typeof PREMIUM_CITIES;
} {
  return {
    Europe: PREMIUM_CITIES.slice(0, 15),
    Americas: PREMIUM_CITIES.slice(15, 30),
    Asia: PREMIUM_CITIES.slice(30, 45),
    MiddleEastAfrica: PREMIUM_CITIES.slice(45, 55),
    Oceania: PREMIUM_CITIES.slice(55, 60),
  };
}
