import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, luxuryStores, InsertLuxuryStore, luxuryNews, InsertLuxuryNews } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get all luxury stores with optional filters
 */
export async function getLuxuryStores(filters?: {
  city?: string;
  country?: string;
  brandName?: string;
  newsType?: string;
  sourceName?: string;
  dateFrom?: string;
  dateTo?: string;
}) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get luxury stores: database not available");
    return [];
  }

  let query = db.select().from(luxuryStores);

  if (filters?.city) {
    query = query.where(eq(luxuryStores.city, filters.city)) as any;
  }
  if (filters?.country) {
    query = query.where(eq(luxuryStores.country, filters.country)) as any;
  }
  if (filters?.brandName) {
    query = query.where(eq(luxuryStores.brandName, filters.brandName)) as any;
  }
  if (filters?.newsType) {
    query = query.where(eq(luxuryStores.newsType, filters.newsType)) as any;
  }
  if (filters?.sourceName) {
    query = query.where(eq(luxuryStores.sourceName, filters.sourceName)) as any;
  }

  const result = await query;
  return result;
}

/**
 * Get a single luxury store by ID
 */
export async function getLuxuryStoreById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get luxury store: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(luxuryStores)
    .where(eq(luxuryStores.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get unique cities
 */
export async function getUniqueCities(country?: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get cities: database not available");
    return [];
  }

  let query = db.selectDistinct({ city: luxuryStores.city }).from(luxuryStores);

  if (country) {
    const filtered = await query.where(eq(luxuryStores.country, country));
    return filtered.map((r) => r.city);
  }

  const result = await query;
  return result.map((r) => r.city);
}

/**
 * Get unique brands
 */
export async function getUniqueBrands() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get brands: database not available");
    return [];
  }

  const result = await db
    .selectDistinct({ brandName: luxuryStores.brandName })
    .from(luxuryStores);

  return result.map((r) => r.brandName);
}

/**
 * Insert a new luxury store
 */
export async function insertLuxuryStore(store: InsertLuxuryStore) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot insert luxury store: database not available");
    return undefined;
  }

  try {
    const result = await db.insert(luxuryStores).values(store);
    return result;
  } catch (error) {
    console.error("[Database] Failed to insert luxury store:", error);
    throw error;
  }
}

/**
 * Update a luxury store
 */
export async function updateLuxuryStore(
  id: number,
  updates: Partial<InsertLuxuryStore>
) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update luxury store: database not available");
    return undefined;
  }

  try {
    const result = await db
      .update(luxuryStores)
      .set(updates)
      .where(eq(luxuryStores.id, id));
    return result;
  } catch (error) {
    console.error("[Database] Failed to update luxury store:", error);
    throw error;
  }
}

/**
 * Delete a luxury store
 */
export async function deleteLuxuryStore(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete luxury store: database not available");
    return undefined;
  }

  try {
    const result = await db
      .delete(luxuryStores)
      .where(eq(luxuryStores.id, id));
    return result;
  } catch (error) {
    console.error("[Database] Failed to delete luxury store:", error);
    throw error;
  }
}

/**
 * Get all luxury news with optional filters
 */
export async function getLuxuryNews(filters?: {
  city?: string;
  country?: string;
  brand?: string;
  status?: "new" | "archived" | "featured";
}) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get luxury news: database not available");
    return [];
  }

  let query = db.select().from(luxuryNews);

  if (filters?.city) {
    query = query.where(eq(luxuryNews.city, filters.city)) as any;
  }
  if (filters?.country) {
    query = query.where(eq(luxuryNews.country, filters.country)) as any;
  }
  if (filters?.brand) {
    query = query.where(eq(luxuryNews.brandName, filters.brand)) as any;
  }
  if (filters?.status) {
    query = query.where(eq(luxuryNews.status, filters.status)) as any;
  }

  const result = await query;
  return result;
}

/**
 * Insert a new luxury news
 */
export async function insertLuxuryNews(news: InsertLuxuryNews) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot insert luxury news: database not available");
    return undefined;
  }

  try {
    const result = await db.insert(luxuryNews).values(news);
    return result;
  } catch (error) {
    console.error("[Database] Failed to insert luxury news:", error);
    throw error;
  }
}

/**
 * Migrate all luxury stores to luxury news archive
 */
export async function migrateStoresToNews() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot migrate: database not available");
    return { success: false, migrated: 0, skipped: 0, errors: 0 };
  }

  try {
    const crypto = await import("crypto");
    
    // Get all stores
    const stores = await db.select().from(luxuryStores);
    console.log(`[Migration] Found ${stores.length} stores to migrate`);

    let migratedCount = 0;
    let skippedCount = 0;
    let errorCount = 0;

    // Migrate each store to news
    for (const store of stores) {
      try {
        // Generate URL hash from source URL or create unique hash
        const urlHash = crypto.default
          .createHash("sha256")
          .update(store.sourceUrl || `store-${store.id}`)
          .digest("hex");

        // Check if news already exists
        const existing = await db
          .select()
          .from(luxuryNews)
          .where(eq(luxuryNews.urlHash, urlHash))
          .limit(1);

        if (existing.length > 0) {
          skippedCount++;
          continue;
        }

        // Insert into luxury_news
        const newsData: InsertLuxuryNews = {
          urlHash,
          brandName: store.brandName,
          city: store.city,
          country: store.country,
          street: store.locationAddress || undefined,
          date: store.date,
          source: store.sourceName || "Import",
          link: store.sourceUrl || "",
          description: store.summary || `${store.brandName} - ${store.newsType}`,
          latitude: store.latitude || undefined,
          longitude: store.longitude || undefined,
          photoUrl: store.imageUrl || undefined,
          status: "archived",
        };

        await db.insert(luxuryNews).values(newsData);
        migratedCount++;
      } catch (error) {
        console.error(`[Migration] Error migrating store ${store.id}:`, error);
        errorCount++;
      }
    }

    console.log(`[Migration] Complete: migrated=${migratedCount}, skipped=${skippedCount}, errors=${errorCount}`);
    return { success: true, migrated: migratedCount, skipped: skippedCount, errors: errorCount };
  } catch (error) {
    console.error("[Database] Migration error:", error);
    return { success: false, migrated: 0, skipped: 0, errors: 1 };
  }
}

// TODO: add feature queries here as your schema grows.

/**
 * Get news aggregated by city and street
 */
export async function getNewsByCity(city: string, country?: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get news by city: database not available");
    return { city, country, totalNews: 0, byStreet: [] };
  }

  try {
    const conditions = [eq(luxuryNews.city, city)];
    if (country) {
      conditions.push(eq(luxuryNews.country, country));
    }

    const news = await db.select().from(luxuryNews).where(and(...conditions));
    
    // Group by street
    const byStreet: Record<string, { street: string; count: number; brands: string[] }> = {};
    
    news.forEach(item => {
      const street = item.street || "Unknown Street";
      if (!byStreet[street]) {
        byStreet[street] = { street, count: 0, brands: [] };
      }
      byStreet[street].count++;
      if (item.brandName && !byStreet[street].brands.includes(item.brandName)) {
        byStreet[street].brands.push(item.brandName);
      }
    });

    return {
      city,
      country: country || "Unknown",
      totalNews: news.length,
      byStreet: Object.values(byStreet).sort((a, b) => b.count - a.count),
    };
  } catch (error) {
    console.error("[Database] Failed to get news by city:", error);
    return { city, country, totalNews: 0, byStreet: [] };
  }
}

/**
 * Get news statistics for all countries and cities
 */
export async function getNewsStatistics() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get news statistics: database not available");
    return { countries: {}, totalNews: 0 };
  }

  try {
    const news = await db.select().from(luxuryNews);
    
    const stats: Record<string, Record<string, { count: number; streets: number }>> = {};
    let totalNews = 0;

    news.forEach(item => {
      const country = item.country || "Unknown";
      const city = item.city || "Unknown";
      const street = item.street || "Unknown";

      if (!stats[country]) {
        stats[country] = {};
      }
      if (!stats[country][city]) {
        stats[country][city] = { count: 0, streets: new Set() as any };
      }

      stats[country][city].count++;
      (stats[country][city].streets as any).add(street);
      totalNews++;
    });

    // Convert Sets to counts
    const result: Record<string, Record<string, { count: number; streets: number }>> = {};
    Object.keys(stats).forEach(country => {
      result[country] = {};
      Object.keys(stats[country]).forEach(city => {
        result[country][city] = {
          count: stats[country][city].count,
          streets: (stats[country][city].streets as any).size,
        };
      });
    });

    return { countries: result, totalNews };
  } catch (error) {
    console.error("[Database] Failed to get news statistics:", error);
    return { countries: {}, totalNews: 0 };
  }
}

/**
 * Get top streets by news count in a city
 */
export async function getTopStreetsByCity(city: string, limit: number = 10) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get top streets: database not available");
    return [];
  }

  try {
    const news = await db.select().from(luxuryNews).where(eq(luxuryNews.city, city)) as any;
    
    const streetCounts: Record<string, { street: string; count: number; brands: Set<string> }> = {};
    
    news.forEach((item: any) => {
      const street = item.street || "Unknown Street";
      if (!streetCounts[street]) {
        streetCounts[street] = { street, count: 0, brands: new Set() };
      }
      streetCounts[street].count++;
      if (item.brandName) {
        streetCounts[street].brands.add(item.brandName);
      }
    });

    return Object.values(streetCounts)
      .map(s => ({ street: s.street, count: s.count, brands: Array.from(s.brands) }))
      .sort((a, b) => b.count - a.count)
      .slice(0, limit);
  } catch (error) {
    console.error("[Database] Failed to get top streets:", error);
    return [];
  }
}
