import { getDb } from "./db";
import { STREET_GEOMETRY, StreetCoordinates } from "./streetGeometry";
import { luxuryNews } from "../drizzle/schema";
import { inArray } from "drizzle-orm";

export interface MarkerPosition {
  newsId: string;
  lat: number;
  lng: number;
  offset: number; // Distance along the street line (0-1)
  streetName: string;
  city: string;
  brand: string;
  title: string;
  date: Date;
}

export interface StreetMarkerCluster {
  streetName: string;
  city: string;
  startLat: number;
  startLng: number;
  endLat: number;
  endLng: number;
  markers: MarkerPosition[];
  totalCount: number;
}

/**
 * Calculate linear position along a street line
 * Returns offset (0-1) where 0 is start and 1 is end
 */
export function calculateLinearOffset(
  lat: number,
  lng: number,
  startLat: number,
  startLng: number,
  endLat: number,
  endLng: number
): number {
  // Calculate distances
  const totalDistance = haversineDistance(startLat, startLng, endLat, endLng);
  const pointDistance = haversineDistance(startLat, startLng, lat, lng);

  // Clamp to 0-1 range
  const offset = Math.max(0, Math.min(1, pointDistance / totalDistance));
  return offset;
}

/**
 * Haversine formula to calculate distance between two points
 * Returns distance in kilometers
 */
export function haversineDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Arrange markers linearly along a street
 * Spreads markers evenly or clusters them based on density
 */
export function arrangeMarkersOnStreet(
  markers: Array<{ lat: number; lng: number; newsId: string; brand: string; title: string; date: Date }>,
  startLat: number,
  startLng: number,
  endLat: number,
  endLng: number,
  streetName: string,
  city: string
): MarkerPosition[] {
  // Calculate linear offsets for each marker
  const markerOffsets = markers.map((marker) => ({
    ...marker,
    offset: calculateLinearOffset(
      marker.lat,
      marker.lng,
      startLat,
      startLng,
      endLat,
      endLng
    ),
  }));

  // Sort by offset (position along street)
  markerOffsets.sort((a, b) => a.offset - b.offset);

  // Apply spacing to avoid overlaps
  const spacedMarkers = applyMarkerSpacing(markerOffsets, 0.02); // 2% minimum spacing

  // Convert back to coordinates
  const arrangedMarkers: MarkerPosition[] = spacedMarkers.map((marker) => ({
    newsId: marker.newsId,
    lat: interpolateCoordinate(
      startLat,
      endLat,
      marker.offset
    ),
    lng: interpolateCoordinate(
      startLng,
      endLng,
      marker.offset
    ),
    offset: marker.offset,
    streetName,
    city,
    brand: marker.brand,
    title: marker.title,
    date: marker.date,
  }));

  return arrangedMarkers;
}

/**
 * Apply minimum spacing between markers to prevent overlaps
 */
export function applyMarkerSpacing(
  markers: Array<any & { offset: number }>,
  minSpacing: number
): Array<any & { offset: number }> {
  if (markers.length === 0) return [];
  if (markers.length === 1) return markers;

  const result = [markers[0]];

  for (let i = 1; i < markers.length; i++) {
    const currentMarker = markers[i];
    const lastMarker = result[result.length - 1];

    // If too close, adjust offset slightly
    if (currentMarker.offset - lastMarker.offset < minSpacing) {
      currentMarker.offset = lastMarker.offset + minSpacing;
    }

    // Clamp to valid range
    if (currentMarker.offset > 1) {
      currentMarker.offset = 1;
    }

    result.push(currentMarker);
  }

  return result;
}

/**
 * Interpolate coordinate between two points
 */
export function interpolateCoordinate(
  start: number,
  end: number,
  offset: number
): number {
  return start + (end - start) * offset;
}

/**
 * Cluster markers by street and arrange them
 */
export async function clusterAndArrangeMarkers(
  newsIds: string[]
): Promise<StreetMarkerCluster[]> {
  const dbInstance = await getDb();
  if (!dbInstance) return [];
  
  if (newsIds.length === 0) return [];
  
  const newsItems = await dbInstance
    .select()
    .from(luxuryNews)
    .where(inArray(luxuryNews.id, newsIds.map(id => parseInt(id))))
    .execute();

  // Group by street
  const streetGroups: Record<string, typeof newsItems> = {};

  for (const news of newsItems) {
    if (!news.latitude || !news.longitude) continue;

    // Extract street name from address
    const streetName = news.street || extractStreetName(news.description || "");
    const key = `${news.city}|${streetName}`;

    if (!streetGroups[key]) {
      streetGroups[key] = [];
    }
    streetGroups[key].push(news);
  }

  // Arrange markers for each street
  const clusters: StreetMarkerCluster[] = [];

  for (const [key, newsGroup] of Object.entries(streetGroups)) {
    const [city, streetName] = key.split("|");

    // Get street geometry
    const street = STREET_GEOMETRY.find(
      (s: StreetCoordinates) => s.city === city && s.streetName === streetName
    );

    if (!street) continue;

    // Arrange markers on this street
    const arrangedMarkers = arrangeMarkersOnStreet(
      newsGroup.map((n: any) => ({
        lat: parseFloat(n.latitude || "0"),
        lng: parseFloat(n.longitude || "0"),
        newsId: n.id.toString(),
        brand: n.brandName,
        title: n.description,
        date: new Date(n.date),
      })),
      street.startLat,
      street.startLng,
      street.endLat,
      street.endLng,
      streetName,
      city
    );

    clusters.push({
      streetName,
      city,
      startLat: street.startLat,
      startLng: street.startLng,
      endLat: street.endLat,
      endLng: street.endLng,
      markers: arrangedMarkers,
      totalCount: arrangedMarkers.length,
    });
  }

  return clusters;
}

/**
 * Extract street name from address
 */
export function extractStreetName(address: string): string {
  // Simple extraction - can be improved with regex
  const parts = address.split(",");
  return parts[0]?.trim() || address;
}

/**
 * Calculate marker density on a street
 * Returns markers per kilometer
 */
export function calculateMarkerDensity(
  markers: MarkerPosition[],
  startLat: number,
  startLng: number,
  endLat: number,
  endLng: number
): number {
  const streetLength = haversineDistance(startLat, startLng, endLat, endLng);
  return markers.length / Math.max(streetLength, 0.1);
}

/**
 * Get marker visibility based on zoom level
 * Higher zoom = show more markers
 */
export function getVisibleMarkers(
  markers: MarkerPosition[],
  zoomLevel: number
): MarkerPosition[] {
  // Zoom 10-12: Show only every 5th marker
  // Zoom 13-14: Show every 2nd marker
  // Zoom 15+: Show all markers
  
  if (zoomLevel >= 15) return markers;
  if (zoomLevel >= 13) return markers.filter((_, i) => i % 2 === 0);
  if (zoomLevel >= 10) return markers.filter((_, i) => i % 5 === 0);
  
  return [];
}
