import { publicProcedure, protectedProcedure, router } from './_core/trpc';
import { z } from 'zod';
import { 
  fetchPlaceDetails, 
  batchFetchAndUploadPhotos, 
  extractOpeningHours,
  fetchAndUpdateStorePhoto,
  batchUpdateStoreDetails,
  getStoresNeedingPhotos,
  extractSquareMeters,
} from './placesApi';
import {
  fetchPhotosForAllStores,
  fetchPhotosForCity,
  fetchPhotosForBrand,
  getStoresWithoutPhotosCount,
} from './photoFetchService';
import { getDb } from './db';
import { luxuryNews } from '../drizzle/schema';
import { eq, and, isNull } from 'drizzle-orm';

export const placesRouter = router({
  /**
   * Fetch store details and photos from Google Places API
   */
  getStoreDetails: publicProcedure
    .input(z.object({
      storeName: z.string(),
      address: z.string(),
    }))
    .query(async (opts) => {
      const { input } = opts;
      try {
        const placeDetails = await fetchPlaceDetails(input.storeName, input.address);
        const openingHours = extractOpeningHours(placeDetails);
        
        return {
          success: true,
          data: {
            ...placeDetails,
            openingHours,
          },
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),

  /**
   * Batch fetch and upload photos for multiple stores
   */
  batchFetchPhotos: publicProcedure
    .input(z.object({
      stores: z.array(z.object({
        id: z.string(),
        name: z.string(),
        address: z.string(),
      })),
    }))
    .mutation(async (opts) => {
      const { input } = opts;
      try {
        const results = await batchFetchAndUploadPhotos(input.stores);
        
        return {
          success: true,
          data: results,
          totalStores: input.stores.length,
          storesWithPhotos: results.filter(r => r.photoUrls.length > 0).length,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),

  /**
   * Fetch and update photo for a specific store
   */
  fetchAndUpdatePhoto: protectedProcedure
    .input(z.object({
      storeId: z.string(),
      storeName: z.string(),
      address: z.string(),
      city: z.string(),
      country: z.string(),
      street: z.string().optional(),
    }))
    .mutation(async (opts) => {
      const { input, ctx } = opts;

      // Only admins can update photos
      if (ctx.user?.role !== 'admin') {
        return {
          success: false,
          error: 'Only admins can update store photos',
        };
      }

      try {
        console.log(`[tRPC] Fetching photo for ${input.storeName} at ${input.address}`);

        // Fetch and upload photo
        const photoResult = await fetchAndUpdateStorePhoto(
          input.storeId,
          input.storeName,
          input.address,
          input.city,
          input.street
        );

        if (!photoResult.success) {
          return {
            success: false,
            error: photoResult.error || 'Failed to fetch photo',
          };
        }

        return {
          success: true,
          photoUrl: photoResult.photoUrl,
          message: `Photo fetched and updated for ${input.storeName}`,
        };
      } catch (error) {
        console.error('[tRPC] Error in fetchAndUpdatePhoto:', error);
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),

  /**
   * Batch update store details (photos, opening hours, square meters) for all stores
   */
  batchUpdateAllStores: protectedProcedure
    .input(z.object({
      limit: z.number().optional().default(100),
      offset: z.number().optional().default(0),
    }))
    .mutation(async (opts) => {
      const { input, ctx } = opts;

      // Only admins can batch update
      if (ctx.user?.role !== 'admin') {
        return {
          success: false,
          error: 'Only admins can batch update stores',
        };
      }

      try {
        console.log(`[tRPC] Starting batch update for stores (limit: ${input.limit}, offset: ${input.offset})`);

        // Get stores needing photos
        const storesNeedingPhotos = await getStoresNeedingPhotos();
        const storesToProcess = storesNeedingPhotos.slice(input.offset, input.offset + input.limit);

        if (storesToProcess.length === 0) {
          return {
            success: true,
            message: 'No stores need photo updates',
            totalStores: 0,
            successfulUpdates: 0,
            failedUpdates: 0,
          };
        }

        // Batch update store details
        const result = await batchUpdateStoreDetails(storesToProcess);

        return {
          success: true,
          message: `Batch update completed: ${result.successfulUpdates} successful, ${result.failedUpdates} failed`,
          totalStores: result.totalStores,
          successfulUpdates: result.successfulUpdates,
          failedUpdates: result.failedUpdates,
          results: result.results,
        };
      } catch (error) {
        console.error('[tRPC] Error in batchUpdateAllStores:', error);
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),

  /**
   * Get count of stores needing photo updates
   */
  getStoresNeedingPhotosCount: publicProcedure
    .query(async () => {
      try {
        const db = await getDb();
        if (!db) {
          return {
            success: false,
            count: 0,
            error: 'Database not available',
          };
        }

        // Count stores without photos
        const storesWithoutPhotos = await db
          .select()
          .from(luxuryNews)
          .where(isNull(luxuryNews.photoUrl));

        return {
          success: true,
          count: storesWithoutPhotos.length,
        };
      } catch (error) {
        console.error('[tRPC] Error in getStoresNeedingPhotosCount:', error);
        return {
          success: false,
          count: 0,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),

  /**
   * Get photo upload status for a store
   */
  getPhotoStatus: publicProcedure
    .input(z.object({
      storeId: z.string(),
    }))
    .query(async (opts) => {
      const { input } = opts;
      try {
        const db = await getDb();
        if (!db) {
          return {
            storeId: input.storeId,
            photoCount: 0,
            lastUpdated: new Date(),
            status: 'pending',
          };
        }

        // Query database for photo status
        const store = await db
          .select()
          .from(luxuryNews)
          .where(eq(luxuryNews.id, parseInt(input.storeId)))
          .limit(1);

        if (store.length === 0) {
          return {
            storeId: input.storeId,
            photoCount: 0,
            lastUpdated: new Date(),
            status: 'not_found',
          };
        }

        const photoCount = store[0].photoUrl ? 1 : 0;

        return {
          storeId: input.storeId,
          photoCount,
          lastUpdated: store[0].updatedAt,
          status: photoCount > 0 ? 'completed' : 'pending',
          photoUrl: store[0].photoUrl || undefined,
        };
      } catch (error) {
        console.error('[tRPC] Error in getPhotoStatus:', error);
        return {
          storeId: input.storeId,
          photoCount: 0,
          lastUpdated: new Date(),
          status: 'error',
        };
      }
    }),

  /**
   * Get store by ID
   */
  getStoreById: publicProcedure
    .input(z.object({
      id: z.string(),
    }))
    .query(async (opts) => {
      const { input } = opts;
      try {
        const db = await getDb();
        if (!db) {
          return {
            success: false,
            store: null,
            error: 'Database not available',
          };
        }

        // Query store by ID
        const store = await db
          .select()
          .from(luxuryNews)
          .where(eq(luxuryNews.id, parseInt(input.id)))
          .limit(1);

        if (store.length === 0) {
          return {
            success: false,
            store: null,
            error: 'Store not found',
          };
        }

        return {
          success: true,
          store: store[0],
        };
      } catch (error) {
        console.error('[tRPC] Error in getStoreById:', error);
        return {
          success: false,
          store: null,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),

  /**
   * Get stores by city for batch processing
   */
  getStoresByCity: publicProcedure
    .input(z.object({
      city: z.string(),
      limit: z.number().optional().default(50),
    }))
    .query(async (opts) => {
      const { input } = opts;
      try {
        const db = await getDb();
        if (!db) {
          return {
            success: false,
            stores: [],
            error: 'Database not available',
          };
        }

        // Query stores by city
        const stores = await db
          .select()
          .from(luxuryNews)
          .where(eq(luxuryNews.city, input.city))
          .limit(input.limit);

        return {
          success: true,
          stores: stores.map((store) => ({
            id: store.id.toString(),
            brandName: store.brandName,
            city: store.city,
            street: store.street,
            photoUrl: store.photoUrl,
            hasPhoto: !!store.photoUrl,
          })),
        };
      } catch (error) {
        console.error('[tRPC] Error in getStoresByCity:', error);
        return {
          success: false,
          stores: [],
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),
});
