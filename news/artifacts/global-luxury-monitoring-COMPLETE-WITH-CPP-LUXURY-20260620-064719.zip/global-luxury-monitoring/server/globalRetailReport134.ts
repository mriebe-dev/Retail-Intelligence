/**
 * Global Luxury Retail Report Generator - 134 Cities Edition
 * Based on Retail Market Study 2016
 * Organized by Country -> City -> Street (like CH.Retail-Report.com)
 */

export interface StreetData {
  name: string;
  newsCount: number;
  topBrands: string[];
  category: string;
  priority: number; // 1 = highest priority (flagship streets), 5 = lower priority
}

export interface CityData {
  name: string;
  country: string;
  totalNews: number;
  uniqueStreets: number;
  topStreets: StreetData[];
  allStreets: StreetData[];
}

export interface CountryData {
  name: string;
  totalNews: number;
  totalCities: number;
  totalStreets: number;
  cities: CityData[];
}

// Comprehensive street data for 134 premium cities worldwide
export const GLOBAL_RETAIL_STREETS_134: Record<string, Record<string, string[]>> = {
  // CONTINENTAL EUROPE
  Switzerland: {
    Zurich: [
      "Bahnhofstrasse",
      "Rennweg",
      "Storchengasse",
      "Augustinergasse",
      "Lintheschergasse",
    ],
    Geneva: [
      "Rue du Rhône",
      "Rue de la Confederation",
      "Rue de Mont-Blanc",
      "Place Bel-Air",
    ],
    Lucerne: ["Hertensteinstrasse", "Kapellgasse", "Löwenstrasse"],
    Basel: ["Freiestrasse", "Marktplatz", "Gerbergasse"],
  },
  Germany: {
    Berlin: [
      "Kurfürstendamm",
      "Friedrichstrasse",
      "Tauentzienstrasse",
      "Wilmersdorfer Strasse",
    ],
    Munich: [
      "Maximilianstrasse",
      "Marienplatz",
      "Kaufingerstrasse",
      "Neuhauserstrasse",
      "Sendlingerstrasse",
      "Weinstrasse",
      "Dienerstrasse",
      "Perusastrasse",
      "Residenzstrasse",
      "Theatinerstrasse",
    ],
    Hamburg: ["Möhlstrasse", "Jungfernstieg", "Neuer Wall"],
    Cologne: ["Hohe Strasse", "Schildergasse", "Ehrenstrasse"],
    Frankfurt: ["Zeil", "Main Tower", "Bankenviertel"],
    Stuttgart: ["Königstrasse", "Markthalle", "Theodor-Heuss-Strasse"],
    Düsseldorf: ["Königsallee", "Schadowstrasse", "Flinger Strasse"],
  },
  Austria: {
    Vienna: [
      "Kärntner Strasse",
      "Graben",
      "Kohlmarkt",
      "Stephansplatz",
      "Neuer Markt",
      "Ringstrasse",
      "Mariahilfer Strasse",
    ],
    Salzburg: ["Getreidegasse", "Linzergasse", "Judengasse"],
    Innsbruck: ["Maria-Theresien-Strasse", "Herzog-Friedrich-Strasse"],
  },
  France: {
    Paris: [
      "Champs-Élysées",
      "Rue Saint-Honoré",
      "Avenue Montaigne",
      "Rue de Rivoli",
      "Boulevard Saint-Germain",
      "Rue de la Paix",
      "Place Vendôme",
      "Rue de Castiglione",
    ],
    Cannes: ["Rue d'Antibes", "Croisette", "Rue Meynadier"],
    Nice: ["Promenade des Anglais", "Rue Masséna", "Rue de France"],
    "Saint-Tropez": ["Rue Allard", "Rue Gambetta", "Rue Clemenceau"],
    Chamonix: ["Rue du Docteur Paccard", "Rue Michel Croz"],
  },
  Belgium: {
    Brussels: [
      "Rue de Namur",
      "Galeries Royales",
      "Rue Neuve",
      "Avenue Louise",
      "Rue Royale",
    ],
    Antwerp: ["Meir", "Groendalstraat", "Huidevettersstraat"],
  },
  Netherlands: {
    Amsterdam: [
      "Kalverstraat", // HMV Store opened 2026-03-15 at Kalverstraat 8
      "P.C. Hooftstraat",
      "Nieuwendijk",
      "Leidsestraat",
      "Negen Straatjes",
      "Rokin",
      "Dam",
    ],
  },
  Luxembourg: {
    "Luxembourg City": ["Rue de la Paix", "Rue de Strasbourg", "Rue Aldringen"],
  },
  Italy: {
    Milan: [
      "Via Monte Napoleone",
      "Via della Spiga",
      "Via Sant'Andrea",
      "Galleria Vittorio Emanuele II",
      "Corso Como",
      "Via Manzoni",
    ],
    Rome: [
      "Via Condotti",
      "Via del Corso",
      "Via Frattina",
      "Piazza di Spagna",
      "Via Sistina",
    ],
    Florence: ["Via Tornabuoni", "Ponte Vecchio", "Via Roma"],
    Venice: ["Calle Larga XXII Marzo", "Merceria", "Grand Canal"],
  },
  Spain: {
    Barcelona: [
      "Passeig de Gràcia",
      "Rambla",
      "Carrer de Montcada",
      "Avinguda Diagonal",
      "Passeig de Colom",
    ],
    Madrid: [
      "Gran Vía",
      "Calle Serrano",
      "Paseo del Prado",
      "Calle Claudio Coello",
      "Paseo de Recoletos",
    ],
  },
  Portugal: {
    Lisbon: [
      "Chiado",
      "Baixa",
      "Avenida da Liberdade",
      "Rua Aurea",
      "Rua do Carmo",
    ],
  },

  // UNITED KINGDOM & IRELAND
  "United Kingdom": {
    London: [
      "Oxford Street",
      "Bond Street",
      "Regent Street",
      "Sloane Street",
      "Knightsbridge",
      "King's Road",
      "Piccadilly",
    ],
    Edinburgh: [
      "Princes Street",
      "George Street",
      "Rose Street",
      "Multrees Walk",
      "Royal Mile",
    ],
    Glasgow: [
      "Buchanan Street",
      "Sauchiehall Street",
      "Argyle Street",
      "Merchant City",
      "Princes Square",
    ],
  },
  Ireland: {
    Dublin: [
      "Grafton Street",
      "Henry Street",
      "Temple Bar",
      "Exchequer Street",
      "South Great George's Street",
    ],
  },

  // NORTHERN EUROPE
  Denmark: {
    Copenhagen: ["Strøget", "Nygade", "Frederiksberggade"],
  },
  Norway: {
    Oslo: ["Karl Johans Gate", "Ferner Jacobsens Gate", "Bogstadveien"],
  },
  Sweden: {
    Stockholm: ["Drottninggatan", "Hamngatan", "Biblioteksgatan"],
  },
  Finland: {
    Helsinki: ["Aleksanterinkatu", "Esplanadi", "Mannerheimintie"],
  },

  // RUSSIA
  Russia: {
    Moscow: [
      "Tverskaya Street",
      "Red Square",
      "Petrovka Street",
      "Kuznetsky Most",
    ],
    "Saint Petersburg": ["Nevsky Prospekt", "Gorokhovaya Street"],
  },

  // EASTERN EUROPE
  Ukraine: {
    Kiev: ["Khreshchatyk", "Andriyivsky Descent", "Vul. Prorizna"],
  },
  Estonia: {
    Tallinn: ["Viru Street", "Pikk Street", "Müürivahe Street"],
  },
  Latvia: {
    Riga: ["Kalku Street", "Brīvības Street", "Elizabetas Street"],
  },
  Lithuania: {
    Vilnius: ["Gediminas Avenue", "Pilies Street", "Vokiečių Street"],
  },
  Poland: {
    Warsaw: [
      "Nowy Świat",
      "Marszałkowska",
      "Krakowskie Przedmieście",
      "Chmielna",
    ],
  },
  "Czech Republic": {
    Prague: [
      "Old Town Square",
      "Celetna",
      "Parizska",
      "Wenceslas Square",
      "Na Příkopě",
    ],
  },
  Hungary: {
    Budapest: [
      "Andrássy Avenue",
      "Váci utca",
      "Vörösmarty Square",
      "Deák Ferenc utca",
    ],
  },
  Romania: {
    Bucharest: ["Calea Victoriei", "Lipscani", "Dorobanți"],
  },
  Kazakhstan: {
    Almaty: ["Zhybek Zholy", "Panfilov Street", "Abay Avenue"],
  },
  Azerbaijan: {
    Baku: ["Nizami Street", "Fountain Square", "Istiklal Street"],
  },
  Bulgaria: {
    Sofia: ["Vitosha Boulevard", "Tsar Osvoboditel Boulevard"],
  },

  // SOUTHEASTERN EUROPE
  Greece: {
    Athens: [
      "Ermou Street",
      "Syntagma",
      "Monastiraki",
      "Voukourestiou Street",
    ],
  },
  Serbia: {
    Belgrade: ["Knez Mihailova", "Terazije", "Beton Hala"],
  },
  "North Macedonia": {
    Skopje: ["Makedonska Street", "Pazar Street"],
  },
  Croatia: {
    Zagreb: ["Ilica", "Tkalčićeva Street", "Jelačić Square"],
  },

  // MIDDLE EAST
  Turkey: {
    Istanbul: [
      "Istiklal Avenue",
      "Galata",
      "Taksim",
      "Nisantasi",
      "Sultanahmet",
    ],
  },
  Bahrain: {
    Manama: ["Bab Al Bahrain", "Manama Souk", "Seef District"],
  },
  Israel: {
    "Tel Aviv": ["Dizengoff Street", "Rothschild Boulevard", "Rabin Square"],
  },
  Lebanon: {
    Beirut: ["Hamra Street", "Verdun Street", "Downtown Beirut"],
  },
  "United Arab Emirates": {
    Dubai: [
      "Dubai Mall",
      "Gold Souk",
      "The Galleria",
      "Mall of the Emirates",
    ],
    "Abu Dhabi": ["The Galleria", "Saadiyat", "Downtown Abu Dhabi"],
  },
  "Saudi Arabia": {
    Riyadh: ["Riyadh Gallery", "Downtown", "Al Nakheel"],
    Jeddah: ["Red Sea Mall", "Downtown", "Corniche"],
  },
  Kuwait: {
    "Kuwait City": ["The Avenues", "Salmiya", "Downtown Kuwait"],
  },
  Qatar: {
    Doha: ["The Pearl", "Lusail", "West Bay", "Corniche"],
  },
  Oman: {
    Muscat: ["Mutrah Corniche", "Mutrah Souk", "Ghubrah"],
  },

  // INDIA
  India: {
    Mumbai: ["Bandra", "Fort", "Colaba", "Worli"],
    "New Delhi": ["Connaught Place", "Khan Market", "DLF Cyber Hub"],
  },

  // ASIA
  Vietnam: {
    Hanoi: ["Hoan Kiem", "Old Quarter", "Dong Khoi"],
    "Ho Chi Minh City": ["Dong Khoi", "Ben Thanh", "District 1"],
  },
  Thailand: {
    Bangkok: [
      "Silom",
      "Sukhumvit",
      "Wireless Road",
      "Emporium",
      "EmQuartier",
    ],
  },
  Malaysia: {
    "Kuala Lumpur": [
      "Pavilion KL",
      "Bukit Bintang",
      "Midvalley",
      "Bangsar",
    ],
  },
  Singapore: {
    Singapore: ["Orchard Road", "Marina Bay", "Raffles Place"],
  },
  Indonesia: {
    Jakarta: ["Senayan", "Menteng", "Blok M", "Kelapa Gading"],
  },
  Philippines: {
    Manila: ["Makati", "BGC", "Quezon City", "Ortigas"],
  },
  Cambodia: {
    "Phnom Penh": ["Sisowath Quay", "Street 178", "Riverside"],
  },

  // CHINA
  China: {
    Beijing: [
      "Wangfujing Street",
      "Sanlitun",
      "Qianmen Street",
      "Xidan",
      "Chaoyang",
    ],
    Shanghai: [
      "Nanjing Road",
      "Huaihai Road",
      "Jing'an",
      "Pudong",
      "French Concession",
    ],
    "Hong Kong": ["Central", "Causeway Bay", "Mong Kok", "Tsim Sha Tsui"],
    Macau: ["Rua da Felicidade", "Avenida de Almeida Ribeiro"],
    Chongqing: ["Jiefangbei", "Tanan Street"],
    Wuhan: ["Hankou", "Wuchang", "Hanyang"],
    Chengdu: ["Chunxi Road", "Taikooli", "Kuanzhai Xiangzi"],
    Tianjin: ["Binjiang Road", "Heping District"],
    Shenyang: ["Zhongshan Road", "Taiyuan Street"],
    Hangzhou: ["Hubin Road", "Yan'an Road", "West Lake"],
    Nanjing: ["Hunan Road", "Xinjiekou", "Confucius Temple"],
    Guangzhou: ["Beijing Road", "Liwan", "Tianhe"],
    Qingdao: ["Zhongshan Road", "Taidong Road"],
  },

  // ASIA & PACIFIC
  "South Korea": {
    Seoul: [
      "Gangnam",
      "Myeongdong",
      "Insadong",
      "Hongdae",
      "Itaewon",
      "Cheongdam",
    ],
  },
  Taiwan: {
    Taipei: ["Taipei 101", "Dunnan", "Xinyi", "Daan"],
  },
  Japan: {
    Tokyo: [
      "Ginza",
      "Shibuya",
      "Shinjuku",
      "Harajuku",
      "Roppongi",
      "Akihabara",
    ],
    Yokohama: ["Landmark Tower", "Motomachi", "Minato Mirai"],
    Osaka: ["Dotonbori", "Shinsaibashi", "Umeda"],
    Fukuoka: ["Tenjin", "Nakasu", "Hakata"],
    Kyoto: ["Gion", "Kawaramachi", "Sanjo"],
  },
  Australia: {
    Sydney: [
      "Pitt Street",
      "Double Bay",
      "Paddington",
      "Surry Hills",
    ],
    Melbourne: [
      "Collins Street",
      "Chapel Street",
      "Toorak Road",
      "South Yarra",
    ],
    Brisbane: ["Queen Street", "South Bank", "Fortitude Valley"],
  },

  // AFRICA
  Morocco: {
    Casablanca: ["Anfa", "Downtown", "Medina"],
    Marrakesh: ["Medina", "Gueliz", "Jemaa el-Fnaa"],
  },
  Algeria: {
    Algiers: ["Rue Didouche Mourad", "Rue Larbi Ben M'hidi"],
  },
  Egypt: {
    Cairo: ["Khan El-Khalili", "Downtown", "Heliopolis"],
  },
  Nigeria: {
    Lagos: ["Victoria Island", "Ikoyi", "Lekki"],
  },
  Namibia: {
    Windhoek: ["Independence Avenue", "Post Street"],
  },
  "South Africa": {
    Johannesburg: ["Sandton", "Rosebank", "Parkhurst"],
    "Cape Town": ["V&A Waterfront", "Camps Bay", "Constantia Nek"],
  },

  // NORTH AMERICA
  Canada: {
    Vancouver: [
      "Robson Street",
      "Gastown",
      "Granville Street",
      "Alberni Street",
    ],
    Toronto: [
      "Bloor Street",
      "Queen Street West",
      "King Street West",
      "Yorkville",
    ],
  },
  "United States": {
    "New York": [
      "Fifth Avenue",
      "Madison Avenue",
      "Park Avenue",
      "Broadway",
      "SoHo",
      "NoHo",
      "TriBeCa",
      "Upper East Side",
    ],
    Boston: ["Newbury Street", "Downtown", "Back Bay"],
    Chicago: [
      "Michigan Avenue",
      "State Street",
      "North Avenue",
      "Armitage Avenue",
    ],
    "Washington D.C.": ["M Street", "Connecticut Avenue", "Georgetown"],
    Atlanta: ["Buckhead", "Downtown", "Midtown"],
    Miami: ["Lincoln Road", "Brickell", "Wynwood", "Design District"],
    Houston: ["Uptown", "Downtown", "Midtown"],
    Dallas: ["Uptown", "Downtown", "Highland Park"],
    Denver: ["Cherry Creek", "Downtown", "LoDo"],
    "Las Vegas": ["The Strip", "Downtown", "Fremont Street"],
    "San Francisco": [
      "Union Street",
      "Market Street",
      "Fillmore Street",
      "Haight Street",
    ],
    "Los Angeles": [
      "Rodeo Drive",
      "Sunset Boulevard",
      "Hollywood Boulevard",
      "Melrose Avenue",
    ],
    "San Diego": ["Gaslamp Quarter", "Fashion Valley", "Downtown"],
  },

  // LATIN AMERICA
  Mexico: {
    "Mexico City": [
      "Paseo de la Reforma",
      "Polanco",
      "Condesa",
      "Roma",
      "Centro Histórico",
    ],
  },
  Panama: {
    "Panama City": ["Cinta Costera", "Punta Pacifica", "Amador"],
  },
  Colombia: {
    Bogotá: ["Carrera 7", "Zona Rosa", "Usaquén"],
  },
  Peru: {
    Lima: ["Jirón de la Unión", "Miraflores", "San Isidro"],
  },
  Chile: {
    Santiago: ["Paseo Ahumada", "Lastarria", "Providencia"],
  },
  Brazil: {
    "São Paulo": [
      "Oscar Freire Street",
      "Paulista Avenue",
      "Rua Augusta",
    ],
    "Rio de Janeiro": ["Copacabana", "Ipanema", "Leblon"],
  },
};

/**
 * Get all countries with their data
 */
export function getAllCountries(): string[] {
  return Object.keys(GLOBAL_RETAIL_STREETS_134).sort();
}

/**
 * Get all cities for a country
 */
export function getCitiesByCountry(country: string): string[] {
  return Object.keys(GLOBAL_RETAIL_STREETS_134[country] || {}).sort();
}

/**
 * Get all streets for a city
 */
export function getStreetsByCity(country: string, city: string): string[] {
  return GLOBAL_RETAIL_STREETS_134[country]?.[city] || [];
}

/**
 * Get statistics for country
 */
export function getCountryStats(country: string): {
  country: string;
  cities: number;
  streets: number;
  totalStreets: string[];
} {
  const cities = getCitiesByCountry(country);
  const allStreets = new Set<string>();

  cities.forEach((city) => {
    const streets = getStreetsByCity(country, city);
    streets.forEach((street) => allStreets.add(street));
  });

  return {
    country,
    cities: cities.length,
    streets: allStreets.size,
    totalStreets: Array.from(allStreets).sort(),
  };
}

/**
 * Get statistics for city
 */
export function getCityStats(country: string, city: string): {
  country: string;
  city: string;
  streets: number;
  streetList: string[];
} {
  const streets = getStreetsByCity(country, city);

  return {
    country,
    city,
    streets: streets.length,
    streetList: streets,
  };
}

/**
 * Generate full report structure
 */
export function generateFullReport(): CountryData[] {
  const countries = getAllCountries();

  return countries.map((country) => {
    const cities = getCitiesByCountry(country);
    const countryStats = getCountryStats(country);

    return {
      name: country,
      totalNews: 0,
      totalCities: cities.length,
      totalStreets: countryStats.streets,
      cities: cities.map((city) => {
        const cityStats = getCityStats(country, city);

        return {
          name: city,
          country,
          totalNews: 0,
          uniqueStreets: cityStats.streets,
          topStreets: [],
          allStreets: cityStats.streetList.map((street) => ({
            name: street,
            newsCount: 0,
            topBrands: [],
            category: "Luxury Retail",
            priority: getStreetPriority(country, city, street),
          })),
        };
      }),
    };
  });
}

/**
 * Get street priority based on importance metrics
 * Priority 1 = Flagship streets (Bahnhofstrasse, Champs-Élysées, etc.)
 * Priority 2 = Premium streets (Rennweg, Rue du Rhône, etc.)
 * Priority 3 = Major streets (secondary premium locations)
 * Priority 4 = Standard streets
 * Priority 5 = Emerging streets
 */
export function getStreetPriority(country: string, city: string, street: string): number {
  // Flagship streets - Priority 1
  const flagshipStreets: Record<string, Record<string, string[]>> = {
    Switzerland: {
      Zurich: ["Bahnhofstrasse"],
      Geneva: ["Rue du Rhône"],
      Basel: ["Freiestrasse"],
    },
    Germany: {
      Berlin: ["Kurfürstendamm"],
      Munich: ["Maximilianstrasse"],
      Hamburg: ["Jungfernstieg"],
      Cologne: ["Hohe Strasse"],
      Frankfurt: ["Zeil"],
      Stuttgart: ["Königstrasse"],
      Düsseldorf: ["Königsallee"],
    },
    Austria: {
      Vienna: ["Kärntner Strasse"],
      Salzburg: ["Getreidegasse"],
    },
    France: {
      Paris: ["Champs-Élysées", "Avenue Montaigne"],
      Cannes: ["Croisette"],
      Nice: ["Promenade des Anglais"],
    },
    Belgium: {
      Brussels: ["Rue de Namur"],
      Antwerp: ["Meir"],
    },
    Netherlands: {
      Amsterdam: ["P.C. Hooftstraat"],
    },
    Italy: {
      Milan: ["Via Monte Napoleone"],
      Rome: ["Via Condotti"],
      Florence: ["Via Tornabuoni"],
      Venice: ["Calle Larga XXII Marzo"],
    },
    Spain: {
      Barcelona: ["Passeig de Gràcia"],
      Madrid: ["Gran Vía"],
    },
    "United Kingdom": {
      London: ["Bond Street"],
      Edinburgh: ["Princes Street"],
    },
    "United States": {
      "New York": ["Fifth Avenue"],
      "Los Angeles": ["Rodeo Drive"],
    },
  };

  // Premium streets - Priority 2
  const premiumStreets: Record<string, Record<string, string[]>> = {
    Switzerland: {
      Zurich: ["Rennweg", "Storchengasse"],
      Geneva: ["Rue de la Confederation", "Rue de Mont-Blanc"],
      Basel: ["Marktplatz"],
    },
    Germany: {
      Berlin: ["Friedrichstrasse"],
      Munich: ["Marienplatz", "Kaufingerstrasse"],
      Hamburg: ["Neuer Wall"],
      Cologne: ["Schildergasse"],
      Frankfurt: ["Main Tower"],
      Stuttgart: ["Markthalle"],
      Düsseldorf: ["Schadowstrasse"],
    },
    Austria: {
      Vienna: ["Graben", "Kohlmarkt"],
      Salzburg: ["Linzergasse"],
    },
    France: {
      Paris: ["Rue Saint-Honoré", "Rue de Rivoli"],
      Cannes: ["Rue d'Antibes"],
      Nice: ["Rue Masséna"],
    },
    Belgium: {
      Brussels: ["Galeries Royales"],
      Antwerp: ["Groendalstraat"],
    },
    Netherlands: {
      Amsterdam: ["Kalverstraat", "Nieuwendijk"],
    },
    Italy: {
      Milan: ["Via della Spiga", "Via Sant'Andrea"],
      Rome: ["Via del Corso"],
      Florence: ["Ponte Vecchio"],
      Venice: ["Merceria"],
    },
    Spain: {
      Barcelona: ["Rambla"],
      Madrid: ["Calle de Serrano"],
    },
    "United Kingdom": {
      London: ["Oxford Street", "Regent Street"],
      Edinburgh: ["George Street"],
    },
    "United States": {
      "New York": ["Madison Avenue"],
      "Los Angeles": ["Sunset Boulevard"],
    },
  };

  // Check flagship streets
  if (flagshipStreets[country]?.[city]?.includes(street)) {
    return 1;
  }

  // Check premium streets
  if (premiumStreets[country]?.[city]?.includes(street)) {
    return 2;
  }

  // Check if it's a major street (contains "strasse", "street", "avenue", "boulevard", etc.)
  const majorKeywords = ["strasse", "street", "avenue", "boulevard", "plaza", "place", "piazza", "via", "rue"];
  const isMajor = majorKeywords.some(keyword => street.toLowerCase().includes(keyword));
  if (isMajor) {
    return 3;
  }

  // Default to standard street
  return 4;
}

/**
 * Get total statistics
 */
export function getTotalStats(): {
  countries: number;
  cities: number;
  streets: number;
} {
  const countries = getAllCountries();
  let totalCities = 0;
  let totalStreets = 0;

  countries.forEach((country) => {
    const stats = getCountryStats(country);
    totalCities += stats.cities;
    totalStreets += stats.streets;
  });

  return {
    countries: countries.length,
    cities: totalCities,
    streets: totalStreets,
  };
}
