import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
  fetchPlaceDetails,
  uploadPhotoToS3,
  batchFetchAndUploadPhotos,
  extractOpeningHours,
  placeDetailsSchema,
  fetchAndUpdateStorePhoto,
} from './placesApi';

describe('Google Places API Integration - HMV Amsterdam Store', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe('placeDetailsSchema', () => {
    it('should validate correct place details', () => {
      const validData = {
        name: 'Chanel Store',
        address: 'Bahnhofstrasse 1, Zurich',
        photos: ['https://example.com/photo1.jpg'],
        openingHours: ['09:00-18:00', '09:00-18:00'],
        website: 'https://chanel.com',
        phoneNumber: '+41 44 123 4567',
        rating: 4.5,
        reviews: 123,
      };

      const result = placeDetailsSchema.safeParse(validData);
      expect(result.success).toBe(true);
    });

    it('should allow optional fields', () => {
      const minimalData = {
        name: 'Chanel Store',
        address: 'Bahnhofstrasse 1, Zurich',
      };

      const result = placeDetailsSchema.safeParse(minimalData);
      expect(result.success).toBe(true);
    });

    it('should reject invalid data', () => {
      const invalidData = {
        name: 'Chanel Store',
        // missing required address
      };

      const result = placeDetailsSchema.safeParse(invalidData);
      expect(result.success).toBe(false);
    });
  });

  describe('fetchPlaceDetails', () => {
    it('should fetch place details successfully', async () => {
      const result = await fetchPlaceDetails('Chanel Store', 'Bahnhofstrasse 1, Zurich');

      expect(result).toBeDefined();
      expect(result.name).toBe('Chanel Store');
      expect(result.address).toBe('Bahnhofstrasse 1, Zurich');
      expect(Array.isArray(result.photos)).toBe(true);
    });

    it('should handle store names with special characters', async () => {
      const result = await fetchPlaceDetails(
        'Chanel - Flagship Store',
        'Bahnhofstrasse 1, Zurich'
      );

      expect(result.name).toBe('Chanel - Flagship Store');
    });

    it('should handle international addresses', async () => {
      const result = await fetchPlaceDetails(
        'Gucci Store',
        'Via Monte Napoleone 8, Milan, Italy'
      );

      expect(result.address).toContain('Milan');
    });
  });

  describe('extractOpeningHours', () => {
    it('should extract opening hours correctly', () => {
      const placeDetails = {
        name: 'Chanel Store',
        address: 'Bahnhofstrasse 1, Zurich',
        openingHours: [
          '09:00-18:00',
          '09:00-18:00',
          '09:00-18:00',
          '09:00-18:00',
          '09:00-18:00',
          '10:00-17:00',
          'Closed',
        ],
      };

      const hours = extractOpeningHours(placeDetails);

      expect(hours['Monday']).toBe('09:00-18:00');
      expect(hours['Saturday']).toBe('10:00-17:00');
      expect(hours['Sunday']).toBe('Closed');
    });

    it('should handle missing opening hours', () => {
      const placeDetails = {
        name: 'Chanel Store',
        address: 'Bahnhofstrasse 1, Zurich',
      };

      const hours = extractOpeningHours(placeDetails);

      expect(Object.keys(hours).length).toBe(0);
    });
  });

  describe('batchFetchAndUploadPhotos', () => {
    it('should process multiple stores', async () => {
      const stores = [
        { id: '1', name: 'Chanel', address: 'Bahnhofstrasse 1, Zurich' },
        { id: '2', name: 'Gucci', address: 'Rennweg 1, Zurich' },
        { id: '3', name: 'Dior', address: 'Rue du Rhône 1, Geneva' },
      ];

      const results = await batchFetchAndUploadPhotos(stores);

      expect(results).toHaveLength(3);
      expect(results[0].storeId).toBe('1');
      expect(results[1].storeId).toBe('2');
      expect(results[2].storeId).toBe('3');
    });

    it('should return empty photo URLs for failed uploads', async () => {
      const stores = [
        { id: '1', name: 'Unknown Store', address: 'Unknown Address' },
      ];

      const results = await batchFetchAndUploadPhotos(stores);

      expect(results[0].photoUrls).toEqual([]);
    });

    it('should handle large batch of stores', async () => {
      const stores = Array.from({ length: 100 }, (_, i) => ({
        id: `${i + 1}`,
        name: `Store ${i + 1}`,
        address: `Address ${i + 1}`,
      }));

      const results = await batchFetchAndUploadPhotos(stores);

      expect(results).toHaveLength(100);
    });
  });

  describe('Photo Upload Workflow', () => {
    it('should handle complete photo upload workflow', async () => {
      const stores = [
        {
          id: '1',
          name: 'Chanel Flagship',
          address: 'Bahnhofstrasse 1, Zurich, Switzerland',
        },
      ];

      // Fetch details
      const details = await fetchPlaceDetails(stores[0].name, stores[0].address);
      expect(details.name).toBe(stores[0].name);

      // Extract opening hours
      const hours = extractOpeningHours(details);
      expect(typeof hours).toBe('object');

      // Batch upload
      const results = await batchFetchAndUploadPhotos(stores);
      expect(results).toHaveLength(1);
      expect(results[0].storeId).toBe('1');
    });
  });

  describe('Error Handling', () => {
    it('should handle network errors gracefully', async () => {
      // This test verifies error handling in the batch function
      const stores = [
        { id: '1', name: 'Test Store', address: 'Test Address' },
      ];

      const results = await batchFetchAndUploadPhotos(stores);

      // Should return results even if some stores fail
      expect(Array.isArray(results)).toBe(true);
      expect(results[0]).toHaveProperty('storeId');
      expect(results[0]).toHaveProperty('photoUrls');
    });
  });

  describe('HMV Amsterdam Store Integration', () => {
    it('should correctly identify HMV Amsterdam store', async () => {
      const storeName = 'HMV';
      const address = 'Kalverstraat 8, Amsterdam, Netherlands';

      const result = await fetchPlaceDetails(storeName, address);

      expect(result).toBeDefined();
      expect(result.name).toBe('HMV');
      expect(result.address).toBe(address);
      expect(Array.isArray(result.photos)).toBe(true);
    });

    it('should handle HMV Amsterdam in batch processing', async () => {
      const stores = [
        {
          id: 'hmv-amsterdam-2026-03-15',
          name: 'HMV',
          address: 'Kalverstraat 8, Amsterdam, Netherlands',
        },
      ];

      const results = await batchFetchAndUploadPhotos(stores);

      expect(results).toHaveLength(1);
      expect(results[0].storeId).toBe('hmv-amsterdam-2026-03-15');
      expect(Array.isArray(results[0].photoUrls)).toBe(true);
    });

    it('should extract opening hours for HMV Amsterdam', () => {
      const placeDetails = {
        name: 'HMV',
        address: 'Kalverstraat 8, Amsterdam, Netherlands',
        openingHours: [
          'Mon 10:00 AM - 8:00 PM',
          'Tue 10:00 AM - 8:00 PM',
          'Wed 10:00 AM - 8:00 PM',
          'Thu 10:00 AM - 9:00 PM',
          'Fri 10:00 AM - 9:00 PM',
          'Sat 10:00 AM - 8:00 PM',
          'Sun 12:00 PM - 6:00 PM',
        ],
      };

      const hours = extractOpeningHours(placeDetails);

      expect(hours['Monday']).toBe('Mon 10:00 AM - 8:00 PM');
      expect(hours['Thursday']).toBe('Thu 10:00 AM - 9:00 PM');
      expect(hours['Friday']).toBe('Fri 10:00 AM - 9:00 PM');
      expect(hours['Sunday']).toBe('Sun 12:00 PM - 6:00 PM');
    });

    it('should validate HMV Amsterdam store details schema', () => {
      const hmvData = {
        name: 'HMV',
        address: 'Kalverstraat 8, Amsterdam, Netherlands',
        photos: [],
        openingHours: [
          'Mon 10:00 AM - 8:00 PM',
          'Tue 10:00 AM - 8:00 PM',
          'Wed 10:00 AM - 8:00 PM',
          'Thu 10:00 AM - 9:00 PM',
          'Fri 10:00 AM - 9:00 PM',
          'Sat 10:00 AM - 8:00 PM',
          'Sun 12:00 PM - 6:00 PM',
        ],
      };

      const result = placeDetailsSchema.safeParse(hmvData);
      expect(result.success).toBe(true);
    });
  });
});
