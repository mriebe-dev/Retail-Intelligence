import { getDb } from './db';
import { luxuryNews } from '../drizzle/schema';
import { eq, and } from 'drizzle-orm';
import crypto from 'crypto';

export interface StoreImportData {
  brandName: string;
  city: string;
  country: string;
  street?: string;
  date: string;
  category: 'Fashion' | 'Watches' | 'Jewelry' | 'Home' | 'Other';
  photoUrl?: string;
  source: string;
  link: string;
  description: string;
}

export interface ImportResult {
  total: number;
  imported: number;
  duplicates: number;
  errors: Array<{ row: number; error: string }>;
  details: Array<{
    brandName: string;
    city: string;
    status: 'imported' | 'duplicate' | 'error';
    message?: string;
  }>;
}

/**
 * Generate URL hash for duplicate prevention
 */
function generateUrlHash(link: string): string {
  return crypto.createHash('sha256').update(link).digest('hex');
}

/**
 * Check if a store already exists in the database
 */
async function storeExists(
  brandName: string,
  city: string,
  street?: string
): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  const conditions = [
    eq(luxuryNews.brandName, brandName),
    eq(luxuryNews.city, city),
  ];
  if (street) {
    conditions.push(eq(luxuryNews.street, street));
  }

  const query = and(...conditions);
  const existing = await db.select().from(luxuryNews).where(query).limit(1);
  return existing.length > 0;
}

/**
 * Validate store data
 */
function validateStoreData(data: StoreImportData, rowNumber: number): string | null {
  if (!data.brandName || data.brandName.trim() === '') {
    return `Row ${rowNumber}: Brand name is required`;
  }

  if (!data.city || data.city.trim() === '') {
    return `Row ${rowNumber}: City is required`;
  }

  if (!data.country || data.country.trim() === '') {
    return `Row ${rowNumber}: Country is required`;
  }

  if (!data.date || data.date.trim() === '') {
    return `Row ${rowNumber}: Date is required`;
  }

  // Validate date format (YYYY-MM-DD)
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data.date)) {
    return `Row ${rowNumber}: Invalid date format (use YYYY-MM-DD)`;
  }

  if (!data.category || !['Fashion', 'Watches', 'Jewelry', 'Home', 'Other'].includes(data.category)) {
    return `Row ${rowNumber}: Invalid category (must be Fashion, Watches, Jewelry, Home, or Other)`;
  }

  if (!data.source || data.source.trim() === '') {
    return `Row ${rowNumber}: Source is required`;
  }

  if (!data.link || data.link.trim() === '') {
    return `Row ${rowNumber}: Link is required`;
  }

  if (!data.description || data.description.trim() === '') {
    return `Row ${rowNumber}: Description is required`;
  }

  return null;
}

/**
 * Import stores from CSV/JSON data
 */
export async function importStores(
  storesData: StoreImportData[]
): Promise<ImportResult> {
  const result: ImportResult = {
    total: storesData.length,
    imported: 0,
    duplicates: 0,
    errors: [],
    details: [],
  };

  for (let i = 0; i < storesData.length; i++) {
    const store = storesData[i];
    const rowNumber = i + 2; // +2 because row 1 is header, 0-indexed

    // Validate data
    const validationError = validateStoreData(store, rowNumber);
    if (validationError) {
      result.errors.push({ row: rowNumber, error: validationError });
      result.details.push({
        brandName: store.brandName,
        city: store.city,
        status: 'error',
        message: validationError,
      });
      continue;
    }

    try {
      // Check for duplicates
      const exists = await storeExists(store.brandName, store.city, store.street);
      if (exists) {
        result.duplicates++;
        result.details.push({
          brandName: store.brandName,
          city: store.city,
          status: 'duplicate',
          message: `${store.brandName} in ${store.city} already exists`,
        });
        continue;
      }

      // Insert new store
      const db = await getDb();
      if (!db) {
        throw new Error('Database connection failed');
      }

      const urlHash = generateUrlHash(store.link);

      await db.insert(luxuryNews).values({
        urlHash,
        brandName: store.brandName.trim(),
        city: store.city.trim(),
        country: store.country.trim(),
        street: store.street ? store.street.trim() : null,
        date: store.date,
        category: store.category,
        photoUrl: store.photoUrl || null,
        source: store.source.trim(),
        link: store.link.trim(),
        description: store.description.trim(),
        status: 'new',
      });

      result.imported++;
      result.details.push({
        brandName: store.brandName,
        city: store.city,
        status: 'imported',
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      result.errors.push({
        row: rowNumber,
        error: `Failed to import: ${errorMessage}`,
      });
      result.details.push({
        brandName: store.brandName,
        city: store.city,
        status: 'error',
        message: errorMessage,
      });
    }
  }

  return result;
}

/**
 * Parse CSV data
 */
export function parseCSV(csvContent: string): StoreImportData[] {
  const lines = csvContent.split('\n').filter((line) => line.trim());
  if (lines.length < 2) {
    throw new Error('CSV must have at least header and one data row');
  }

  const headers = lines[0].split(',').map((h) => h.trim().toLowerCase());
  const stores: StoreImportData[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map((v) => v.trim());
    if (values.length < headers.length) continue;

    const store: any = {};
    headers.forEach((header, index) => {
      store[header] = values[index];
    });

    stores.push(store as StoreImportData);
  }

  return stores;
}

/**
 * Parse JSON data
 */
export function parseJSON(jsonContent: string): StoreImportData[] {
  const data = JSON.parse(jsonContent);
  if (!Array.isArray(data)) {
    throw new Error('JSON must be an array of stores');
  }
  return data as StoreImportData[];
}
