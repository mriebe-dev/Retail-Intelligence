/**
 * Global Luxury Retail Report Generator
 * Organized by Country -> City -> Street (like CH.Retail-Report.com)
 */

export interface StreetData {
  name: string;
  newsCount: number;
  topBrands: string[];
  category: string;
}

export interface CityData {
  name: string;
  country: string;
  totalNews: number;
  uniqueStreets: number;
  topStreets: StreetData[];
  allStreets: StreetData[];
}

export interface CountryData {
  name: string;
  totalNews: number;
  totalCities: number;
  totalStreets: number;
  cities: CityData[];
}

// Comprehensive street data by city
export const GLOBAL_RETAIL_STREETS: Record<string, Record<string, string[]>> = {
  // EUROPE
  Germany: {
    Berlin: [
      "Kurfürstendamm",
      "Friedrichstrasse",
      "Tauentzienstrasse",
      "Wilmersdorfer Strasse",
      "Kantstrasse",
    ],
    Munich: [
      "Maximilianstrasse",
      "Marienplatz",
      "Kaufingerstrasse",
      "Neuhauserstrasse",
      "Sendlingerstrasse",
      "Weinstrasse",
      "Dienerstrasse",
      "Perusastrasse",
      "Residenzstrasse",
      "Theatinerstrasse",
    ],
  },
  Italy: {
    Rome: [
      "Via Condotti",
      "Via del Corso",
      "Via Frattina",
      "Via Borgognona",
      "Via della Vite",
      "Piazza di Spagna",
      "Via Nazionale",
      "Via Cavour",
      "Via Sistina",
      "Via Tritone",
    ],
    Milan: [
      "Via Monte Napoleone",
      "Via della Spiga",
      "Via Sant'Andrea",
      "Via Borgospesso",
      "Galleria Vittorio Emanuele II",
      "Piazza Duomo",
      "Corso Como",
      "Corso Vercelli",
      "Corso Magenta",
      "Corso Garibaldi",
      "Via Tornabuoni",
      "Via Manzoni",
    ],
  },
  Spain: {
    Madrid: [
      "Paseo de la Castellana",
      "Gran Vía",
      "Calle Serrano",
      "Calle Goya",
      "Calle Alcalá",
      "Paseo del Prado",
      "Plaza Mayor",
      "Calle Fuencarral",
      "Calle Claudio Coello",
      "Calle Velázquez",
      "Calle Jorge Juan",
      "Calle Ortega y Gasset",
      "Paseo de Recoletos",
    ],
    Barcelona: [
      "Passeig de Gràcia",
      "Rambla",
      "Plaça Reial",
      "Carrer de Montcada",
      "Passeig de Sant Joan",
      "Avinguda Diagonal",
      "Carrer del Carme",
      "Carrer de la Boqueria",
      "Carrer Portaferrissa",
      "Carrer del Pi",
      "Carrer de Santa Anna",
      "Passeig de Colom",
      "Carrer de l'Argenteria",
    ],
  },
  Austria: {
    Vienna: [
      "Kärntner Strasse",
      "Graben",
      "Kohlmarkt",
      "Stephansplatz",
      "Neuer Markt",
      "Tuchlauben",
      "Naglergasse",
      "Ringstrasse",
      "Mariahilfer Strasse",
      "Freyung",
      "Am Hof",
    ],
  },
  "Czech Republic": {
    Prague: [
      "Old Town Square",
      "Nerudova",
      "Mostecka",
      "Celetna",
      "Parizska",
      "Wenceslas Square",
      "Na Příkopě",
      "Dlouhá",
      "Husova",
    ],
  },
  Hungary: {
    Budapest: [
      "Andrássy Avenue",
      "Váci utca",
      "Vörösmarty Square",
      "Deák Ferenc utca",
      "Ferenciek tere",
      "Petőfi Sándor utca",
      "Falk Miksa utca",
      "Szépvölgyi út",
    ],
  },
  Netherlands: {
    Amsterdam: [
      "Kalverstraat",
      "P.C. Hooftstraat",
      "Nieuwendijk",
      "Leidsestraat",
      "Pieter Cornelisz Hooftstraat",
      "Negen Straatjes",
      "Rokin",
      "Dam",
      "Warmoesstraat",
      "Spiegelgracht",
      "Herengracht",
      "Prinsengracht",
    ],
  },
  Belgium: {
    Brussels: [
      "Rue de Namur",
      "Galeries Royales",
      "Rue Neuve",
      "Rue de la Madeleine",
      "Rue de Trèves",
      "Avenue Louise",
      "Rue Royale",
      "Place Royale",
      "Rue du Marché aux Herbes",
      "Boulevard Anspach",
    ],
  },
  Portugal: {
    Lisbon: [
      "Chiado",
      "Baixa",
      "Rua Garrett",
      "Rua Aurea",
      "Rua do Carmo",
      "Avenida da Liberdade",
      "Rua do Ouro",
      "Rua da Prata",
      "Praça do Rossio",
    ],
  },
  Greece: {
    Athens: [
      "Ermou Street",
      "Syntagma",
      "Monastiraki",
      "Plaka",
      "Voukourestiou Street",
      "Stadiou Street",
      "Mitropoleos Street",
    ],
  },
  Turkey: {
    Istanbul: [
      "Istiklal Avenue",
      "Galata",
      "Taksim",
      "Beyoglu",
      "Nisantasi",
      "Bosphorus",
      "Sultanahmet",
    ],
  },
  Russia: {
    Moscow: [
      "Tverskaya Street",
      "Red Square",
      "Arbat",
      "Kuznetsky Most",
      "Petrovka Street",
      "Stoleshnikov Lane",
      "Okhotny Ryad",
    ],
  },
  Poland: {
    Warsaw: [
      "Nowy Świat",
      "Marszałkowska",
      "Krakowskie Przedmieście",
      "Chmielna",
      "Świętokrzyska",
      "Piotrkowska",
    ],
  },

  // AMERICAS
  "United States": {
    "New York": [
      "Fifth Avenue",
      "Madison Avenue",
      "Park Avenue",
      "Broadway",
      "SoHo",
      "NoHo",
      "East Village",
      "Lower East Side",
      "Chinatown",
      "Little Italy",
      "Nolita",
      "TriBeCa",
      "Financial District",
      "Wall Street",
      "Stone Street",
      "South Street Seaport",
      "Midtown",
      "Times Square",
      "Hell's Kitchen",
      "Chelsea",
      "Flatiron",
      "Gramercy Park",
      "Union Square",
      "Upper East Side",
      "Upper West Side",
      "Central Park",
      "Harlem",
      "Washington Heights",
      "Inwood",
      "Williamsburg",
    ],
    "Los Angeles": [
      "Rodeo Drive",
      "Sunset Boulevard",
      "Hollywood Boulevard",
      "Melrose Avenue",
      "Beverly Boulevard",
      "Wilshire Boulevard",
      "Third Street Promenade",
      "Downtown LA",
      "Arts District",
    ],
    "San Francisco": [
      "Union Street",
      "Market Street",
      "Fillmore Street",
      "Haight Street",
      "Valencia Street",
      "Mission District",
      "Financial District",
    ],
    Chicago: [
      "Michigan Avenue",
      "State Street",
      "North Avenue",
      "Armitage Avenue",
      "Lincoln Avenue",
    ],
    Miami: ["Lincoln Road", "Brickell", "Wynwood", "Design District"],
    Boston: ["Newbury Street", "Downtown", "Back Bay"],
    Seattle: ["Pike Place Market", "University District", "Capitol Hill"],
    Dallas: ["Uptown", "Downtown", "Highland Park"],
    Houston: ["Uptown", "Downtown", "Midtown"],
    Atlanta: ["Buckhead", "Downtown", "Midtown"],
    Denver: ["Cherry Creek", "Downtown", "LoDo"],
  },
  Canada: {
    Toronto: [
      "Bloor Street",
      "Queen Street West",
      "King Street West",
      "Yonge Street",
      "Yorkville",
    ],
    Vancouver: [
      "Robson Street",
      "Gastown",
      "Granville Street",
      "Alberni Street",
    ],
  },
  Mexico: {
    "Mexico City": [
      "Paseo de la Reforma",
      "Polanco",
      "Condesa",
      "Roma",
      "Centro Histórico",
    ],
  },
  Brazil: {
    "São Paulo": [
      "Oscar Freire Street",
      "Paulista Avenue",
      "Rua 25 de Março",
      "Rua Augusta",
    ],
  },
  Argentina: {
    "Buenos Aires": [
      "Calle Florida",
      "San Telmo",
      "La Boca",
      "Recoleta",
      "Palermo",
    ],
  },

  // ASIA
  China: {
    Beijing: [
      "Wangfujing Street",
      "Sanlitun",
      "Qianmen Street",
      "Xidan",
      "Chaoyang",
    ],
    Shanghai: [
      "Nanjing Road",
      "Huaihai Road",
      "Jing'an",
      "Pudong",
      "French Concession",
    ],
    Guangzhou: ["Beijing Road", "Liwan", "Tianhe", "Zhujiang"],
    Chengdu: ["Chunxi Road", "Taikooli", "Kuanzhai Xiangzi"],
  },
  Thailand: {
    Bangkok: [
      "Silom",
      "Sukhumvit",
      "Wireless Road",
      "Ploenchit",
      "Emporium",
      "EmQuartier",
    ],
  },
  "South Korea": {
    Seoul: [
      "Gangnam",
      "Myeongdong",
      "Insadong",
      "Hongdae",
      "Itaewon",
      "Cheongdam",
    ],
    Busan: ["Nampodong", "Seomyeon", "Gwangbok-ro"],
  },
  Philippines: {
    Manila: ["Makati", "BGC", "Quezon City", "Ortigas"],
  },
  Indonesia: {
    Jakarta: ["Senayan", "Menteng", "Blok M", "Kelapa Gading"],
  },
  Malaysia: {
    "Kuala Lumpur": [
      "Pavilion KL",
      "Bukit Bintang",
      "Midvalley",
      "Bangsar",
      "Klang Valley",
    ],
  },
  Vietnam: {
    "Ho Chi Minh City": ["Dong Khoi", "Ben Thanh", "District 1"],
  },
  Taiwan: {
    Taipei: ["Taipei 101", "Dunnan", "Xinyi", "Daan"],
  },
  India: {
    Mumbai: ["Bandra", "Fort", "Colaba", "Worli"],
    Delhi: ["Connaught Place", "Khan Market", "DLF Cyber Hub"],
  },

  // MIDDLE EAST & AFRICA
  "United Arab Emirates": {
    Dubai: [
      "Dubai Mall",
      "Gold Souk",
      "Spice Souk",
      "The Galleria",
      "Mall of the Emirates",
      "Ibn Battuta Mall",
    ],
    "Abu Dhabi": ["The Galleria", "Saadiyat", "Downtown Abu Dhabi"],
  },
  Qatar: {
    Doha: ["The Pearl", "Lusail", "West Bay", "Corniche"],
  },
  "Saudi Arabia": {
    Riyadh: ["Riyadh Gallery", "Downtown", "Al Nakheel"],
    Jeddah: ["Red Sea Mall", "Downtown", "Corniche"],
  },
  Egypt: {
    Cairo: ["Khan El-Khalili", "Downtown", "Heliopolis"],
  },
  Morocco: {
    Casablanca: ["Anfa", "Downtown", "Medina"],
  },
  "South Africa": {
    Johannesburg: ["Sandton", "Rosebank", "Parkhurst"],
    "Cape Town": ["V&A Waterfront", "Camps Bay", "Constantia Nek"],
  },
  Nigeria: {
    Lagos: ["Victoria Island", "Ikoyi", "Lekki"],
  },
  Kenya: {
    Nairobi: ["Westlands", "Downtown", "Karen"],
  },

  // OCEANIA
  Australia: {
    Sydney: [
      "Pitt Street",
      "Double Bay",
      "Paddington",
      "Surry Hills",
      "Newtown",
    ],
    Melbourne: [
      "Collins Street",
      "Chapel Street",
      "Toorak Road",
      "South Yarra",
    ],
    Brisbane: ["Queen Street", "South Bank", "Fortitude Valley"],
    Perth: ["Hay Street", "Northbridge", "Claremont"],
  },
  "New Zealand": {
    Auckland: ["Queen Street", "Newmarket", "Ponsonby", "Parnell"],
  },
};

/**
 * Get all countries with their data
 */
export function getAllCountries(): string[] {
  return Object.keys(GLOBAL_RETAIL_STREETS).sort();
}

/**
 * Get all cities for a country
 */
export function getCitiesByCountry(country: string): string[] {
  return Object.keys(GLOBAL_RETAIL_STREETS[country] || {}).sort();
}

/**
 * Get all streets for a city
 */
export function getStreetsByCity(country: string, city: string): string[] {
  return GLOBAL_RETAIL_STREETS[country]?.[city] || [];
}

/**
 * Get statistics for country
 */
export function getCountryStats(country: string): {
  country: string;
  cities: number;
  streets: number;
  totalStreets: string[];
} {
  const cities = getCitiesByCountry(country);
  const allStreets = new Set<string>();

  cities.forEach((city) => {
    const streets = getStreetsByCity(country, city);
    streets.forEach((street) => allStreets.add(street));
  });

  return {
    country,
    cities: cities.length,
    streets: allStreets.size,
    totalStreets: Array.from(allStreets).sort(),
  };
}

/**
 * Get statistics for city
 */
export function getCityStats(country: string, city: string): {
  country: string;
  city: string;
  streets: number;
  streetList: string[];
} {
  const streets = getStreetsByCity(country, city);

  return {
    country,
    city,
    streets: streets.length,
    streetList: streets,
  };
}

/**
 * Generate full report structure
 */
export function generateFullReport(): CountryData[] {
  const countries = getAllCountries();

  return countries.map((country) => {
    const cities = getCitiesByCountry(country);
    const countryStats = getCountryStats(country);

    return {
      name: country,
      totalNews: 0, // Will be filled from database
      totalCities: cities.length,
      totalStreets: countryStats.streets,
      cities: cities.map((city) => {
        const cityStats = getCityStats(country, city);

        return {
          name: city,
          country,
          totalNews: 0, // Will be filled from database
          uniqueStreets: cityStats.streets,
          topStreets: [], // Will be filled from database
          allStreets: cityStats.streetList.map((street) => ({
            name: street,
            newsCount: 0, // Will be filled from database
            topBrands: [],
            category: "Luxury Retail",
          })),
        };
      }),
    };
  });
}

/**
 * Export report as structured data
 */
export function exportReportAsJSON(): string {
  const report = generateFullReport();
  return JSON.stringify(report, null, 2);
}

/**
 * Export report as markdown
 */
export function exportReportAsMarkdown(): string {
  const countries = getAllCountries();
  let markdown = "# 🌍 Global Luxury Retail Report\n\n";
  markdown += `**Last Updated:** ${new Date().toLocaleDateString()}\n\n`;
  markdown += `**Coverage:** ${countries.length} Countries | ${countries.reduce((sum, c) => sum + getCitiesByCountry(c).length, 0)} Cities | ${countries.reduce((sum, c) => sum + getCountryStats(c).streets, 0)} Premium Streets\n\n`;
  markdown += "---\n\n";

  countries.forEach((country) => {
    const countryStats = getCountryStats(country);
    const cities = getCitiesByCountry(country);

    markdown += `## 🌐 ${country}\n\n`;
    markdown += `**Statistics:** ${countryStats.cities} Cities | ${countryStats.streets} Premium Streets\n\n`;

    cities.forEach((city) => {
      const cityStats = getCityStats(country, city);
      markdown += `### 📍 ${city}\n\n`;
      markdown += `**Premium Streets:** ${cityStats.streets}\n\n`;
      markdown += `| Street | Category |\n`;
      markdown += `|--------|----------|\n`;

      cityStats.streetList.forEach((street) => {
        markdown += `| ${street} | Luxury Retail |\n`;
      });

      markdown += `\n`;
    });

    markdown += `---\n\n`;
  });

  return markdown;
}
