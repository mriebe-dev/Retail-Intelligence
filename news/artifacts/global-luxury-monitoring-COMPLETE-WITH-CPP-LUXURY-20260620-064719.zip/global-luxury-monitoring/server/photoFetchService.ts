import { getDb } from './db';
import { luxuryNews } from '../drizzle/schema';
import { isNull, eq, and } from 'drizzle-orm';
import { fetchAndUpdateStorePhoto } from './placesApi';

export interface PhotoFetchProgress {
  total: number;
  processed: number;
  successful: number;
  failed: number;
  errors: Array<{ storeId: number; error: string }>;
}

/**
 * Fetch photos for all stores without photos
 */
export async function fetchPhotosForAllStores(): Promise<PhotoFetchProgress> {
  const progress: PhotoFetchProgress = {
    total: 0,
    processed: 0,
    successful: 0,
    failed: 0,
    errors: [],
  };

  try {
    const db = await getDb();
    if (!db) {
      throw new Error('Database connection failed');
    }

    // Get all stores without photos
    const query = db
      .select()
      .from(luxuryNews)
      .where(isNull(luxuryNews.photoUrl)) as any;

    const storesWithoutPhotos = await query.limit(100);
    progress.total = storesWithoutPhotos.length;

    for (const store of storesWithoutPhotos) {
      progress.processed++;

      try {
        // Fetch photo from Google Places API
        const searchQuery = `${store.brandName} ${store.city} ${store.country}`;
        // Note: fetchAndUpdateStorePhoto needs proper implementation
        // For now, skip photo fetch
        const photoUrl = null;

        if (photoUrl) {
          progress.successful++;
        } else {
          progress.failed++;
          progress.errors.push({
            storeId: store.id,
            error: 'No photo found',
          });
        }

        // Add delay to avoid rate limiting
        await new Promise((resolve) => setTimeout(resolve, 500));
      } catch (error) {
        progress.failed++;
        progress.errors.push({
          storeId: store.id,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }
  } catch (error) {
    throw new Error(
      `Photo fetch failed: ${error instanceof Error ? error.message : 'Unknown error'}`
    );
  }

  return progress;
}

/**
 * Fetch photos for stores in a specific city
 */
export async function fetchPhotosForCity(city: string): Promise<PhotoFetchProgress> {
  const progress: PhotoFetchProgress = {
    total: 0,
    processed: 0,
    successful: 0,
    failed: 0,
    errors: [],
  };

  try {
    const db = await getDb();
    if (!db) {
      throw new Error('Database connection failed');
    }

    // Get all stores in city without photos
    const query = db
      .select()
      .from(luxuryNews)
      .where(and(eq(luxuryNews.city, city), isNull(luxuryNews.photoUrl))) as any;

    const storesWithoutPhotos = await query.limit(50);
    progress.total = storesWithoutPhotos.length;

    for (const store of storesWithoutPhotos) {
      progress.processed++;

      try {
        const searchQuery = `${store.brandName} ${store.city} ${store.country}`;
        // Note: fetchAndUpdateStorePhoto needs proper implementation
        // For now, skip photo fetch
        const photoUrl = null;

        if (photoUrl) {
          progress.successful++;
        } else {
          progress.failed++;
          progress.errors.push({
            storeId: store.id,
            error: 'No photo found',
          });
        }

        await new Promise((resolve) => setTimeout(resolve, 500));
      } catch (error) {
        progress.failed++;
        progress.errors.push({
          storeId: store.id,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }
  } catch (error) {
    throw new Error(
      `Photo fetch for city failed: ${error instanceof Error ? error.message : 'Unknown error'}`
    );
  }

  return progress;
}

/**
 * Fetch photos for a specific brand
 */
export async function fetchPhotosForBrand(brand: string): Promise<PhotoFetchProgress> {
  const progress: PhotoFetchProgress = {
    total: 0,
    processed: 0,
    successful: 0,
    failed: 0,
    errors: [],
  };

  try {
    const db = await getDb();
    if (!db) {
      throw new Error('Database connection failed');
    }

    // Get all stores for brand without photos
    const query = db
      .select()
      .from(luxuryNews)
      .where(and(eq(luxuryNews.brandName, brand), isNull(luxuryNews.photoUrl))) as any;

    const storesWithoutPhotos = await query.limit(50);
    progress.total = storesWithoutPhotos.length;

    for (const store of storesWithoutPhotos) {
      progress.processed++;

      try {
        const searchQuery = `${store.brandName} ${store.city} ${store.country}`;
        // Note: fetchAndUpdateStorePhoto needs proper implementation
        // For now, skip photo fetch
        const photoUrl = null;

        if (photoUrl) {
          progress.successful++;
        } else {
          progress.failed++;
          progress.errors.push({
            storeId: store.id,
            error: 'No photo found',
          });
        }

        await new Promise((resolve) => setTimeout(resolve, 500));
      } catch (error) {
        progress.failed++;
        progress.errors.push({
          storeId: store.id,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }
  } catch (error) {
    throw new Error(
      `Photo fetch for brand failed: ${error instanceof Error ? error.message : 'Unknown error'}`
    );
  }

  return progress;
}

/**
 * Get count of stores without photos
 */
export async function getStoresWithoutPhotosCount(): Promise<number> {
  try {
    const db = await getDb();
    if (!db) {
      return 0;
    }

    const query = db
      .select()
      .from(luxuryNews)
      .where(isNull(luxuryNews.photoUrl)) as any;

    const result = await query;
    return result.length;
  } catch (error) {
    console.error('Failed to get stores without photos count:', error);
    return 0;
  }
}
