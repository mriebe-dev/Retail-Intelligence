import { describe, it, expect } from "vitest";
import {
  extractLocationFromAddress,
  projectNewsOntoStreet,
  projectNewsInParallel,
  sortProjectionsByStreet,
  groupProjectionsByStreet,
  calculateStreetStatistics,
} from "./newsProjection";

describe("News Projection Service", () => {
  describe("extractLocationFromAddress", () => {
    it("should extract city from address", () => {
      const result = extractLocationFromAddress(
        "Bahnhofstrasse 50, 8001 Zurich, Switzerland"
      );
      expect(result.city).toBe("Zurich");
    });

    it("should extract street from address", () => {
      const result = extractLocationFromAddress(
        "Bahnhofstrasse 50, 8001 Zurich, Switzerland"
      );
      expect(result.street).toBe("Bahnhofstrasse");
    });

    it("should extract both city and street", () => {
      const result = extractLocationFromAddress(
        "Rue du Rhône 50, 1204 Geneva, Switzerland"
      );
      expect(result.city).toBe("Geneva");
      expect(result.street).toBe("Rue du Rhône");
    });

    it("should return null for unknown city", () => {
      const result = extractLocationFromAddress(
        "Unknown Street 50, Unknown City"
      );
      expect(result.city).toBeNull();
    });

    it("should handle Paris address", () => {
      const result = extractLocationFromAddress(
        "Champs-Élysées 100, Paris, France"
      );
      expect(result.city).toBe("Paris");
      expect(result.street).toBe("Champs-Élysées");
    });
  });

  describe("projectNewsOntoStreet", () => {
    it("should project news onto Bahnhofstrasse Zurich", () => {
      const projected = projectNewsOntoStreet(
        "news-1",
        "Rolex",
        "Bahnhofstrasse 50, Zurich",
        47.3773,
        8.5391,
        new Date("2026-03-12"),
        "new"
      );

      expect(projected).toBeDefined();
      expect(projected?.city).toBe("Zurich");
      expect(projected?.streetName).toBe("Bahnhofstrasse");
      expect(projected?.projectionConfidence).toBeGreaterThan(0.5);
    });

    it("should project news onto Rue du Rhône Geneva", () => {
      const projected = projectNewsOntoStreet(
        "news-2",
        "Cartier",
        "Rue du Rhône 50, Geneva",
        46.1954,
        6.1424,
        new Date("2026-03-12"),
        "featured"
      );

      expect(projected).toBeDefined();
      expect(projected?.city).toBe("Geneva");
      expect(projected?.streetName).toBe("Rue du Rhône");
    });

    it("should return null for unknown city", () => {
      const projected = projectNewsOntoStreet(
        "news-3",
        "Brand",
        "Unknown Street, Unknown City",
        0,
        0,
        new Date("2026-03-12"),
        "new"
      );

      expect(projected).toBeNull();
    });

    it("should find closest street when exact street not found", () => {
      const projected = projectNewsOntoStreet(
        "news-4",
        "Dior",
        "Zurich",
        47.3773,
        8.5391,
        new Date("2026-03-12"),
        "new"
      );

      expect(projected).toBeDefined();
      expect(projected?.city).toBe("Zurich");
      expect(projected?.streetName).toBeDefined();
    });

    it("should have valid projection confidence", () => {
      const projected = projectNewsOntoStreet(
        "news-5",
        "Gucci",
        "Bahnhofstrasse 50, Zurich",
        47.3773,
        8.5391,
        new Date("2026-03-12"),
        "new"
      );

      expect(projected?.projectionConfidence).toBeGreaterThanOrEqual(0);
      expect(projected?.projectionConfidence).toBeLessThanOrEqual(1);
    });
  });

  describe("projectNewsInParallel", () => {
    it("should project multiple news items", () => {
      const newsItems = [
        {
          id: "news-1",
          brand: "Rolex",
          address: "Bahnhofstrasse 50, Zurich",
          latitude: 47.3773,
          longitude: 8.5391,
          date: new Date("2026-03-12"),
          status: "new" as const,
        },
        {
          id: "news-2",
          brand: "Cartier",
          address: "Rue du Rhône 50, Geneva",
          latitude: 46.1954,
          longitude: 6.1424,
          date: new Date("2026-03-12"),
          status: "featured" as const,
        },
      ];

      const result = projectNewsInParallel(newsItems);

      expect(result.totalNews).toBe(2);
      expect(result.successfulProjections).toBe(2);
      expect(result.failedProjections).toBe(0);
      expect(result.projections.length).toBe(2);
    });

    it("should handle mixed success and failure", () => {
      const newsItems = [
        {
          id: "news-1",
          brand: "Rolex",
          address: "Bahnhofstrasse 50, Zurich",
          latitude: 47.3773,
          longitude: 8.5391,
          date: new Date("2026-03-12"),
          status: "new" as const,
        },
        {
          id: "news-2",
          brand: "Unknown",
          address: "Unknown Street, Unknown City",
          latitude: 0,
          longitude: 0,
          date: new Date("2026-03-12"),
          status: "new" as const,
        },
      ];

      const result = projectNewsInParallel(newsItems);

      expect(result.totalNews).toBe(2);
      expect(result.successfulProjections).toBe(1);
      expect(result.failedProjections).toBe(1);
    });

    it("should handle empty array", () => {
      const result = projectNewsInParallel([]);

      expect(result.totalNews).toBe(0);
      expect(result.successfulProjections).toBe(0);
      expect(result.failedProjections).toBe(0);
    });
  });

  describe("sortProjectionsByStreet", () => {
    it("should sort by city then street then distance", () => {
      const projections = [
        {
          newsId: "1",
          brand: "Rolex",
          city: "Zurich",
          streetName: "Bahnhofstrasse",
          latitude: 47.3773,
          longitude: 8.5391,
          distanceAlongStreet: 500,
          closestStreetDistance: 0,
          projectionConfidence: 0.9,
          date: new Date(),
          status: "new" as const,
        },
        {
          newsId: "2",
          brand: "Cartier",
          city: "Zurich",
          streetName: "Bahnhofstrasse",
          latitude: 47.3773,
          longitude: 8.5391,
          distanceAlongStreet: 100,
          closestStreetDistance: 0,
          projectionConfidence: 0.9,
          date: new Date(),
          status: "new" as const,
        },
      ];

      const sorted = sortProjectionsByStreet(projections);

      expect(sorted[0].distanceAlongStreet).toBe(100);
      expect(sorted[1].distanceAlongStreet).toBe(500);
    });
  });

  describe("groupProjectionsByStreet", () => {
    it("should group by street", () => {
      const projections = [
        {
          newsId: "1",
          brand: "Rolex",
          city: "Zurich",
          streetName: "Bahnhofstrasse",
          latitude: 47.3773,
          longitude: 8.5391,
          distanceAlongStreet: 500,
          closestStreetDistance: 0,
          projectionConfidence: 0.9,
          date: new Date(),
          status: "new" as const,
        },
        {
          newsId: "2",
          brand: "Cartier",
          city: "Geneva",
          streetName: "Rue du Rhône",
          latitude: 46.1954,
          longitude: 6.1424,
          distanceAlongStreet: 300,
          closestStreetDistance: 0,
          projectionConfidence: 0.9,
          date: new Date(),
          status: "new" as const,
        },
      ];

      const grouped = groupProjectionsByStreet(projections);

      expect(grouped.size).toBe(2);
      expect(grouped.get("Zurich/Bahnhofstrasse")?.length).toBe(1);
      expect(grouped.get("Geneva/Rue du Rhône")?.length).toBe(1);
    });

    it("should sort items within each group by distance", () => {
      const projections = [
        {
          newsId: "1",
          brand: "Rolex",
          city: "Zurich",
          streetName: "Bahnhofstrasse",
          latitude: 47.3773,
          longitude: 8.5391,
          distanceAlongStreet: 500,
          closestStreetDistance: 0,
          projectionConfidence: 0.9,
          date: new Date(),
          status: "new" as const,
        },
        {
          newsId: "2",
          brand: "Cartier",
          city: "Zurich",
          streetName: "Bahnhofstrasse",
          latitude: 47.3773,
          longitude: 8.5391,
          distanceAlongStreet: 100,
          closestStreetDistance: 0,
          projectionConfidence: 0.9,
          date: new Date(),
          status: "new" as const,
        },
      ];

      const grouped = groupProjectionsByStreet(projections);
      const items = grouped.get("Zurich/Bahnhofstrasse");

      expect(items?.[0].distanceAlongStreet).toBe(100);
      expect(items?.[1].distanceAlongStreet).toBe(500);
    });
  });

  describe("calculateStreetStatistics", () => {
    it("should calculate statistics for streets", () => {
      const projections = [
        {
          newsId: "1",
          brand: "Rolex",
          city: "Zurich",
          streetName: "Bahnhofstrasse",
          latitude: 47.3773,
          longitude: 8.5391,
          distanceAlongStreet: 500,
          closestStreetDistance: 0,
          projectionConfidence: 0.9,
          date: new Date("2026-03-12"),
          status: "new" as const,
        },
        {
          newsId: "2",
          brand: "Cartier",
          city: "Zurich",
          streetName: "Bahnhofstrasse",
          latitude: 47.3773,
          longitude: 8.5391,
          distanceAlongStreet: 100,
          closestStreetDistance: 0,
          projectionConfidence: 0.8,
          date: new Date("2026-03-11"),
          status: "new" as const,
        },
      ];

      const stats = calculateStreetStatistics(projections);
      const bahnhofStats = stats.get("Zurich/Bahnhofstrasse");

      expect(bahnhofStats?.count).toBe(2);
      expect(bahnhofStats?.brands.size).toBe(2);
      expect(bahnhofStats?.avgConfidence).toBeCloseTo(0.85, 2);
    });

    it("should track date range", () => {
      const date1 = new Date("2026-03-10");
      const date2 = new Date("2026-03-15");

      const projections = [
        {
          newsId: "1",
          brand: "Rolex",
          city: "Zurich",
          streetName: "Bahnhofstrasse",
          latitude: 47.3773,
          longitude: 8.5391,
          distanceAlongStreet: 500,
          closestStreetDistance: 0,
          projectionConfidence: 0.9,
          date: date1,
          status: "new" as const,
        },
        {
          newsId: "2",
          brand: "Cartier",
          city: "Zurich",
          streetName: "Bahnhofstrasse",
          latitude: 47.3773,
          longitude: 8.5391,
          distanceAlongStreet: 100,
          closestStreetDistance: 0,
          projectionConfidence: 0.8,
          date: date2,
          status: "new" as const,
        },
      ];

      const stats = calculateStreetStatistics(projections);
      const bahnhofStats = stats.get("Zurich/Bahnhofstrasse");

      expect(bahnhofStats?.dateRange.min).toEqual(date1);
      expect(bahnhofStats?.dateRange.max).toEqual(date2);
    });
  });
});
