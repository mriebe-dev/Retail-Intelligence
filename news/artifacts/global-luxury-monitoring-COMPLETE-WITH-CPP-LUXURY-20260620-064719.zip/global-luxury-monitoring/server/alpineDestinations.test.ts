import { describe, it, expect } from "vitest";

describe("AlpineDestinations", () => {
  const ALPINE_DESTINATIONS = [
    {
      slug: "st-moritz",
      name: "St. Moritz",
      stats: { stores: 24, flagships: 3, avgRent: "CHF 2,800/m²", vacancy: "1.5%" },
    },
    {
      slug: "gstaad",
      name: "Gstaad",
      stats: { stores: 18, flagships: 2, avgRent: "CHF 2,500/m²", vacancy: "2.0%" },
    },
    {
      slug: "zermatt",
      name: "Zermatt",
      stats: { stores: 12, flagships: 1, avgRent: "CHF 2,200/m²", vacancy: "2.5%" },
    },
    {
      slug: "interlaken",
      name: "Interlaken",
      stats: { stores: 16, flagships: 2, avgRent: "CHF 2,000/m²", vacancy: "3.0%" },
    },
  ];

  it("should have 4 alpine destinations", () => {
    expect(ALPINE_DESTINATIONS).toHaveLength(4);
  });

  it("should have correct destination names", () => {
    const names = ALPINE_DESTINATIONS.map((d) => d.name);
    expect(names).toEqual(["St. Moritz", "Gstaad", "Zermatt", "Interlaken"]);
  });

  it("should have correct slugs", () => {
    const slugs = ALPINE_DESTINATIONS.map((d) => d.slug);
    expect(slugs).toEqual(["st-moritz", "gstaad", "zermatt", "interlaken"]);
  });

  it("should have valid store counts for each destination", () => {
    ALPINE_DESTINATIONS.forEach((destination) => {
      expect(destination.stats.stores).toBeGreaterThan(0);
      expect(destination.stats.stores).toBeLessThan(100);
    });
  });

  it("should have valid flagship store counts", () => {
    ALPINE_DESTINATIONS.forEach((destination) => {
      expect(destination.stats.flagships).toBeGreaterThanOrEqual(1);
      expect(destination.stats.flagships).toBeLessThanOrEqual(5);
    });
  });

  it("should have valid vacancy percentages", () => {
    ALPINE_DESTINATIONS.forEach((destination) => {
      const vacancy = parseFloat(destination.stats.vacancy);
      expect(vacancy).toBeGreaterThan(0);
      expect(vacancy).toBeLessThan(10);
    });
  });

  it("should have valid rent prices", () => {
    ALPINE_DESTINATIONS.forEach((destination) => {
      expect(destination.stats.avgRent).toMatch(/CHF \d+,\d+\/m²/);
    });
  });

  it("should have St. Moritz as most expensive", () => {
    const stMoritzRent = 2800;
    const otherRents = ALPINE_DESTINATIONS.filter((d) => d.slug !== "st-moritz").map(
      (d) => parseInt(d.stats.avgRent.match(/\d+/)?.[0] || "0") * 100
    );

    otherRents.forEach((rent) => {
      expect(stMoritzRent * 100).toBeGreaterThan(rent);
    });
  });

  it("should have Interlaken as least expensive", () => {
    const interlaken = ALPINE_DESTINATIONS.find((d) => d.slug === "interlaken");
    const others = ALPINE_DESTINATIONS.filter((d) => d.slug !== "interlaken");

    const interlakenRent = parseInt(interlaken?.stats.avgRent.match(/\d+/)?.[0] || "0");
    others.forEach((other) => {
      const otherRent = parseInt(other.stats.avgRent.match(/\d+/)?.[0] || "0");
      expect(interlakenRent).toBeLessThanOrEqual(otherRent);
    });
  });

  it("should have correct total stores across all destinations", () => {
    const totalStores = ALPINE_DESTINATIONS.reduce(
      (sum, d) => sum + d.stats.stores,
      0
    );
    expect(totalStores).toBe(70); // 24 + 18 + 12 + 16
  });

  it("should have correct total flagship stores", () => {
    const totalFlagships = ALPINE_DESTINATIONS.reduce(
      (sum, d) => sum + d.stats.flagships,
      0
    );
    expect(totalFlagships).toBe(8); // 3 + 2 + 1 + 2
  });

  it("should sort destinations by store count descending", () => {
    const sorted = [...ALPINE_DESTINATIONS].sort(
      (a, b) => b.stats.stores - a.stats.stores
    );
    expect(sorted[0].name).toBe("St. Moritz");
    expect(sorted[sorted.length - 1].name).toBe("Zermatt");
  });
});
