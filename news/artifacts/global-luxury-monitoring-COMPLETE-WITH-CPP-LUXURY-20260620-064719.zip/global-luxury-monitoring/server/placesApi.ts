import { z } from 'zod';
import { storagePut } from './storage';
import { ENV } from './_core/env';
import { getDb } from './db';
import { luxuryNews, storePhotos } from '../drizzle/schema';
import { eq, and, isNull, SQL } from 'drizzle-orm';

/**
 * Google Places API Integration for fetching store photos, opening hours, and details
 * Uses the Manus built-in Forge API for Google Places
 */

export const placeDetailsSchema = z.object({
  name: z.string(),
  address: z.string(),
  photos: z.array(z.string()).optional(),
  openingHours: z.array(z.string()).optional(),
  website: z.string().optional(),
  phoneNumber: z.string().optional(),
  rating: z.number().optional(),
  reviews: z.number().optional(),
  squareMeters: z.number().optional(),
});

export type PlaceDetails = z.infer<typeof placeDetailsSchema>;

/**
 * Fetch store details and photos from Google Places API via Manus Forge
 */
export async function fetchPlaceDetails(storeName: string, address: string): Promise<PlaceDetails> {
  try {
    console.log(`[Places API] Fetching details for ${storeName} at ${address}`);

    // For now, return a placeholder structure
    // In production, this would integrate with the Manus built-in Forge API
    // which provides access to Google Places API
    
    const placeDetails: PlaceDetails = {
      name: storeName,
      address: address,
      photos: [],
      openingHours: [],
      website: undefined,
      phoneNumber: undefined,
      rating: undefined,
      reviews: undefined,
      squareMeters: undefined,
    };

    console.log(`[Places API] Returning placeholder for ${storeName}`);
    return placeDetails;
  } catch (error) {
    console.error(`[Places API] Failed to fetch place details for ${storeName}:`, error);
    throw new Error(`Failed to fetch place details: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Extract square meters from place details (estimated from Google Places data)
 */
export function extractSquareMeters(placeDetails: PlaceDetails): number | undefined {
  // In production, this would extract from Google Places API response
  // For now, return undefined
  return placeDetails.squareMeters;
}

/**
 * Extract opening hours from place details
 */
export function extractOpeningHours(placeDetails: PlaceDetails): Record<string, string> {
  const hours: Record<string, string> = {};
  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  if (placeDetails.openingHours) {
    placeDetails.openingHours.forEach((hour, index) => {
      if (index < daysOfWeek.length) {
        hours[daysOfWeek[index]] = hour;
      }
    });
  }

  return hours;
}

/**
 * Upload photo to S3 and return URL
 */
export async function uploadPhotoToS3(photoUrl: string, storeName: string, index: number): Promise<string> {
  try {
    console.log(`[Storage] Uploading photo ${index} for ${storeName}`);

    // Fetch the photo from URL
    const response = await fetch(photoUrl);
    if (!response.ok) {
      throw new Error(`Failed to fetch photo: ${response.statusText}`);
    }

    const buffer = await response.arrayBuffer();
    
    // Generate unique filename
    const fileName = `store-photos/${storeName.replace(/\s+/g, '-').toLowerCase()}-${index}-${Date.now()}.jpg`;
    
    // Upload to S3
    const { url } = await storagePut(fileName, Buffer.from(buffer), 'image/jpeg');
    
    console.log(`[Storage] Photo uploaded successfully: ${url}`);
    return url;
  } catch (error) {
    console.error(`[Storage] Failed to upload photo for ${storeName}:`, error);
    throw new Error(`Failed to upload photo: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Batch fetch and upload photos for multiple stores
 */
export async function batchFetchAndUploadPhotos(
  stores: Array<{ name: string; address: string; id: string }>
): Promise<Array<{ storeId: string; photoUrls: string[] }>> {
  const results: Array<{ storeId: string; photoUrls: string[] }> = [];

  console.log(`[Places API] Batch fetching photos for ${stores.length} stores`);

  for (const store of stores) {
    try {
      const placeDetails = await fetchPlaceDetails(store.name, store.address);
      const photoUrls: string[] = [];

      if (placeDetails.photos && placeDetails.photos.length > 0) {
        for (let i = 0; i < Math.min(placeDetails.photos.length, 3); i++) {
          try {
            const s3Url = await uploadPhotoToS3(placeDetails.photos[i], store.name, i);
            photoUrls.push(s3Url);
          } catch (photoError) {
            console.error(`[Storage] Failed to upload photo ${i} for ${store.name}:`, photoError);
          }
        }
      }

      results.push({
        storeId: store.id,
        photoUrls,
      });
    } catch (storeError) {
      console.error(`[Places API] Failed to process store ${store.name}:`, storeError);
      results.push({
        storeId: store.id,
        photoUrls: [],
      });
    }
  }

  console.log(`[Places API] Batch fetch completed: ${results.filter(r => r.photoUrls.length > 0).length}/${stores.length} stores with photos`);
  return results;
}

/**
 * Fetch and update store photo in database
 */
export async function fetchAndUpdateStorePhoto(
  storeId: string,
  storeName: string,
  address: string,
  city: string,
  street?: string
): Promise<{ success: boolean; photoUrl?: string; error?: string }> {
  try {
    console.log(`[Places API] Fetching and updating photo for ${storeName} (${storeId})`);

    // Fetch place details
    const placeDetails = await fetchPlaceDetails(storeName, address);

    if (!placeDetails.photos || placeDetails.photos.length === 0) {
      console.warn(`[Places API] No photos found for ${storeName}`);
      return { success: false, error: 'No photos found' };
    }

    // Upload first photo to S3
    const photoUrl = await uploadPhotoToS3(placeDetails.photos[0], storeName, 0);

      // Update database with photo URL
    const db = await getDb();
    if (db) {
      try {
        const whereConditions = [eq(luxuryNews.brandName, storeName), eq(luxuryNews.city, city)];
        if (street) {
          whereConditions.push(eq(luxuryNews.street, street));
        }
        await db
          .update(luxuryNews)
          .set({
            photoUrl: photoUrl,
            updatedAt: new Date(),
          })
          .where(and(...whereConditions));

        console.log(`[Places API] Updated database with photo URL: ${photoUrl}`);
      } catch (dbError) {
        console.error('[Places API] Failed to update database:', dbError);
      }
    }

    console.log(`[Places API] Successfully fetched and uploaded photo for ${storeName}`);
    return { success: true, photoUrl };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error(`[Places API] Failed to fetch and update photo for ${storeName}:`, errorMessage);
    return { success: false, error: errorMessage };
  }
}

/**
 * Batch fetch and update store details (photos, opening hours, square meters)
 */
export async function batchUpdateStoreDetails(
  stores: Array<{
    id: string;
    brandName: string;
    city: string;
    street: string;
    address: string;
  }>
): Promise<{
  totalStores: number;
  successfulUpdates: number;
  failedUpdates: number;
  results: Array<{
    storeId: string;
    brandName: string;
    photoUrl?: string;
    openingHours?: Record<string, string>;
    squareMeters?: number;
    error?: string;
  }>;
}> {
  const results: Array<{
    storeId: string;
    brandName: string;
    photoUrl?: string;
    openingHours?: Record<string, string>;
    squareMeters?: number;
    error?: string;
  }> = [];

  let successfulUpdates = 0;
  let failedUpdates = 0;

  console.log(`[Places API] Starting batch update for ${stores.length} stores`);

  for (const store of stores) {
    try {
      console.log(`[Places API] Processing ${store.brandName} in ${store.city}`);

      // Fetch place details
      const placeDetails = await fetchPlaceDetails(store.brandName, store.address);

      let photoUrl: string | undefined;
      let openingHours: Record<string, string> | undefined;
      let squareMeters: number | undefined;

      // Upload photo if available
      if (placeDetails.photos && placeDetails.photos.length > 0) {
        try {
          photoUrl = await uploadPhotoToS3(placeDetails.photos[0], store.brandName, 0);
          successfulUpdates++;
        } catch (photoError) {
          console.error(`[Places API] Failed to upload photo for ${store.brandName}:`, photoError);
          failedUpdates++;
        }
      } else {
        failedUpdates++;
      }

      // Extract opening hours
      if (placeDetails.openingHours) {
        openingHours = extractOpeningHours(placeDetails);
      }

      // Extract square meters
      squareMeters = extractSquareMeters(placeDetails);

      // Update database
      const db = await getDb();
      if (db) {
        try {
          const whereConditions = [eq(luxuryNews.brandName, store.brandName), eq(luxuryNews.city, store.city)];
          if (store.street) {
            whereConditions.push(eq(luxuryNews.street, store.street));
          }
          
          const updateData: any = {
            updatedAt: new Date(),
          };
          
          if (photoUrl) {
            updateData.photoUrl = photoUrl;
          }
          
          if (openingHours) {
            updateData.openingHours = JSON.stringify(openingHours);
          }
          
          if (squareMeters) {
            updateData.squareMeters = squareMeters;
          }
          
          await db
            .update(luxuryNews)
            .set(updateData)
            .where(and(...whereConditions));

          console.log(`[Places API] Updated ${store.brandName} in database with photo, hours, and size`);
        } catch (dbError) {
          console.error(`[Places API] Failed to update database for ${store.brandName}:`, dbError);
        }
      }

      results.push({
        storeId: store.id,
        brandName: store.brandName,
        photoUrl,
        openingHours,
        squareMeters,
      });
    } catch (storeError) {
      const errorMessage = storeError instanceof Error ? storeError.message : 'Unknown error';
      console.error(`[Places API] Failed to process ${store.brandName}:`, errorMessage);
      failedUpdates++;
      results.push({
        storeId: store.id,
        brandName: store.brandName,
        error: errorMessage,
      });
    }
  }

  console.log(
    `[Places API] Batch update completed: ${successfulUpdates} successful, ${failedUpdates} failed`
  );

  return {
    totalStores: stores.length,
    successfulUpdates,
    failedUpdates,
    results,
  };
}

/**
 * Get all stores that need photo updates
 */
export async function getStoresNeedingPhotos(): Promise<
  Array<{
    id: string;
    brandName: string;
    city: string;
    street: string;
    address: string;
  }>
> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn('[Places API] Database not available');
      return [];
    }

    // Query stores without photos
    const storesWithoutPhotos = await db
      .select()
      .from(luxuryNews)
      .where(isNull(luxuryNews.photoUrl));

    console.log(`[Places API] Found ${storesWithoutPhotos.length} stores without photos`);

    return storesWithoutPhotos.map((store) => ({
      id: store.id.toString(),
      brandName: store.brandName,
      city: store.city,
      street: store.street || '',
      address: store.street || '',
    }));
  } catch (error) {
    console.error('[Places API] Failed to get stores needing photos:', error);
    return [];
  }
}
