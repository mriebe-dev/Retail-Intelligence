import { getDb } from "./db";
import { luxuryNews } from "../drizzle/schema";
import { eq, and, gte, lte, sql } from "drizzle-orm";

/**
 * Analytics Service
 * Provides market insights and trend analysis for luxury retail
 */

export interface OpeningTrend {
  date: string;
  count: number;
  cumulative: number;
}

export interface BrandStats {
  brand: string;
  openings: number;
  percentage: number;
}

export interface CityStats {
  city: string;
  openings: number;
  percentage: number;
}

export interface StreetStats {
  street: string;
  city: string;
  openings: number;
  brands: number;
}

export interface CategoryStats {
  category: string;
  count: number;
  percentage: number;
}

export interface AnalyticsOverview {
  totalOpenings: number;
  totalBrands: number;
  totalCities: number;
  totalStreets: number;
  dateRange: {
    start: string;
    end: string;
  };
}

/**
 * Get opening trends by month
 */
export async function getOpeningTrends(
  startDate?: string,
  endDate?: string
): Promise<OpeningTrend[]> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[Analytics] Database not available");
      return [];
    }

    let query = db
      .select({
        date: sql<string>`DATE_FORMAT(${luxuryNews.date}, '%Y-%m')`,
        count: sql<number>`COUNT(*) as count`,
      })
      .from(luxuryNews)
      .groupBy(sql`DATE_FORMAT(${luxuryNews.date}, '%Y-%m')`)
      .orderBy(sql`DATE_FORMAT(${luxuryNews.date}, '%Y-%m')`);

    // Apply date filters if provided
    if (startDate && endDate) {
      query = query.where(
        and(
          gte(luxuryNews.date, startDate),
          lte(luxuryNews.date, endDate)
        )
      ) as any;
    }

    const results = await query;

    // Calculate cumulative counts
    let cumulative = 0;
    const trends: OpeningTrend[] = results.map((row) => {
      cumulative += row.count;
      return {
        date: row.date,
        count: row.count,
        cumulative,
      };
    });

    return trends;
  } catch (error) {
    console.error("[Analytics] Error getting opening trends:", error);
    return [];
  }
}

/**
 * Get top brands by number of openings
 */
export async function getTopBrands(limit: number = 20): Promise<BrandStats[]> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[Analytics] Database not available");
      return [];
    }

    const results = await db
      .select({
        brand: luxuryNews.brandName,
        count: sql<number>`COUNT(*) as count`,
      })
      .from(luxuryNews)
      .groupBy(luxuryNews.brandName)
      .orderBy(sql`COUNT(*) DESC`)
      .limit(limit);

    // Calculate total for percentages
    const total = results.reduce((sum, r) => sum + r.count, 0);

    return results.map((row) => ({
      brand: row.brand,
      openings: row.count,
      percentage: total > 0 ? (row.count / total) * 100 : 0,
    }));
  } catch (error) {
    console.error("[Analytics] Error getting top brands:", error);
    return [];
  }
}

/**
 * Get city distribution
 */
export async function getCityDistribution(): Promise<CityStats[]> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[Analytics] Database not available");
      return [];
    }

    const results = await db
      .select({
        city: luxuryNews.city,
        count: sql<number>`COUNT(*) as count`,
      })
      .from(luxuryNews)
      .groupBy(luxuryNews.city)
      .orderBy(sql`COUNT(*) DESC`);

    // Calculate total for percentages
    const total = results.reduce((sum, r) => sum + r.count, 0);

    return results.map((row) => ({
      city: row.city,
      openings: row.count,
      percentage: total > 0 ? (row.count / total) * 100 : 0,
    }));
  } catch (error) {
    console.error("[Analytics] Error getting city distribution:", error);
    return [];
  }
}

/**
 * Get top streets by number of openings
 */
export async function getTopStreets(limit: number = 20): Promise<StreetStats[]> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[Analytics] Database not available");
      return [];
    }

    const results = await db
      .select({
        street: luxuryNews.street,
        city: luxuryNews.city,
        count: sql<number>`COUNT(*) as count`,
        brands: sql<number>`COUNT(DISTINCT ${luxuryNews.brandName}) as brands`,
      })
      .from(luxuryNews)
      .where(sql`${luxuryNews.street} IS NOT NULL`)
      .groupBy(luxuryNews.street, luxuryNews.city)
      .orderBy(sql`COUNT(*) DESC`)
      .limit(limit);

    return results.map((row) => ({
      street: row.street || "Unknown",
      city: row.city,
      openings: row.count,
      brands: row.brands,
    }));
  } catch (error) {
    console.error("[Analytics] Error getting top streets:", error);
    return [];
  }
}

/**
 * Get category distribution
 */
export async function getCategoryDistribution(): Promise<CategoryStats[]> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[Analytics] Database not available");
      return [];
    }

    const results = await db
      .select({
        category: luxuryNews.category,
        count: sql<number>`COUNT(*) as count`,
      })
      .from(luxuryNews)
      .groupBy(luxuryNews.category)
      .orderBy(sql`COUNT(*) DESC`);

    // Calculate total for percentages
    const total = results.reduce((sum, r) => sum + r.count, 0);

    return results.map((row) => ({
      category: row.category,
      count: row.count,
      percentage: total > 0 ? (row.count / total) * 100 : 0,
    }));
  } catch (error) {
    console.error("[Analytics] Error getting category distribution:", error);
    return [];
  }
}

/**
 * Get analytics overview
 */
export async function getAnalyticsOverview(): Promise<AnalyticsOverview> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[Analytics] Database not available");
      return {
        totalOpenings: 0,
        totalBrands: 0,
        totalCities: 0,
        totalStreets: 0,
        dateRange: { start: "", end: "" },
      };
    }

    // Get all news items
    const allNews = await db.select().from(luxuryNews);

    if (allNews.length === 0) {
      return {
        totalOpenings: 0,
        totalBrands: 0,
        totalCities: 0,
        totalStreets: 0,
        dateRange: { start: "", end: "" },
      };
    }

    // Calculate unique values
    const brands = new Set(allNews.map((n) => n.brandName));
    const cities = new Set(allNews.map((n) => n.city));
    const streets = new Set(
      allNews.filter((n) => n.street).map((n) => n.street)
    );

    // Get date range
    const dates = allNews.map((n) => new Date(n.date).getTime());
    const startDate = new Date(Math.min(...dates)).toISOString().split("T")[0];
    const endDate = new Date(Math.max(...dates)).toISOString().split("T")[0];

    return {
      totalOpenings: allNews.length,
      totalBrands: brands.size,
      totalCities: cities.size,
      totalStreets: streets.size,
      dateRange: { start: startDate, end: endDate },
    };
  } catch (error) {
    console.error("[Analytics] Error getting overview:", error);
    return {
      totalOpenings: 0,
      totalBrands: 0,
      totalCities: 0,
      totalStreets: 0,
      dateRange: { start: "", end: "" },
    };
  }
}

/**
 * Get year-over-year comparison
 */
export async function getYearOverYearComparison(): Promise<
  Array<{ year: string; count: number }>
> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[Analytics] Database not available");
      return [];
    }

    const results = await db
      .select({
        year: sql<string>`YEAR(${luxuryNews.date})`,
        count: sql<number>`COUNT(*) as count`,
      })
      .from(luxuryNews)
      .groupBy(sql`YEAR(${luxuryNews.date})`)
      .orderBy(sql`YEAR(${luxuryNews.date})`);

    return results.map((row) => ({
      year: row.year.toString(),
      count: row.count,
    }));
  } catch (error) {
    console.error("[Analytics] Error getting YoY comparison:", error);
    return [];
  }
}

/**
 * Get opening trends by category
 */
export async function getOpeningTrendsByCategory(): Promise<
  Array<{ category: string; month: string; count: number }>
> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[Analytics] Database not available");
      return [];
    }

    const results = await db
      .select({
        category: luxuryNews.category,
        month: sql<string>`DATE_FORMAT(${luxuryNews.date}, '%Y-%m')`,
        count: sql<number>`COUNT(*) as count`,
      })
      .from(luxuryNews)
      .groupBy(luxuryNews.category, sql`DATE_FORMAT(${luxuryNews.date}, '%Y-%m')`)
      .orderBy(sql`DATE_FORMAT(${luxuryNews.date}, '%Y-%m')`);

    return results.map((row) => ({
      category: row.category,
      month: row.month,
      count: row.count,
    }));
  } catch (error) {
    console.error("[Analytics] Error getting category trends:", error);
    return [];
  }
}

/**
 * Get brand performance by city
 */
export async function getBrandPerformanceByCity(
  city: string
): Promise<BrandStats[]> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[Analytics] Database not available");
      return [];
    }

    const results = await db
      .select({
        brand: luxuryNews.brandName,
        count: sql<number>`COUNT(*) as count`,
      })
      .from(luxuryNews)
      .where(eq(luxuryNews.city, city))
      .groupBy(luxuryNews.brandName)
      .orderBy(sql`COUNT(*) DESC`)
      .limit(20);

    // Calculate total for percentages
    const total = results.reduce((sum, r) => sum + r.count, 0);

    return results.map((row) => ({
      brand: row.brand,
      openings: row.count,
      percentage: total > 0 ? (row.count / total) * 100 : 0,
    }));
  } catch (error) {
    console.error("[Analytics] Error getting brand performance by city:", error);
    return [];
  }
}
