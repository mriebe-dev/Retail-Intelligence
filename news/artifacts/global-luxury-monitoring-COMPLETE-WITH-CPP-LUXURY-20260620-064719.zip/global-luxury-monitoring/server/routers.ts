import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  getLuxuryStores,
  getLuxuryStoreById,
  getUniqueCities,
  getUniqueBrands,
  insertLuxuryStore,
  updateLuxuryStore,
  deleteLuxuryStore,
  getLuxuryNews,
  insertLuxuryNews,
  migrateStoresToNews,
  getNewsByCity,
  getNewsStatistics,
  getTopStreetsByCity,
} from "./db";
import {
  runAllDailyCollectors,
  getCollectorStatus,
} from "./dailyNewsCollector";
import {
  getOpeningTrends,
  getTopBrands,
  getCityDistribution,
  getTopStreets,
  getCategoryDistribution,
  getAnalyticsOverview,
  getYearOverYearComparison,
  getOpeningTrendsByCategory,
  getBrandPerformanceByCity,
} from "./analytics";
import {
  collectFromInstagram,
  getInstagramCollectorStatus,
  getMonitoredBrands,
  getMonitoredHashtags,
  getMonitoredCities,
} from "./instagramNewsCollector";
import {
  collectFromGlobalCities,
  getPremiumCities,
  getPremiumCitiesByRegion,
} from "./globalCitiesCollector";
import { placesRouter } from "./placesRouter";
import { batchImportRouter } from "./batchImportRouter";
import { investmentDealsRouter } from "./investmentDealsRouter";
import crypto from "crypto";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  investmentDeals: investmentDealsRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  news: router({
    list: publicProcedure
      .input(
        z.object({
          city: z.string().optional(),
          country: z.string().optional(),
          status: z.enum(["new", "archived", "featured"]).optional(),
          brand: z.string().optional(),
          limit: z.number().optional(),
        })
      )
      .query(async ({ input }) => {
        return await getLuxuryNews(input);
      }),
    getNews: publicProcedure
      .input(
        z.object({
          city: z.string().optional(),
          country: z.string().optional(),
          brand: z.string().optional(),
          status: z.enum(["new", "archived", "featured"]).optional(),
        })
      )
      .query(async ({ input }) => {
        return await getLuxuryNews(input);
      }),
    addNews: publicProcedure
      .input(
        z.object({
          brand: z.string(),
          city: z.string(),
          country: z.string(),
          street: z.string(),
          date: z.string(),
          source: z.string(),
          link: z.string(),
          description: z.string(),
          status: z.enum(["new", "archived", "featured"]).default("new"),
          latitude: z.string().optional(),
          longitude: z.string().optional(),
          photoUrl: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        // Generate URL hash for duplicate prevention
        const urlHash = crypto.createHash("sha256").update(input.link).digest("hex");
        
        return await insertLuxuryNews({
          urlHash,
          brandName: input.brand,
          city: input.city,
          country: input.country,
          street: input.street,
          date: input.date,
          source: input.source,
          link: input.link,
          description: input.description,
          status: input.status,
          latitude: input.latitude,
          longitude: input.longitude,
          photoUrl: input.photoUrl,
        });
      }),
    migrateFromStores: protectedProcedure
      .mutation(async ({ ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        return await migrateStoresToNews();
      }),
    runCollector: protectedProcedure
      .mutation(async ({ ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        return await runAllDailyCollectors();
      }),
    collectorStatus: publicProcedure
      .query(async () => {
        return await getCollectorStatus();
      }),
    getByCity: publicProcedure
      .input(
        z.object({
          city: z.string(),
          country: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        return await getNewsByCity(input.city, input.country);
      }),
    statistics: publicProcedure
      .query(async () => {
        return await getNewsStatistics();
      }),
    topStreets: publicProcedure
      .input(
        z.object({
          city: z.string(),
          limit: z.number().optional().default(20),
        })
      )
      .query(async ({ input }) => {
        return await getTopStreetsByCity(input.city, input.limit);
      }),
    collectFromInstagram: protectedProcedure
      .mutation(async ({ ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        return await collectFromInstagram();
      }),
    instagramStatus: publicProcedure
      .query(async () => {
        return await getInstagramCollectorStatus();
      }),
    monitoredBrands: publicProcedure
      .query(async () => {
        return getMonitoredBrands();
      }),
    monitoredHashtags: publicProcedure
      .query(async () => {
        return getMonitoredHashtags();
      }),
    monitoredCities: publicProcedure
      .query(async () => {
        return getMonitoredCities();
      }),
    collectFromGlobalCities: protectedProcedure
      .mutation(async ({ ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        return await collectFromGlobalCities();
      }),
    premiumCities: publicProcedure
      .query(async () => {
        return getPremiumCities();
      }),
    premiumCitiesByRegion: publicProcedure
      .query(async () => {
        return getPremiumCitiesByRegion();
      }),
  }),

  luxury: router({
    list: publicProcedure
      .input(
        z.object({
          city: z.string().optional(),
          country: z.string().optional(),
          brandName: z.string().optional(),
          newsType: z.string().optional(),
          sourceName: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        return await getLuxuryStores(input);
      }),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await getLuxuryStoreById(input.id);
      }),
    cities: publicProcedure
      .input(z.object({ country: z.string().optional() }))
      .query(async ({ input }) => {
        return await getUniqueCities(input.country);
      }),
    brands: publicProcedure.query(async () => {
      return await getUniqueBrands();
    }),
    create: protectedProcedure
      .input(
        z.object({
          date: z.string(),
          brandName: z.string(),
          city: z.string(),
          country: z.string(),
          locationAddress: z.string().optional(),
          newsType: z.string(),
          summary: z.string().optional(),
          sourceName: z.string().optional(),
          sourceUrl: z.string().optional(),
          partners: z.string().optional(),
          latitude: z.string().optional(),
          longitude: z.string().optional(),
          imageUrl: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        return await insertLuxuryStore(input);
      }),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          data: z.object({
            date: z.string().optional(),
            brandName: z.string().optional(),
            city: z.string().optional(),
            country: z.string().optional(),
            locationAddress: z.string().optional(),
            newsType: z.string().optional(),
            summary: z.string().optional(),
            sourceName: z.string().optional(),
            sourceUrl: z.string().optional(),
            partners: z.string().optional(),
            latitude: z.string().optional(),
            longitude: z.string().optional(),
            imageUrl: z.string().optional(),
          }),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        return await updateLuxuryStore(input.id, input.data);
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN' });
        }
        return await deleteLuxuryStore(input.id);
      }),
  }),

  cities: router({
    getByName: publicProcedure
      .input(
        z.object({
          country: z.string(),
          city: z.string(),
        })
      )
      .query(async ({ input }) => {
        // Import globalRetailReport134 to get city data
        const { getCityStats, getStreetsByCity } = await import('./globalRetailReport134');
        const stats = getCityStats(input.country, input.city);
        const streets = getStreetsByCity(input.country, input.city);
        
        return {
          country: input.country,
          city: input.city,
          streets: stats.streets,
          streetList: streets,
        };
      }),
    getAll: publicProcedure.query(async () => {
      const { getAllCountries, getCitiesByCountry } = await import('./globalRetailReport134');
      const countries = getAllCountries();
      
      return countries.map((country) => ({
        country,
        cities: getCitiesByCountry(country),
      }));
    }),
  }),

  analytics: router({
    overview: publicProcedure.query(async () => {
      return await getAnalyticsOverview();
    }),
    openingTrends: publicProcedure
      .input(
        z.object({
          startDate: z.string().optional(),
          endDate: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        return await getOpeningTrends(input.startDate, input.endDate);
      }),
    topBrands: publicProcedure
      .input(z.object({ limit: z.number().default(20) }))
      .query(async ({ input }) => {
        return await getTopBrands(input.limit);
      }),
    cityDistribution: publicProcedure.query(async () => {
      return await getCityDistribution();
    }),
    topStreets: publicProcedure
      .input(z.object({ limit: z.number().default(20) }))
      .query(async ({ input }) => {
        return await getTopStreets(input.limit);
      }),
    categoryDistribution: publicProcedure.query(async () => {
      return await getCategoryDistribution();
    }),
    yearOverYear: publicProcedure.query(async () => {
      return await getYearOverYearComparison();
    }),
    categoryTrends: publicProcedure.query(async () => {
      return await getOpeningTrendsByCategory();
    }),
    brandsByCity: publicProcedure
      .input(z.object({ city: z.string() }))
      .query(async ({ input }) => {
        return await getBrandPerformanceByCity(input.city);
      }),
  }),

  places: placesRouter,
  batchImport: batchImportRouter,
});

export type AppRouter = typeof appRouter;

// Export luxury router for type safety
export type LuxuryRouter = typeof appRouter.luxury;
export type NewsRouter = typeof appRouter.news;
export type CitiesRouter = typeof appRouter.cities;
export type CollectorRouter = typeof appRouter.news.runCollector;
export type InstagramCollectorRouter = typeof appRouter.news.collectFromInstagram;
export type GlobalCitiesCollectorRouter = typeof appRouter.news.collectFromGlobalCities;
