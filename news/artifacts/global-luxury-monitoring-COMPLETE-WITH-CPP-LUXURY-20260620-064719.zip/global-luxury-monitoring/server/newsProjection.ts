/**
 * News Projection Service
 * Projects 1,087 news items onto street geometries for linear marker positioning
 */

import {
  getStreetGeometry,
  findClosestStreet,
  getPointAlongStreet,
  calculateDistance,
  StreetCoordinates,
} from "./streetGeometry";

export interface ProjectedNews {
  newsId: string;
  brand: string;
  city: string;
  streetName: string;
  latitude: number;
  longitude: number;
  distanceAlongStreet: number; // meters from street start
  closestStreetDistance: number; // meters from street line
  projectionConfidence: number; // 0-1
  date: Date;
  status: "new" | "featured" | "archived";
}

export interface NewsProjectionResult {
  totalNews: number;
  successfulProjections: number;
  failedProjections: number;
  projections: ProjectedNews[];
  errors: Array<{ newsId: string; error: string }>;
}

/**
 * Extract city and street from news address
 * @param address Full address string
 * @returns City and street name
 */
export function extractLocationFromAddress(
  address: string
): { city: string | null; street: string | null } {
  // Simple pattern matching - can be enhanced with NLP
  const cityPatterns = [
    "Zurich",
    "Geneva",
    "Munich",
    "Paris",
    "London",
    "Milan",
    "Tokyo",
    "New York",
    "Dubai",
    "Singapore",
    "Hong Kong",
  ];

  const streetPatterns = [
    "Bahnhofstrasse",
    "Rue du Rhône",
    "Neuhauserstrasse",
    "Kaufingerstrasse",
    "Champs-Élysées",
    "Bond Street",
    "Oxford Street",
    "Via Monte Napoleone",
    "Ginza",
    "Fifth Avenue",
    "Madison Avenue",
  ];

  let city: string | null = null;
  let street: string | null = null;

  for (const c of cityPatterns) {
    if (address.includes(c)) {
      city = c;
      break;
    }
  }

  for (const s of streetPatterns) {
    if (address.includes(s)) {
      street = s;
      break;
    }
  }

  return { city, street };
}

/**
 * Project a single news item onto a street
 * @param newsId News ID
 * @param brand Brand name
 * @param address Full address
 * @param latitude Approximate latitude
 * @param longitude Approximate longitude
 * @param date News date
 * @param status News status
 * @returns Projected news with street coordinates
 */
export function projectNewsOntoStreet(
  newsId: string,
  brand: string,
  address: string,
  latitude: number,
  longitude: number,
  date: Date,
  status: "new" | "featured" | "archived"
): ProjectedNews | null {
  const { city, street } = extractLocationFromAddress(address);

  if (!city) {
    return null;
  }

  let projectedNews: ProjectedNews;

  if (street) {
    // Street found - project onto street line
    const streetGeometry = getStreetGeometry(city, street);
    if (streetGeometry) {
      // Find closest point on street line
      const distanceToStart = calculateDistance(
        latitude,
        longitude,
        streetGeometry.startLat,
        streetGeometry.startLng
      );
      const distanceToEnd = calculateDistance(
        latitude,
        longitude,
        streetGeometry.endLat,
        streetGeometry.endLng
      );

      // Determine distance along street
      let distanceAlongStreet = 0;
      if (distanceToStart < distanceToEnd) {
        distanceAlongStreet = Math.min(distanceToStart, streetGeometry.length);
      } else {
        distanceAlongStreet = Math.max(
          0,
          streetGeometry.length - distanceToEnd
        );
      }

      // Get projected point
      const point = getPointAlongStreet(streetGeometry, distanceAlongStreet);

      // Calculate confidence based on distance to street
      const minDistance = Math.min(distanceToStart, distanceToEnd);
      const confidence = Math.max(0, 1 - minDistance / 500); // 500m threshold

      projectedNews = {
        newsId,
        brand,
        city,
        streetName: street,
        latitude: point.lat,
        longitude: point.lng,
        distanceAlongStreet,
        closestStreetDistance: minDistance,
        projectionConfidence: confidence,
        date,
        status,
      };
    } else {
      // Street not found - use closest street
      const result = findClosestStreet(latitude, longitude, city);
      if (!result) {
        return null;
      }

      const distanceAlongStreet = calculateDistance(
        latitude,
        longitude,
        result.street.startLat,
        result.street.startLng
      );
      const point = getPointAlongStreet(result.street, distanceAlongStreet);
      const confidence = Math.max(0, 1 - result.distance / 1000);

      projectedNews = {
        newsId,
        brand,
        city,
        streetName: result.street.streetName,
        latitude: point.lat,
        longitude: point.lng,
        distanceAlongStreet,
        closestStreetDistance: result.distance,
        projectionConfidence: confidence,
        date,
        status,
      };
    }
  } else {
    // No street found - use closest street in city
    const result = findClosestStreet(latitude, longitude, city);
    if (!result) {
      return null;
    }

    const distanceAlongStreet = calculateDistance(
      latitude,
      longitude,
      result.street.startLat,
      result.street.startLng
    );
    const point = getPointAlongStreet(result.street, distanceAlongStreet);
    const confidence = Math.max(0, 1 - result.distance / 1000);

    projectedNews = {
      newsId,
      brand,
      city,
      streetName: result.street.streetName,
      latitude: point.lat,
      longitude: point.lng,
      distanceAlongStreet,
      closestStreetDistance: result.distance,
      projectionConfidence: confidence,
      date,
      status,
    };
  }

  return projectedNews;
}

/**
 * Project multiple news items in parallel
 * @param newsItems Array of news items to project
 * @returns Projection result with successes and failures
 */
export function projectNewsInParallel(
  newsItems: Array<{
    id: string;
    brand: string;
    address: string;
    latitude: number;
    longitude: number;
    date: Date;
    status: "new" | "featured" | "archived";
  }>
): NewsProjectionResult {
  const projections: ProjectedNews[] = [];
  const errors: Array<{ newsId: string; error: string }> = [];

  for (const item of newsItems) {
    try {
      const projected = projectNewsOntoStreet(
        item.id,
        item.brand,
        item.address,
        item.latitude,
        item.longitude,
        item.date,
        item.status
      );

      if (projected) {
        projections.push(projected);
      } else {
        errors.push({
          newsId: item.id,
          error: "Could not extract location or find matching street",
        });
      }
    } catch (error) {
      errors.push({
        newsId: item.id,
        error: error instanceof Error ? error.message : "Unknown error",
      });
    }
  }

  return {
    totalNews: newsItems.length,
    successfulProjections: projections.length,
    failedProjections: errors.length,
    projections,
    errors,
  };
}

/**
 * Sort projected news by street and distance
 * @param projections Array of projected news
 * @returns Sorted projections
 */
export function sortProjectionsByStreet(
  projections: ProjectedNews[]
): ProjectedNews[] {
  return projections.sort((a, b) => {
    if (a.city !== b.city) {
      return a.city.localeCompare(b.city);
    }
    if (a.streetName !== b.streetName) {
      return a.streetName.localeCompare(b.streetName);
    }
    return a.distanceAlongStreet - b.distanceAlongStreet;
  });
}

/**
 * Group projected news by street
 * @param projections Array of projected news
 * @returns Map of street -> news items
 */
export function groupProjectionsByStreet(
  projections: ProjectedNews[]
): Map<string, ProjectedNews[]> {
  const grouped = new Map<string, ProjectedNews[]>();

  for (const projection of projections) {
    const key = `${projection.city}/${projection.streetName}`;
    if (!grouped.has(key)) {
      grouped.set(key, []);
    }
    grouped.get(key)!.push(projection);
  }

  // Sort each group by distance along street
  grouped.forEach((items: ProjectedNews[]) => {
    items.sort((a: ProjectedNews, b: ProjectedNews) => a.distanceAlongStreet - b.distanceAlongStreet);
  });

  return grouped;
}

/**
 * Calculate street statistics
 * @param projections Array of projected news
 * @returns Statistics per street
 */
export function calculateStreetStatistics(
  projections: ProjectedNews[]
): Map<
  string,
  {
    streetName: string;
    city: string;
    count: number;
    brands: Set<string>;
    avgConfidence: number;
    dateRange: { min: Date; max: Date };
  }
> {
  const stats = new Map<
    string,
    {
      streetName: string;
      city: string;
      count: number;
      brands: Set<string>;
      avgConfidence: number;
      dateRange: { min: Date; max: Date };
    }
  >();

  for (const projection of projections) {
    const key = `${projection.city}/${projection.streetName}`;

    if (!stats.has(key)) {
      stats.set(key, {
        streetName: projection.streetName,
        city: projection.city,
        count: 0,
        brands: new Set(),
        avgConfidence: 0,
        dateRange: { min: projection.date, max: projection.date },
      });
    }

    const stat = stats.get(key)!;
    stat.count++;
    stat.brands.add(projection.brand);
    stat.avgConfidence += projection.projectionConfidence;
    stat.dateRange.min = new Date(
      Math.min(stat.dateRange.min.getTime(), projection.date.getTime())
    );
    stat.dateRange.max = new Date(
      Math.max(stat.dateRange.max.getTime(), projection.date.getTime())
    );
  }

  // Calculate average confidence
  stats.forEach((stat) => {
    stat.avgConfidence = stat.avgConfidence / stat.count;
  });

  return stats;
}
