import { describe, it, expect } from 'vitest';
import { getCityStats, getStreetsByCity, getAllCountries, getCitiesByCountry } from './globalRetailReport134';

describe('Cities Router - globalRetailReport134', () => {
  describe('getCityStats', () => {
    it('should return stats for Zurich', () => {
      const stats = getCityStats('Switzerland', 'Zurich');
      expect(stats.city).toBe('Zurich');
      expect(stats.country).toBe('Switzerland');
      expect(stats.streets).toBeGreaterThan(0);
      expect(stats.streetList.length).toBe(stats.streets);
    });

    it('should return stats for Berlin', () => {
      const stats = getCityStats('Germany', 'Berlin');
      expect(stats.city).toBe('Berlin');
      expect(stats.country).toBe('Germany');
      expect(stats.streets).toBeGreaterThan(0);
    });

    it('should return stats for Dublin', () => {
      const stats = getCityStats('Ireland', 'Dublin');
      expect(stats.city).toBe('Dublin');
      expect(stats.country).toBe('Ireland');
      expect(stats.streets).toBeGreaterThan(0);
    });

    it('should return stats for Edinburgh', () => {
      const stats = getCityStats('United Kingdom', 'Edinburgh');
      expect(stats.city).toBe('Edinburgh');
      expect(stats.country).toBe('United Kingdom');
      expect(stats.streets).toBeGreaterThan(0);
    });

    it('should return stats for Glasgow', () => {
      const stats = getCityStats('United Kingdom', 'Glasgow');
      expect(stats.city).toBe('Glasgow');
      expect(stats.country).toBe('United Kingdom');
      expect(stats.streets).toBeGreaterThan(0);
    });

    it('should return empty stats for non-existent city', () => {
      const stats = getCityStats('NonExistent', 'NonExistent');
      expect(stats.streets).toBe(0);
      expect(stats.streetList.length).toBe(0);
    });
  });

  describe('getStreetsByCity', () => {
    it('should return streets for Zurich', () => {
      const streets = getStreetsByCity('Switzerland', 'Zurich');
      expect(Array.isArray(streets)).toBe(true);
      expect(streets.length).toBeGreaterThan(0);
      expect(streets).toContain('Bahnhofstrasse');
    });

    it('should return streets for Paris', () => {
      const streets = getStreetsByCity('France', 'Paris');
      expect(Array.isArray(streets)).toBe(true);
      expect(streets.length).toBeGreaterThan(0);
      expect(streets).toContain('Champs-Élysées');
    });

    it('should return streets for Dublin', () => {
      const streets = getStreetsByCity('Ireland', 'Dublin');
      expect(Array.isArray(streets)).toBe(true);
      expect(streets.length).toBeGreaterThan(0);
      expect(streets).toContain('Grafton Street');
    });

    it('should return empty array for non-existent city', () => {
      const streets = getStreetsByCity('NonExistent', 'NonExistent');
      expect(Array.isArray(streets)).toBe(true);
      expect(streets.length).toBe(0);
    });
  });

  describe('getAllCountries', () => {
    it('should return array of countries', () => {
      const countries = getAllCountries();
      expect(Array.isArray(countries)).toBe(true);
      expect(countries.length).toBeGreaterThan(0);
    });

    it('should include Switzerland', () => {
      const countries = getAllCountries();
      expect(countries).toContain('Switzerland');
    });

    it('should include Germany', () => {
      const countries = getAllCountries();
      expect(countries).toContain('Germany');
    });

    it('should include United Kingdom', () => {
      const countries = getAllCountries();
      expect(countries).toContain('United Kingdom');
    });

    it('should include Ireland', () => {
      const countries = getAllCountries();
      expect(countries).toContain('Ireland');
    });

    it('should be sorted alphabetically', () => {
      const countries = getAllCountries();
      const sortedCountries = [...countries].sort();
      expect(countries).toEqual(sortedCountries);
    });
  });

  describe('getCitiesByCountry', () => {
    it('should return cities for Switzerland', () => {
      const cities = getCitiesByCountry('Switzerland');
      expect(Array.isArray(cities)).toBe(true);
      expect(cities.length).toBeGreaterThan(0);
      expect(cities).toContain('Zurich');
      expect(cities).toContain('Geneva');
    });

    it('should return cities for Germany', () => {
      const cities = getCitiesByCountry('Germany');
      expect(Array.isArray(cities)).toBe(true);
      expect(cities.length).toBeGreaterThan(0);
      expect(cities).toContain('Berlin');
      expect(cities).toContain('Munich');
    });

    it('should return cities for United Kingdom', () => {
      const cities = getCitiesByCountry('United Kingdom');
      expect(Array.isArray(cities)).toBe(true);
      expect(cities.length).toBeGreaterThan(0);
      expect(cities).toContain('Edinburgh');
      expect(cities).toContain('Glasgow');
    });

    it('should return cities for Ireland', () => {
      const cities = getCitiesByCountry('Ireland');
      expect(Array.isArray(cities)).toBe(true);
      expect(cities.length).toBeGreaterThan(0);
      expect(cities).toContain('Dublin');
    });

    it('should return empty array for non-existent country', () => {
      const cities = getCitiesByCountry('NonExistent');
      expect(Array.isArray(cities)).toBe(true);
      expect(cities.length).toBe(0);
    });

    it('should be sorted alphabetically', () => {
      const cities = getCitiesByCountry('Switzerland');
      const sortedCities = [...cities].sort();
      expect(cities).toEqual(sortedCities);
    });
  });
});
