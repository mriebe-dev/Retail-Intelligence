import { describe, it, expect } from 'vitest';

describe('NewsMarkers Component', () => {
  it('should group news by street correctly', () => {
    const news = [
      {
        id: '1',
        brand: 'Dior',
        street: 'Bahnhofstrasse 13',
        city: 'Zurich',
        country: 'Switzerland',
        latitude: 47.3688273,
        longitude: 8.5393512,
        date: '2026-02-13',
        source: 'Opening News',
        link: 'https://example.com',
        status: 'new' as const,
        category: 'Fashion',
      },
      {
        id: '2',
        brand: 'Rolex',
        street: 'Bahnhofstrasse 40',
        city: 'Zurich',
        country: 'Switzerland',
        latitude: 47.3715035,
        longitude: 8.5389191,
        date: '2026-02-26',
        source: 'Opening News',
        link: 'https://example.com',
        status: 'new' as const,
        category: 'Watches',
      },
    ];

    // Group by street
    const grouped = news.reduce((acc, item) => {
      const key = `${item.street}, ${item.city}`;
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(item);
      return acc;
    }, {} as Record<string, typeof news>);

    expect(Object.keys(grouped).length).toBe(2);
    expect(grouped['Bahnhofstrasse 13, Zurich'].length).toBe(1);
    expect(grouped['Bahnhofstrasse 40, Zurich'].length).toBe(1);
  });

  it('should handle multiple news on same street', () => {
    const news = [
      {
        id: '1',
        brand: 'Dior',
        street: 'Bahnhofstrasse',
        city: 'Zurich',
        country: 'Switzerland',
        latitude: 47.3688273,
        longitude: 8.5393512,
        date: '2026-02-13',
        source: 'Opening News',
        link: 'https://example.com',
        status: 'new' as const,
        category: 'Fashion',
      },
      {
        id: '2',
        brand: 'Chanel',
        street: 'Bahnhofstrasse',
        city: 'Zurich',
        country: 'Switzerland',
        latitude: 47.3715035,
        longitude: 8.5389191,
        date: '2026-02-20',
        source: 'Opening News',
        link: 'https://example.com',
        status: 'new' as const,
        category: 'Fashion',
      },
    ];

    const grouped = news.reduce((acc, item) => {
      const key = `${item.street}, ${item.city}`;
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(item);
      return acc;
    }, {} as Record<string, typeof news>);

    expect(Object.keys(grouped).length).toBe(1);
    expect(grouped['Bahnhofstrasse, Zurich'].length).toBe(2);
  });

  it('should correctly identify news status', () => {
    const statuses = ['new', 'archived', 'featured'];
    
    statuses.forEach(status => {
      expect(['new', 'archived', 'featured']).toContain(status);
    });
  });

  it('should format news data correctly', () => {
    const news = {
      id: '1',
      brand: 'Dior',
      street: 'Bahnhofstrasse 13',
      city: 'Zurich',
      country: 'Switzerland',
      latitude: 47.3688273,
      longitude: 8.5393512,
      date: '2026-02-13',
      source: 'Opening News',
      link: 'https://example.com',
      status: 'new' as const,
      category: 'Fashion',
    };

    expect(news.brand).toBe('Dior');
    expect(news.latitude).toBeGreaterThan(0);
    expect(news.longitude).toBeGreaterThan(0);
    expect(news.status).toBe('new');
  });

  it('should handle empty news array', () => {
    const news: any[] = [];
    
    const grouped = news.reduce((acc, item) => {
      const key = `${item.street}, ${item.city}`;
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(item);
      return acc;
    }, {} as Record<string, typeof news>);

    expect(Object.keys(grouped).length).toBe(0);
  });

  it('should filter news by status', () => {
    const news = [
      {
        id: '1',
        brand: 'Dior',
        street: 'Bahnhofstrasse',
        city: 'Zurich',
        country: 'Switzerland',
        latitude: 47.3688273,
        longitude: 8.5393512,
        date: '2026-02-13',
        source: 'Opening News',
        link: 'https://example.com',
        status: 'new' as const,
        category: 'Fashion',
      },
      {
        id: '2',
        brand: 'Chanel',
        street: 'Bahnhofstrasse',
        city: 'Zurich',
        country: 'Switzerland',
        latitude: 47.3715035,
        longitude: 8.5389191,
        date: '2026-02-20',
        source: 'Opening News',
        link: 'https://example.com',
        status: 'archived' as const,
        category: 'Fashion',
      },
    ];

    const newNews = news.filter(n => n.status === 'new');
    const archivedNews = news.filter(n => n.status === 'archived');

    expect(newNews.length).toBe(1);
    expect(archivedNews.length).toBe(1);
  });

  it('should calculate marker positions correctly', () => {
    const news = {
      id: '1',
      brand: 'Dior',
      street: 'Bahnhofstrasse 13',
      city: 'Zurich',
      country: 'Switzerland',
      latitude: 47.3688273,
      longitude: 8.5393512,
      date: '2026-02-13',
      source: 'Opening News',
      link: 'https://example.com',
      status: 'new' as const,
      category: 'Fashion',
    };

    // Zurich coordinates should be within valid range
    expect(news.latitude).toBeGreaterThan(47);
    expect(news.latitude).toBeLessThan(48);
    expect(news.longitude).toBeGreaterThan(8);
    expect(news.longitude).toBeLessThan(9);
  });

  it('should sort news by date', () => {
    const news = [
      {
        id: '1',
        brand: 'Dior',
        street: 'Bahnhofstrasse',
        city: 'Zurich',
        country: 'Switzerland',
        latitude: 47.3688273,
        longitude: 8.5393512,
        date: '2026-02-20',
        source: 'Opening News',
        link: 'https://example.com',
        status: 'new' as const,
        category: 'Fashion',
      },
      {
        id: '2',
        brand: 'Chanel',
        street: 'Bahnhofstrasse',
        city: 'Zurich',
        country: 'Switzerland',
        latitude: 47.3715035,
        longitude: 8.5389191,
        date: '2026-02-13',
        source: 'Opening News',
        link: 'https://example.com',
        status: 'new' as const,
        category: 'Fashion',
      },
    ];

    const sorted = [...news].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    expect(sorted[0].brand).toBe('Chanel');
    expect(sorted[1].brand).toBe('Dior');
  });

  it('should validate news link URLs', () => {
    const news = {
      id: '1',
      brand: 'Dior',
      street: 'Bahnhofstrasse 13',
      city: 'Zurich',
      country: 'Switzerland',
      latitude: 47.3688273,
      longitude: 8.5393512,
      date: '2026-02-13',
      source: 'Opening News',
      link: 'https://example.com',
      status: 'new' as const,
      category: 'Fashion',
    };

    expect(news.link.startsWith('http')).toBe(true);
  });

  it('should count news per street correctly', () => {
    const news = [
      {
        id: '1',
        brand: 'Dior',
        street: 'Bahnhofstrasse',
        city: 'Zurich',
        country: 'Switzerland',
        latitude: 47.3688273,
        longitude: 8.5393512,
        date: '2026-02-13',
        source: 'Opening News',
        link: 'https://example.com',
        status: 'new' as const,
        category: 'Fashion',
      },
      {
        id: '2',
        brand: 'Chanel',
        street: 'Bahnhofstrasse',
        city: 'Zurich',
        country: 'Switzerland',
        latitude: 47.3715035,
        longitude: 8.5389191,
        date: '2026-02-20',
        source: 'Opening News',
        link: 'https://example.com',
        status: 'new' as const,
        category: 'Fashion',
      },
      {
        id: '3',
        brand: 'Rolex',
        street: 'Rue du Rhône',
        city: 'Geneva',
        country: 'Switzerland',
        latitude: 46.2031863,
        longitude: 6.1521165,
        date: '2026-02-26',
        source: 'Opening News',
        link: 'https://example.com',
        status: 'new' as const,
        category: 'Watches',
      },
    ];

    const streetCounts = news.reduce((acc, item) => {
      const key = `${item.street}, ${item.city}`;
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    expect(streetCounts['Bahnhofstrasse, Zurich']).toBe(2);
    expect(streetCounts['Rue du Rhône, Geneva']).toBe(1);
  });
});
