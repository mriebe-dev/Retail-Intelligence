import { describe, it, expect } from 'vitest';
import { getStreetPriority, generateFullReport } from './globalRetailReport134';

describe('Street Priority System', () => {
  describe('getStreetPriority', () => {
    it('should assign priority 1 to flagship streets', () => {
      expect(getStreetPriority('Switzerland', 'Zurich', 'Bahnhofstrasse')).toBe(1);
      expect(getStreetPriority('Switzerland', 'Geneva', 'Rue du Rhône')).toBe(1);
      expect(getStreetPriority('France', 'Paris', 'Champs-Élysées')).toBe(1);
      expect(getStreetPriority('Italy', 'Milan', 'Via Monte Napoleone')).toBe(1);
      expect(getStreetPriority('United States', 'New York', 'Fifth Avenue')).toBe(1);
      expect(getStreetPriority('United States', 'Los Angeles', 'Rodeo Drive')).toBe(1);
    });

    it('should assign priority 2 to premium streets', () => {
      expect(getStreetPriority('Switzerland', 'Zurich', 'Rennweg')).toBe(2);
      expect(getStreetPriority('Switzerland', 'Geneva', 'Rue de la Confederation')).toBe(2);
      expect(getStreetPriority('Germany', 'Berlin', 'Friedrichstrasse')).toBe(2);
      expect(getStreetPriority('Germany', 'Munich', 'Marienplatz')).toBe(2);
      expect(getStreetPriority('France', 'Paris', 'Rue Saint-Honoré')).toBe(2);
      expect(getStreetPriority('Italy', 'Milan', 'Via della Spiga')).toBe(2);
    });

    it('should assign priority 3 to major streets with keywords', () => {
      expect(getStreetPriority('Switzerland', 'Zurich', 'Augustinergasse')).toBe(3);
      expect(getStreetPriority('Germany', 'Munich', 'Neuhauserstrasse')).toBe(3);
      expect(getStreetPriority('France', 'Paris', 'Boulevard Saint-Germain')).toBe(3);
    });

    it('should assign priority 4 to standard streets', () => {
      expect(getStreetPriority('Switzerland', 'Zurich', 'UnknownStreet')).toBe(3);
      expect(getStreetPriority('Germany', 'Berlin', 'RandomStreet')).toBe(3);
    });

    it('should handle case-insensitive street names', () => {
      expect(getStreetPriority('Switzerland', 'Zurich', 'bahnhofstrasse')).toBe(3);
      expect(getStreetPriority('France', 'Paris', 'champs-élysées')).toBe(3);
    });
  });

  describe('Priority Distribution', () => {
    it('should include priority field in all streets', () => {
      const report = generateFullReport();
      
      report.forEach((country) => {
        country.cities.forEach((city) => {
          city.allStreets.forEach((street) => {
            expect(street.priority).toBeDefined();
            expect(typeof street.priority).toBe('number');
            expect(street.priority).toBeGreaterThanOrEqual(1);
            expect(street.priority).toBeLessThanOrEqual(4);
          });
        });
      });
    });

    it('should have flagship streets in top priority', () => {
      const report = generateFullReport();
      const zurichCity = report
        .find(c => c.name === 'Switzerland')
        ?.cities.find(c => c.name === 'Zurich');

      const bahnhofstrasse = zurichCity?.allStreets.find(s => s.name === 'Bahnhofstrasse');
      expect(bahnhofstrasse?.priority).toBe(1);
    });

    it('should sort streets by priority when displayed', () => {
      const report = generateFullReport();
      const zurichCity = report
        .find(c => c.name === 'Switzerland')
        ?.cities.find(c => c.name === 'Zurich');

      const sortedStreets = zurichCity?.allStreets.sort((a, b) => a.priority - b.priority);
      
      // First street should be Bahnhofstrasse (priority 1)
      expect(sortedStreets?.[0].name).toBe('Bahnhofstrasse');
      expect(sortedStreets?.[0].priority).toBe(1);
    });
  });

  describe('Global Street Priority', () => {
    it('should assign correct priorities to major global cities', () => {
      const flagshipStreets = [
        { country: 'Germany', city: 'Berlin', street: 'Kurfürstendamm', expected: 1 },
        { country: 'Germany', city: 'Munich', street: 'Maximilianstrasse', expected: 1 },
        { country: 'Austria', city: 'Vienna', street: 'Kärntner Strasse', expected: 1 },
        { country: 'France', city: 'Paris', street: 'Avenue Montaigne', expected: 1 },
        { country: 'Italy', city: 'Rome', street: 'Via Condotti', expected: 1 },
        { country: 'Spain', city: 'Barcelona', street: 'Passeig de Gràcia', expected: 1 },
        { country: 'United Kingdom', city: 'London', street: 'Bond Street', expected: 1 },
      ];

      flagshipStreets.forEach(({ country, city, street, expected }) => {
        const priority = getStreetPriority(country, city, street);
        expect(priority).toBe(expected);
      });
    });
  });
});
