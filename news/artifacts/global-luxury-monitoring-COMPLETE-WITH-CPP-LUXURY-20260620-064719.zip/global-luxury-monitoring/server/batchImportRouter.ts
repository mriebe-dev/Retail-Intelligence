import { protectedProcedure, router } from './_core/trpc';
import { z } from 'zod';
import { importStores, parseCSV, parseJSON, StoreImportData } from './batchImportService';

export const batchImportRouter = router({
  /**
   * Import stores from CSV file content
   */
  importFromCSV: protectedProcedure
    .input(
      z.object({
        csvContent: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Only admins can import stores
      if (ctx.user?.role !== 'admin') {
        throw new Error('Only admins can import stores');
      }

      try {
        const storesData = parseCSV(input.csvContent);
        const result = await importStores(storesData);
        return {
          success: true,
          result,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),

  /**
   * Import stores from JSON file content
   */
  importFromJSON: protectedProcedure
    .input(
      z.object({
        jsonContent: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Only admins can import stores
      if (ctx.user?.role !== 'admin') {
        throw new Error('Only admins can import stores');
      }

      try {
        const storesData = parseJSON(input.jsonContent);
        const result = await importStores(storesData);
        return {
          success: true,
          result,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),

  /**
   * Import stores from raw data array
   */
  importFromData: protectedProcedure
    .input(
      z.object({
        stores: z.array(
          z.object({
            brandName: z.string(),
            city: z.string(),
            country: z.string(),
            street: z.string().optional(),
            date: z.string(),
            category: z.enum(['Fashion', 'Watches', 'Jewelry', 'Home', 'Other']),
            photoUrl: z.string().optional(),
            source: z.string(),
            link: z.string(),
            description: z.string(),
          })
        ),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Only admins can import stores
      if (ctx.user?.role !== 'admin') {
        throw new Error('Only admins can import stores');
      }

      try {
        const storesData: StoreImportData[] = input.stores;
        const result = await importStores(storesData);
        return {
          success: true,
          result,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),
});
