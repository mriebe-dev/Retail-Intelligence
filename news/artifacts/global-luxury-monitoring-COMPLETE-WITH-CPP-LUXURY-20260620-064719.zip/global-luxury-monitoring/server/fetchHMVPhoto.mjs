#!/usr/bin/env node

/**
 * Script to fetch HMV Amsterdam store photos using Manus Forge API
 * Fetches photos from Google Places API and uploads to S3
 */

import https from 'https';

// Configuration
const STORE_NAME = 'HMV';
const STORE_ADDRESS = 'Kalverstraat 8, Amsterdam, Netherlands';
const STORE_ID = 'hmv-amsterdam-2026-03-15';

// Get environment variables
const FORGE_API_URL = process.env.BUILT_IN_FORGE_API_URL || 'https://api.manus.im';
const FORGE_API_KEY = process.env.BUILT_IN_FORGE_API_KEY;

if (!FORGE_API_KEY) {
  console.error('ERROR: BUILT_IN_FORGE_API_KEY environment variable is not set');
  process.exit(1);
}

/**
 * Make HTTPS request to Manus Forge API
 */
function makeRequest(method, path, body = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, FORGE_API_URL);
    const options = {
      method,
      headers: {
        'Authorization': `Bearer ${FORGE_API_KEY}`,
        'Content-Type': 'application/json',
      },
    };

    const req = https.request(url, options, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve({ status: res.statusCode, data: parsed });
        } catch (e) {
          resolve({ status: res.statusCode, data });
        }
      });
    });

    req.on('error', reject);

    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

/**
 * Fetch photos from Google Places API via Manus Forge
 */
async function fetchPhotosFromGooglePlaces() {
  console.log(`\n📸 Fetching photos for ${STORE_NAME} at ${STORE_ADDRESS}...`);

  try {
    // Call the Manus Forge API to search for place details
    const response = await makeRequest('POST', '/v1/places/search', {
      query: `${STORE_NAME} ${STORE_ADDRESS}`,
      fields: ['photos', 'formatted_address', 'name', 'place_id'],
    });

    if (response.status !== 200) {
      console.error(`❌ API Error: ${response.status}`);
      console.error(response.data);
      return null;
    }

    const placeData = response.data;
    console.log(`✅ Found place: ${placeData.name}`);
    console.log(`📍 Address: ${placeData.formatted_address}`);

    if (!placeData.photos || placeData.photos.length === 0) {
      console.warn('⚠️  No photos found for this location');
      return null;
    }

    console.log(`📷 Found ${placeData.photos.length} photos`);

    // Get the first photo (main store photo)
    const photoReference = placeData.photos[0].photo_reference;
    console.log(`\n📥 Downloading photo (reference: ${photoReference.substring(0, 20)}...)`);

    // Fetch the actual photo
    const photoResponse = await makeRequest('POST', '/v1/places/photo', {
      photo_reference: photoReference,
      max_width: 1200,
      max_height: 800,
    });

    if (photoResponse.status !== 200) {
      console.error(`❌ Photo download failed: ${photoResponse.status}`);
      return null;
    }

    console.log(`✅ Photo downloaded successfully`);
    return {
      photoData: photoResponse.data,
      photoReference,
      placeData,
    };
  } catch (error) {
    console.error('❌ Error fetching photos:', error.message);
    return null;
  }
}

/**
 * Upload photo to S3 via Manus Forge API
 */
async function uploadPhotoToS3(photoData) {
  console.log(`\n☁️  Uploading photo to S3...`);

  try {
    const fileName = `store-photos/hmv-amsterdam-${Date.now()}.jpg`;

    // Upload to S3
    const uploadResponse = await makeRequest('POST', '/v1/storage/upload', {
      path: fileName,
      data: photoData,
      contentType: 'image/jpeg',
    });

    if (uploadResponse.status !== 200 && uploadResponse.status !== 201) {
      console.error(`❌ Upload failed: ${uploadResponse.status}`);
      console.error(uploadResponse.data);
      return null;
    }

    const s3Url = uploadResponse.data.url;
    console.log(`✅ Photo uploaded to S3`);
    console.log(`🔗 URL: ${s3Url}`);

    return s3Url;
  } catch (error) {
    console.error('❌ Error uploading photo:', error.message);
    return null;
  }
}

/**
 * Update database with photo URL
 */
async function updateDatabaseWithPhoto(photoUrl) {
  console.log(`\n💾 Updating database with photo URL...`);

  try {
    // This would be called via tRPC in a real scenario
    // For now, we'll just log the SQL that should be executed
    const sql = `
      UPDATE luxury_news 
      SET photo_url = '${photoUrl}', 
          updated_at = NOW() 
      WHERE brand_name = 'HMV' 
      AND city = 'Amsterdam' 
      AND street = 'Kalverstraat'
      LIMIT 1;
    `;

    console.log(`✅ Database update SQL:`);
    console.log(sql);
    console.log(`\n⚠️  Note: Execute this SQL manually or via database admin panel`);

    return true;
  } catch (error) {
    console.error('❌ Error updating database:', error.message);
    return false;
  }
}

/**
 * Main function
 */
async function main() {
  console.log('🚀 HMV Amsterdam Photo Fetcher');
  console.log('================================');
  console.log(`Store: ${STORE_NAME}`);
  console.log(`Address: ${STORE_ADDRESS}`);
  console.log(`Forge API: ${FORGE_API_URL}`);

  // Fetch photos from Google Places
  const photoResult = await fetchPhotosFromGooglePlaces();

  if (!photoResult) {
    console.error('\n❌ Failed to fetch photos');
    process.exit(1);
  }

  // Upload to S3
  const s3Url = await uploadPhotoToS3(photoResult.photoData);

  if (!s3Url) {
    console.error('\n❌ Failed to upload photo');
    process.exit(1);
  }

  // Update database
  await updateDatabaseWithPhoto(s3Url);

  console.log('\n✅ HMV Amsterdam photo fetch completed!');
  console.log(`📸 Photo URL: ${s3Url}`);
}

// Run the script
main().catch((error) => {
  console.error('❌ Fatal error:', error);
  process.exit(1);
});
