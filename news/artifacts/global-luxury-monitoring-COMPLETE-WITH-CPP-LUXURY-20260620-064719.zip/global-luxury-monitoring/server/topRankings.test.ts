import { describe, it, expect, beforeAll } from 'vitest';
import { getTopBrands, getTopStreets, getTopStreetsByCity } from './analytics';
import { getDb } from './db';

/**
 * Unit tests for Top 20 Rankings
 * Tests for brand rankings, street rankings, and city-specific rankings
 */

describe('Top 20 Rankings System', () => {
  let db: any;

  beforeAll(async () => {
    db = await getDb();
  });

  describe('getTopBrands', () => {
    it('should return top 20 brands by default', async () => {
      const brands = await getTopBrands();
      
      expect(brands).toBeDefined();
      expect(Array.isArray(brands)).toBe(true);
      expect(brands.length).toBeLessThanOrEqual(20);
      
      // Verify each brand has required fields
      brands.forEach(brand => {
        expect(brand.brand).toBeDefined();
        expect(brand.openings).toBeGreaterThan(0);
        expect(brand.percentage).toBeGreaterThan(0);
        expect(brand.percentage).toBeLessThanOrEqual(100);
      });
    });

    it('should respect custom limit parameter', async () => {
      const brands = await getTopBrands(10);
      
      expect(brands).toBeDefined();
      expect(brands.length).toBeLessThanOrEqual(10);
    });

    it('should return brands sorted by openings descending', async () => {
      const brands = await getTopBrands();
      
      for (let i = 0; i < brands.length - 1; i++) {
        expect(brands[i].openings).toBeGreaterThanOrEqual(brands[i + 1].openings);
      }
    });

    it('should calculate percentages correctly', async () => {
      const brands = await getTopBrands();
      
      if (brands.length > 0) {
        const totalPercentage = brands.reduce((sum, b) => sum + b.percentage, 0);
        expect(totalPercentage).toBeCloseTo(100, 0);
      }
    });
  });

  describe('getTopStreets', () => {
    it('should return top 20 streets by default', async () => {
      const streets = await getTopStreets();
      
      expect(streets).toBeDefined();
      expect(Array.isArray(streets)).toBe(true);
      expect(streets.length).toBeLessThanOrEqual(20);
      
      // Verify each street has required fields
      streets.forEach(street => {
        expect(street.street).toBeDefined();
        expect(street.city).toBeDefined();
        expect(street.openings).toBeGreaterThan(0);
        expect(street.brands).toBeGreaterThan(0);
      });
    });

    it('should respect custom limit parameter', async () => {
      const streets = await getTopStreets(10);
      
      expect(streets).toBeDefined();
      expect(streets.length).toBeLessThanOrEqual(10);
    });

    it('should return streets sorted by openings descending', async () => {
      const streets = await getTopStreets();
      
      for (let i = 0; i < streets.length - 1; i++) {
        expect(streets[i].openings).toBeGreaterThanOrEqual(streets[i + 1].openings);
      }
    });

    it('should exclude unknown streets', async () => {
      const streets = await getTopStreets();
      
      streets.forEach(street => {
        expect(street.street).not.toBe('Unknown');
      });
    });
  });

  describe('getTopStreetsByCity', () => {
    it('should return top 20 streets for a city by default', async () => {
      const streets = await getTopStreetsByCity('Paris', 20);
      
      expect(streets).toBeDefined();
      expect(Array.isArray(streets)).toBe(true);
      expect(streets.length).toBeLessThanOrEqual(20);
      
      // Verify each street is in the requested city
      streets.forEach(street => {
        expect(street.street).toBeDefined();
        expect(street.count).toBeGreaterThan(0);
        expect(Array.isArray(street.brands)).toBe(true);
      });
    });

    it('should respect custom limit parameter', async () => {
      const streets = await getTopStreetsByCity('London', 10);
      
      expect(streets).toBeDefined();
      expect(streets.length).toBeLessThanOrEqual(10);
    });

    it('should return streets sorted by count descending', async () => {
      const streets = await getTopStreetsByCity('Milan', 20);
      
      for (let i = 0; i < streets.length - 1; i++) {
        expect(streets[i].count).toBeGreaterThanOrEqual(streets[i + 1].count);
      }
    });

    it('should handle cities with no streets', async () => {
      const streets = await getTopStreetsByCity('NonExistentCity', 20);
      
      expect(streets).toBeDefined();
      expect(Array.isArray(streets)).toBe(true);
      expect(streets.length).toBe(0);
    });
  });

  describe('Top 20 Consistency', () => {
    it('should maintain consistent ranking order across calls', async () => {
      const brands1 = await getTopBrands();
      const brands2 = await getTopBrands();
      
      expect(brands1.length).toBe(brands2.length);
      
      for (let i = 0; i < brands1.length; i++) {
        expect(brands1[i].brand).toBe(brands2[i].brand);
        expect(brands1[i].openings).toBe(brands2[i].openings);
      }
    });

    it('should maintain consistent street ranking order across calls', async () => {
      const streets1 = await getTopStreets();
      const streets2 = await getTopStreets();
      
      expect(streets1.length).toBe(streets2.length);
      
      for (let i = 0; i < streets1.length; i++) {
        expect(streets1[i].street).toBe(streets2[i].street);
        expect(streets1[i].openings).toBe(streets2[i].openings);
      }
    });
  });

  describe('Limit Parameter Validation', () => {
    it('should handle limit 0', async () => {
      const brands = await getTopBrands(0);
      expect(brands).toBeDefined();
      expect(Array.isArray(brands)).toBe(true);
      expect(brands.length).toBe(0);
    });

    it('should handle very large limit values', async () => {
      const brands = await getTopBrands(1000);
      expect(brands).toBeDefined();
      expect(Array.isArray(brands)).toBe(true);
      // Should return all available brands, not error
    });

    it('should handle negative limit gracefully', async () => {
      const brands = await getTopBrands(-1);
      expect(brands).toBeDefined();
      expect(Array.isArray(brands)).toBe(true);
    });
  });
});
