import { describe, it, expect } from "vitest";

describe("GlobalCities", () => {
  const GLOBAL_CITIES = [
    {
      slug: "paris",
      name: "Paris",
      country: "Frankreich",
      stats: { stores: 156, flagships: 18, avgRent: "EUR 3,800/m²", vacancy: "1.8%" },
    },
    {
      slug: "london",
      name: "London",
      country: "Vereinigtes Königreich",
      stats: { stores: 142, flagships: 15, avgRent: "GBP 3,200/m²", vacancy: "2.2%" },
    },
    {
      slug: "new-york",
      name: "New York",
      country: "Vereinigte Staaten",
      stats: { stores: 189, flagships: 22, avgRent: "USD 4,500/m²", vacancy: "1.5%" },
    },
    {
      slug: "milan",
      name: "Mailand",
      country: "Italien",
      stats: { stores: 128, flagships: 14, avgRent: "EUR 3,200/m²", vacancy: "2.5%" },
    },
    {
      slug: "tokyo",
      name: "Tokio",
      country: "Japan",
      stats: { stores: 174, flagships: 19, avgRent: "JPY 450,000/m²", vacancy: "1.2%" },
    },
    {
      slug: "hong-kong",
      name: "Hongkong",
      country: "China",
      stats: { stores: 151, flagships: 16, avgRent: "HKD 2,800/m²", vacancy: "1.9%" },
    },
  ];

  it("should have 6 global cities", () => {
    expect(GLOBAL_CITIES).toHaveLength(6);
  });

  it("should have correct city names", () => {
    const names = GLOBAL_CITIES.map((c) => c.name);
    expect(names).toEqual([
      "Paris",
      "London",
      "New York",
      "Mailand",
      "Tokio",
      "Hongkong",
    ]);
  });

  it("should have correct slugs", () => {
    const slugs = GLOBAL_CITIES.map((c) => c.slug);
    expect(slugs).toEqual([
      "paris",
      "london",
      "new-york",
      "milan",
      "tokyo",
      "hong-kong",
    ]);
  });

  it("should have valid store counts for each city", () => {
    GLOBAL_CITIES.forEach((city) => {
      expect(city.stats.stores).toBeGreaterThan(100);
      expect(city.stats.stores).toBeLessThan(200);
    });
  });

  it("should have valid flagship store counts", () => {
    GLOBAL_CITIES.forEach((city) => {
      expect(city.stats.flagships).toBeGreaterThanOrEqual(14);
      expect(city.stats.flagships).toBeLessThanOrEqual(22);
    });
  });

  it("should have valid vacancy percentages", () => {
    GLOBAL_CITIES.forEach((city) => {
      const vacancy = parseFloat(city.stats.vacancy);
      expect(vacancy).toBeGreaterThan(0);
      expect(vacancy).toBeLessThan(5);
    });
  });

  it("should have New York as market leader", () => {
    const newYork = GLOBAL_CITIES.find((c) => c.slug === "new-york");
    const others = GLOBAL_CITIES.filter((c) => c.slug !== "new-york");

    others.forEach((other) => {
      expect(newYork!.stats.stores).toBeGreaterThan(other.stats.stores);
    });
  });

  it("should have Tokio with lowest vacancy", () => {
    const tokio = parseFloat(
      GLOBAL_CITIES.find((c) => c.slug === "tokyo")!.stats.vacancy
    );
    const others = GLOBAL_CITIES.filter((c) => c.slug !== "tokyo").map((c) =>
      parseFloat(c.stats.vacancy)
    );

    others.forEach((vacancy) => {
      expect(tokio).toBeLessThan(vacancy);
    });
  });

  it("should have correct total stores across all cities", () => {
    const totalStores = GLOBAL_CITIES.reduce(
      (sum, c) => sum + c.stats.stores,
      0
    );
    expect(totalStores).toBe(940); // 156 + 142 + 189 + 128 + 174 + 151
  });

  it("should have correct total flagship stores", () => {
    const totalFlagships = GLOBAL_CITIES.reduce(
      (sum, c) => sum + c.stats.flagships,
      0
    );
    expect(totalFlagships).toBe(104); // 18 + 15 + 22 + 14 + 19 + 16
  });

  it("should have New York with highest rent", () => {
    const newYorkRent = 4500;
    const others = GLOBAL_CITIES.filter((c) => c.slug !== "new-york")
      .map((c) => {
        const match = c.stats.avgRent.match(/\d+/);
        return parseInt(match?.[0] || "0");
      });

    others.forEach((rent) => {
      expect(newYorkRent).toBeGreaterThan(rent);
    });
  });

  it("should have all cities with different countries", () => {
    const countries = GLOBAL_CITIES.map((c) => c.country);
    const uniqueCountries = new Set(countries);
    expect(uniqueCountries.size).toBe(6);
  });

  it("should have Paris and London as European leaders", () => {
    const paris = GLOBAL_CITIES.find((c) => c.slug === "paris");
    const london = GLOBAL_CITIES.find((c) => c.slug === "london");
    const milan = GLOBAL_CITIES.find((c) => c.slug === "milan");

    expect(paris!.stats.stores).toBeGreaterThan(milan!.stats.stores);
    expect(london!.stats.stores).toBeGreaterThan(milan!.stats.stores);
  });

  it("should calculate correct average stores per city", () => {
    const totalStores = GLOBAL_CITIES.reduce(
      (sum, c) => sum + c.stats.stores,
      0
    );
    const avgStores = totalStores / GLOBAL_CITIES.length;
    expect(avgStores).toBeCloseTo(156.67, 1);
  });
});
