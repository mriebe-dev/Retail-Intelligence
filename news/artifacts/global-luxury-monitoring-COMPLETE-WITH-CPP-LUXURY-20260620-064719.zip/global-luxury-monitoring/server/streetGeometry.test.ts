import { describe, it, expect } from "vitest";
import {
  getPointAlongStreet,
  getStreetGeometry,
  getStreetsForCity,
  calculateDistance,
  findClosestStreet,
  STREET_GEOMETRY,
} from "./streetGeometry";

describe("Street Geometry Service", () => {
  describe("getPointAlongStreet", () => {
    it("should return start point when distance is 0", () => {
      const street = STREET_GEOMETRY[0]; // Bahnhofstrasse Zurich
      const point = getPointAlongStreet(street, 0);
      expect(point.lat).toBeCloseTo(street.startLat, 5);
      expect(point.lng).toBeCloseTo(street.startLng, 5);
    });

    it("should return end point when distance equals street length", () => {
      const street = STREET_GEOMETRY[0]; // Bahnhofstrasse Zurich
      const point = getPointAlongStreet(street, street.length);
      expect(point.lat).toBeCloseTo(street.endLat, 5);
      expect(point.lng).toBeCloseTo(street.endLng, 5);
    });

    it("should return midpoint when distance is half of street length", () => {
      const street = STREET_GEOMETRY[0]; // Bahnhofstrasse Zurich
      const point = getPointAlongStreet(street, street.length / 2);
      const expectedLat = street.startLat + (street.endLat - street.startLat) * 0.5;
      const expectedLng = street.startLng + (street.endLng - street.startLng) * 0.5;
      expect(point.lat).toBeCloseTo(expectedLat, 5);
      expect(point.lng).toBeCloseTo(expectedLng, 5);
    });

    it("should handle zero-length streets", () => {
      const street = STREET_GEOMETRY.find((s) => s.length === 0);
      if (street) {
        const point = getPointAlongStreet(street, 100);
        expect(point.lat).toBe(street.startLat);
        expect(point.lng).toBe(street.startLng);
      }
    });

    it("should cap distance at street length", () => {
      const street = STREET_GEOMETRY[0]; // Bahnhofstrasse Zurich
      const point = getPointAlongStreet(street, street.length * 2);
      expect(point.lat).toBeCloseTo(street.endLat, 5);
      expect(point.lng).toBeCloseTo(street.endLng, 5);
    });
  });

  describe("getStreetGeometry", () => {
    it("should find Bahnhofstrasse in Zurich", () => {
      const street = getStreetGeometry("Zurich", "Bahnhofstrasse");
      expect(street).toBeDefined();
      expect(street?.city).toBe("Zurich");
      expect(street?.streetName).toBe("Bahnhofstrasse");
    });

    it("should find Rue du Rhône in Geneva", () => {
      const street = getStreetGeometry("Geneva", "Rue du Rhône");
      expect(street).toBeDefined();
      expect(street?.city).toBe("Geneva");
    });

    it("should return undefined for non-existent street", () => {
      const street = getStreetGeometry("NonExistent", "NonExistent");
      expect(street).toBeUndefined();
    });

    it("should be case-sensitive", () => {
      const street = getStreetGeometry("zurich", "bahnhofstrasse");
      expect(street).toBeUndefined();
    });
  });

  describe("getStreetsForCity", () => {
    it("should return all streets for Zurich", () => {
      const streets = getStreetsForCity("Zurich");
      expect(streets.length).toBeGreaterThan(0);
      expect(streets.every((s) => s.city === "Zurich")).toBe(true);
    });

    it("should return all streets for Munich", () => {
      const streets = getStreetsForCity("Munich");
      expect(streets.length).toBeGreaterThan(0);
      expect(streets.every((s) => s.city === "Munich")).toBe(true);
    });

    it("should return empty array for non-existent city", () => {
      const streets = getStreetsForCity("NonExistent");
      expect(streets.length).toBe(0);
    });
  });

  describe("calculateDistance", () => {
    it("should return 0 for same coordinates", () => {
      const distance = calculateDistance(47.3773, 8.5391, 47.3773, 8.5391);
      expect(distance).toBeLessThan(1);
    });

    it("should calculate distance between Zurich and Geneva", () => {
      // Zurich: 47.3773, 8.5391
      // Geneva: 46.1954, 6.1424
      const distance = calculateDistance(47.3773, 8.5391, 46.1954, 6.1424);
      // Approximate distance is ~225 km
      expect(distance).toBeGreaterThan(200000);
      expect(distance).toBeLessThan(250000);
    });

    it("should calculate distance between London and Paris", () => {
      // London: 51.5137, -0.1493
      // Paris: 48.8698, 2.3076
      const distance = calculateDistance(51.5137, -0.1493, 48.8698, 2.3076);
      // Approximate distance is ~340 km
      expect(distance).toBeGreaterThan(300000);
      expect(distance).toBeLessThan(400000);
    });
  });

  describe("findClosestStreet", () => {
    it("should find closest street in Zurich", () => {
      const result = findClosestStreet(47.3773, 8.5391, "Zurich");
      expect(result).toBeDefined();
      expect(result?.street.city).toBe("Zurich");
      expect(result?.distance).toBeLessThan(1000);
    });

    it("should find closest street globally", () => {
      const result = findClosestStreet(47.3773, 8.5391);
      expect(result).toBeDefined();
      expect(result?.street.city).toBe("Zurich");
    });

    it("should return undefined for non-existent city", () => {
      const result = findClosestStreet(47.3773, 8.5391, "NonExistent");
      expect(result).toBeUndefined();
    });

    it("should find closest street in New York", () => {
      const result = findClosestStreet(40.7580, -73.9855, "New York");
      expect(result).toBeDefined();
      expect(result?.street.city).toBe("New York");
    });
  });

  describe("STREET_GEOMETRY database", () => {
    it("should have valid coordinates", () => {
      for (const street of STREET_GEOMETRY) {
        expect(street.startLat).toBeGreaterThanOrEqual(-90);
        expect(street.startLat).toBeLessThanOrEqual(90);
        expect(street.startLng).toBeGreaterThanOrEqual(-180);
        expect(street.startLng).toBeLessThanOrEqual(180);
        expect(street.endLat).toBeGreaterThanOrEqual(-90);
        expect(street.endLat).toBeLessThanOrEqual(90);
        expect(street.endLng).toBeGreaterThanOrEqual(-180);
        expect(street.endLng).toBeLessThanOrEqual(180);
      }
    });

    it("should have valid street lengths", () => {
      for (const street of STREET_GEOMETRY) {
        expect(street.length).toBeGreaterThanOrEqual(0);
      }
    });

    it("should have valid directions", () => {
      const validDirections = ["N-S", "E-W", "NE-SW", "NW-SE"];
      for (const street of STREET_GEOMETRY) {
        expect(validDirections).toContain(street.direction);
      }
    });

    it("should have at least 30 streets", () => {
      expect(STREET_GEOMETRY.length).toBeGreaterThanOrEqual(30);
    });
  });
});
