import { router, publicProcedure, protectedProcedure, adminProcedure } from './_core/trpc';
import { z } from 'zod';
import { getDb } from './db';
import { investmentDeals } from '../drizzle/schema';
import { eq, like, and, isNull } from 'drizzle-orm';
import crypto from 'crypto';

const investmentDealInput = z.object({
  propertyName: z.string(),
  brandName: z.string(),
  city: z.string(),
  country: z.string(),
  street: z.string().optional(),
  dealDate: z.string(),
  completionDate: z.string().optional(),
  dealType: z.enum(['Sale', 'Lease', 'Development', 'Renovation', 'Acquisition']),
  dealValue: z.number().optional(),
  currency: z.string().optional(),
  squareMeters: z.number().optional(),
  seller: z.string().optional(),
  buyer: z.string().optional(),
  terms: z.string().optional(),
  irr: z.number().optional(),
  description: z.string().optional(),
  source: z.string(),
  link: z.string(),
  photoUrl: z.string().optional(),
  latitude: z.string().optional(),
  longitude: z.string().optional(),
});

export const investmentDealsRouter = router({
  // Get all investment deals
  getAll: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    const deals = await db.select().from(investmentDeals).orderBy(investmentDeals.dealDate);
    return deals;
  }),

  // Get deals by city
  getByCity: publicProcedure
    .input(z.object({ city: z.string() }))
    .query(async ({ input }: any) => {
      const db = await getDb();
      if (!db) return [];
      const deals = await db
        .select()
        .from(investmentDeals)
        .where(like(investmentDeals.city, `%${input.city}%`))
        .orderBy(investmentDeals.dealDate);
      return deals;
    }),

  // Get deals by brand
  getByBrand: publicProcedure
    .input(z.object({ brand: z.string() }))
    .query(async ({ input }: any) => {
      const db = await getDb();
      if (!db) return [];
      const deals = await db
        .select()
        .from(investmentDeals)
        .where(like(investmentDeals.brandName, `%${input.brand}%`))
        .orderBy(investmentDeals.dealDate);
      return deals;
    }),

  // Get deals by type
  getByType: publicProcedure
    .input(z.object({ type: z.enum(['Sale', 'Lease', 'Development', 'Renovation', 'Acquisition']) }))
    .query(async ({ input }: any) => {
      const db = await getDb();
      if (!db) return [];
      
      const deals = await db
        .select()
        .from(investmentDeals)
        .where(eq(investmentDeals.dealType, input.type))
        .orderBy(investmentDeals.dealDate);
      return deals;
    }),

  // Get top deals by value
  getTopByValue: publicProcedure
    .input(z.object({ limit: z.number().default(20) }))
    .query(async ({ input }: any) => {
      const db = await getDb();
      if (!db) return [];
      
      const deals = await db
        .select()
        .from(investmentDeals)
        .orderBy(investmentDeals.dealValue)
        .limit(input.limit);
      return deals;
    }),

  // Add new investment deal (admin only)
  add: adminProcedure
    .input(investmentDealInput)
    .mutation(async ({ input }: any) => {
      const db = await getDb();
      if (!db) return null;
      
      const urlHash = crypto.createHash('sha256').update(input.link).digest('hex');

      const result = await db.insert(investmentDeals).values({
        urlHash,
        propertyName: input.propertyName,
        brandName: input.brandName,
        city: input.city,
        country: input.country,
        street: input.street,
        dealDate: input.dealDate,
        completionDate: input.completionDate,
        dealType: input.dealType,
        dealValue: input.dealValue,
        currency: input.currency,
        squareMeters: input.squareMeters,
        seller: input.seller,
        buyer: input.buyer,
        terms: input.terms,
        irr: input.irr,
        description: input.description,
        source: input.source,
        link: input.link,
        photoUrl: input.photoUrl,
        latitude: input.latitude,
        longitude: input.longitude,
      });

      return result;
    }),

  // Batch import deals (admin only)
  batchImport: adminProcedure
    .input(z.array(investmentDealInput))
    .mutation(async ({ input }: any) => {
      const db = await getDb();
      if (!db) return { count: 0 };
      
      const deals = input.map((deal: any) => ({
        urlHash: crypto.createHash('sha256').update(deal.link).digest('hex'),
        propertyName: deal.propertyName,
        brandName: deal.brandName,
        city: deal.city,
        country: deal.country,
        street: deal.street,
        dealDate: deal.dealDate,
        completionDate: deal.completionDate,
        dealType: deal.dealType,
        dealValue: deal.dealValue,
        currency: deal.currency,
        squareMeters: deal.squareMeters,
        seller: deal.seller,
        buyer: deal.buyer,
        terms: deal.terms,
        irr: deal.irr,
        description: deal.description,
        source: deal.source,
        link: deal.link,
        photoUrl: deal.photoUrl,
        latitude: deal.latitude,
        longitude: deal.longitude,
      }));

      const result = await db.insert(investmentDeals).values(deals);
      return { count: deals.length };
    }),

  // Update deal (admin only)
  update: adminProcedure
    .input(
      z.object({
        id: z.number(),
        data: investmentDealInput.partial(),
      })
    )
    .mutation(async ({ input }: any) => {
      const db = await getDb();
      if (!db) return null;
      
      const result = await db
        .update(investmentDeals)
        .set(input.data)
        .where(eq(investmentDeals.id, input.id));
      return result;
    }),

  // Delete deal (admin only)
  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }: any) => {
      const db = await getDb();
      if (!db) return null;
      
      const result = await db.delete(investmentDeals).where(eq(investmentDeals.id, input.id));
      return result;
    }),

  // Get statistics
  getStats: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return { totalDeals: 0, totalValue: 0, avgValue: 0, dealsByType: {} };
    
    const deals = await db.select().from(investmentDeals);
    const totalDeals = deals.length;
    const totalValue = deals.reduce((sum: number, d: any) => sum + (d.dealValue || 0), 0);
    const avgValue = totalValue / totalDeals;
    const dealsByType = deals.reduce(
      (acc: Record<string, number>, d: any) => {
        acc[d.dealType] = (acc[d.dealType] || 0) + 1;
        return acc;
      },
      {} as Record<string, number>
    );

    return {
      totalDeals,
      totalValue,
      avgValue,
      dealsByType,
    };
  }),
});
