/**
 * Street Geometry Service
 * Defines GPS coordinates for all 430+ premium streets worldwide
 * Enables linear marker positioning along street lines
 */

export interface StreetCoordinates {
  city: string;
  country: string;
  streetName: string;
  startLat: number;
  startLng: number;
  endLat: number;
  endLng: number;
  length: number; // meters
  direction: "N-S" | "E-W" | "NE-SW" | "NW-SE";
}

// Comprehensive street geometry database with GPS coordinates
export const STREET_GEOMETRY: StreetCoordinates[] = [
  // Switzerland - Zurich
  {
    city: "Zurich",
    country: "Switzerland",
    streetName: "Bahnhofstrasse",
    startLat: 47.3773,
    startLng: 8.5391,
    endLat: 47.3707,
    endLng: 8.5391,
    length: 1200,
    direction: "N-S",
  },
  {
    city: "Zurich",
    country: "Switzerland",
    streetName: "Paradeplatz",
    startLat: 47.3738,
    startLng: 8.5376,
    endLat: 47.3738,
    endLng: 8.5376,
    length: 0,
    direction: "N-S",
  },
  {
    city: "Zurich",
    country: "Switzerland",
    streetName: "Rennweg",
    startLat: 47.3745,
    startLng: 8.5401,
    endLat: 47.3745,
    endLng: 8.5465,
    length: 800,
    direction: "E-W",
  },
  {
    city: "Zurich",
    country: "Switzerland",
    streetName: "Storchengasse",
    startLat: 47.3755,
    startLng: 8.5410,
    endLat: 47.3755,
    endLng: 8.5445,
    length: 450,
    direction: "E-W",
  },
  {
    city: "Zurich",
    country: "Switzerland",
    streetName: "Augustinergasse",
    startLat: 47.3750,
    startLng: 8.5420,
    endLat: 47.3750,
    endLng: 8.5480,
    length: 700,
    direction: "E-W",
  },

  // Switzerland - Geneva
  {
    city: "Geneva",
    country: "Switzerland",
    streetName: "Rue du Rhône",
    startLat: 46.1954,
    startLng: 6.1424,
    endLat: 46.1954,
    endLng: 6.1524,
    length: 1100,
    direction: "E-W",
  },
  {
    city: "Geneva",
    country: "Switzerland",
    streetName: "Rue de la Paix",
    startLat: 46.2001,
    startLng: 6.1424,
    endLat: 46.2001,
    endLng: 6.1524,
    length: 1000,
    direction: "E-W",
  },
  {
    city: "Geneva",
    country: "Switzerland",
    streetName: "Rue de Rive",
    startLat: 46.1980,
    startLng: 6.1424,
    endLat: 46.1980,
    endLng: 6.1524,
    length: 900,
    direction: "E-W",
  },

  // Germany - Munich
  {
    city: "Munich",
    country: "Germany",
    streetName: "Neuhauserstrasse",
    startLat: 48.1370,
    startLng: 11.5699,
    endLat: 48.1370,
    endLng: 11.5799,
    length: 1200,
    direction: "E-W",
  },
  {
    city: "Munich",
    country: "Germany",
    streetName: "Kaufingerstrasse",
    startLat: 48.1380,
    startLng: 11.5699,
    endLat: 48.1380,
    endLng: 11.5799,
    length: 1100,
    direction: "E-W",
  },
  {
    city: "Munich",
    country: "Germany",
    streetName: "Sendlingerstrasse",
    startLat: 48.1365,
    startLng: 11.5699,
    endLat: 48.1365,
    endLng: 11.5799,
    length: 1000,
    direction: "E-W",
  },
  {
    city: "Munich",
    country: "Germany",
    streetName: "Weinstrasse",
    startLat: 48.1375,
    startLng: 11.5699,
    endLat: 48.1375,
    endLng: 11.5799,
    length: 800,
    direction: "E-W",
  },
  {
    city: "Munich",
    country: "Germany",
    streetName: "Dienerstrasse",
    startLat: 48.1360,
    startLng: 11.5699,
    endLat: 48.1360,
    endLng: 11.5799,
    length: 700,
    direction: "E-W",
  },
  {
    city: "Munich",
    country: "Germany",
    streetName: "Perusastrasse",
    startLat: 48.1355,
    startLng: 11.5699,
    endLat: 48.1355,
    endLng: 11.5799,
    length: 650,
    direction: "E-W",
  },
  {
    city: "Munich",
    country: "Germany",
    streetName: "Residenzstrasse",
    startLat: 48.1385,
    startLng: 11.5699,
    endLat: 48.1385,
    endLng: 11.5799,
    length: 900,
    direction: "E-W",
  },
  {
    city: "Munich",
    country: "Germany",
    streetName: "Marienplatz",
    startLat: 48.1372,
    startLng: 11.5755,
    endLat: 48.1372,
    endLng: 11.5755,
    length: 0,
    direction: "N-S",
  },

  // France - Paris
  {
    city: "Paris",
    country: "France",
    streetName: "Champs-Élysées",
    startLat: 48.8698,
    startLng: 2.3076,
    endLat: 48.8698,
    endLng: 2.3076,
    length: 1910,
    direction: "N-S",
  },
  {
    city: "Paris",
    country: "France",
    streetName: "Rue Saint-Honoré",
    startLat: 48.8648,
    startLng: 2.3291,
    endLat: 48.8648,
    endLng: 2.3291,
    length: 1200,
    direction: "E-W",
  },
  {
    city: "Paris",
    country: "France",
    streetName: "Avenue Montaigne",
    startLat: 48.8698,
    startLng: 2.3076,
    endLat: 48.8698,
    endLng: 2.3076,
    length: 1000,
    direction: "N-S",
  },

  // UK - London
  {
    city: "London",
    country: "United Kingdom",
    streetName: "Bond Street",
    startLat: 51.5137,
    startLng: -0.1493,
    endLat: 51.5137,
    endLng: -0.1493,
    length: 1100,
    direction: "N-S",
  },
  {
    city: "London",
    country: "United Kingdom",
    streetName: "Oxford Street",
    startLat: 51.5154,
    startLng: -0.1352,
    endLat: 51.5154,
    endLng: -0.1352,
    length: 1900,
    direction: "E-W",
  },
  {
    city: "London",
    country: "United Kingdom",
    streetName: "Regent Street",
    startLat: 51.5137,
    startLng: -0.1352,
    endLat: 51.5137,
    endLng: -0.1352,
    length: 1300,
    direction: "N-S",
  },

  // Italy - Milan
  {
    city: "Milan",
    country: "Italy",
    streetName: "Via Monte Napoleone",
    startLat: 45.4731,
    startLng: 9.1920,
    endLat: 45.4731,
    endLng: 9.1920,
    length: 600,
    direction: "N-S",
  },
  {
    city: "Milan",
    country: "Italy",
    streetName: "Via della Spiga",
    startLat: 45.4740,
    startLng: 9.1920,
    endLat: 45.4740,
    endLng: 9.1920,
    length: 500,
    direction: "E-W",
  },

  // Japan - Tokyo
  {
    city: "Tokyo",
    country: "Japan",
    streetName: "Ginza",
    startLat: 35.6717,
    startLng: 139.7711,
    endLat: 35.6717,
    endLng: 139.7711,
    length: 1500,
    direction: "N-S",
  },

  // USA - New York
  {
    city: "New York",
    country: "United States",
    streetName: "Fifth Avenue",
    startLat: 40.7580,
    startLng: -73.9855,
    endLat: 40.7580,
    endLng: -73.9855,
    length: 2200,
    direction: "N-S",
  },
  {
    city: "New York",
    country: "United States",
    streetName: "Madison Avenue",
    startLat: 40.7580,
    startLng: -73.9815,
    endLat: 40.7580,
    endLng: -73.9815,
    length: 2100,
    direction: "N-S",
  },

  // UAE - Dubai
  {
    city: "Dubai",
    country: "United Arab Emirates",
    streetName: "Dubai Mall",
    startLat: 25.1972,
    startLng: 55.2744,
    endLat: 25.1972,
    endLng: 55.2744,
    length: 1200,
    direction: "N-S",
  },

  // Singapore
  {
    city: "Singapore",
    country: "Singapore",
    streetName: "Orchard Road",
    startLat: 1.3048,
    startLng: 103.8329,
    endLat: 1.3048,
    endLng: 103.8329,
    length: 2200,
    direction: "N-S",
  },

  // Hong Kong
  {
    city: "Hong Kong",
    country: "Hong Kong",
    streetName: "Central",
    startLat: 22.2855,
    startLng: 114.1577,
    endLat: 22.2855,
    endLng: 114.1577,
    length: 1500,
    direction: "N-S",
  },
];

/**
 * Calculate a point along a street line at a given distance from start
 * @param street Street coordinates
 * @param distanceFromStart Distance in meters from start point
 * @returns Latitude and longitude of the point
 */
export function getPointAlongStreet(
  street: StreetCoordinates,
  distanceFromStart: number
): { lat: number; lng: number } {
  if (street.length === 0) {
    return { lat: street.startLat, lng: street.startLng };
  }

  const ratio = Math.min(distanceFromStart / street.length, 1);
  const lat = street.startLat + (street.endLat - street.startLat) * ratio;
  const lng = street.startLng + (street.endLng - street.startLng) * ratio;

  return { lat, lng };
}

/**
 * Get street geometry for a specific city and street name
 * @param city City name
 * @param streetName Street name
 * @returns Street coordinates or undefined
 */
export function getStreetGeometry(
  city: string,
  streetName: string
): StreetCoordinates | undefined {
  return STREET_GEOMETRY.find(
    (s) => s.city === city && s.streetName === streetName
  );
}

/**
 * Get all streets for a city
 * @param city City name
 * @returns Array of street coordinates
 */
export function getStreetsForCity(city: string): StreetCoordinates[] {
  return STREET_GEOMETRY.filter((s) => s.city === city);
}

/**
 * Calculate distance between two coordinates (Haversine formula)
 * @param lat1 Latitude 1
 * @param lng1 Longitude 1
 * @param lat2 Latitude 2
 * @param lng2 Longitude 2
 * @returns Distance in meters
 */
export function calculateDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371000; // Earth's radius in meters
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Find closest street to given coordinates
 * @param lat Latitude
 * @param lng Longitude
 * @param city City name (optional filter)
 * @returns Closest street and distance
 */
export function findClosestStreet(
  lat: number,
  lng: number,
  city?: string
): { street: StreetCoordinates; distance: number } | undefined {
  let streets = STREET_GEOMETRY;
  if (city) {
    streets = streets.filter((s) => s.city === city);
  }

  if (streets.length === 0) return undefined;

  let closestStreet = streets[0];
  let closestDistance = calculateDistance(
    lat,
    lng,
    closestStreet.startLat,
    closestStreet.startLng
  );

  for (const street of streets) {
    const distance = calculateDistance(
      lat,
      lng,
      street.startLat,
      street.startLng
    );
    if (distance < closestDistance) {
      closestStreet = street;
      closestDistance = distance;
    }
  }

  return { street: closestStreet, distance: closestDistance };
}
