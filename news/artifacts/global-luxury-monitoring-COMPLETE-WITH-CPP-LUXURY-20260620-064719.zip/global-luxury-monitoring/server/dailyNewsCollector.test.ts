import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import {
  generateUrlHash,
  collectFromLinkedIn,
  collectFromRetailJournal,
  collectFromWWD,
  collectFromGoogleNews,
  runAllDailyCollectors,
  getCollectorStatus,
} from "./dailyNewsCollector";

describe("Daily News Collector", () => {
  describe("generateUrlHash", () => {
    it("should generate consistent hash for same URL", () => {
      const url = "https://www.linkedin.com/posts/test-123";
      const hash1 = generateUrlHash(url);
      const hash2 = generateUrlHash(url);
      expect(hash1).toBe(hash2);
    });

    it("should generate different hashes for different URLs", () => {
      const url1 = "https://www.linkedin.com/posts/test-123";
      const url2 = "https://www.linkedin.com/posts/test-456";
      const hash1 = generateUrlHash(url1);
      const hash2 = generateUrlHash(url2);
      expect(hash1).not.toBe(hash2);
    });

    it("should generate 64-character SHA256 hash", () => {
      const url = "https://www.example.com/news";
      const hash = generateUrlHash(url);
      expect(hash).toHaveLength(64);
      expect(/^[a-f0-9]{64}$/.test(hash)).toBe(true);
    });
  });

  describe("collectFromLinkedIn", () => {
    it("should return CollectorResult with LinkedIn source", async () => {
      const result = await collectFromLinkedIn();
      expect(result.source).toBe("LinkedIn");
      expect(result).toHaveProperty("added");
      expect(result).toHaveProperty("duplicates");
      expect(result).toHaveProperty("errors");
      expect(result).toHaveProperty("timestamp");
    });

    it("should add news items successfully", async () => {
      const result = await collectFromLinkedIn();
      expect(result.added).toBeGreaterThanOrEqual(0);
    });

    it("should have valid timestamp", async () => {
      const result = await collectFromLinkedIn();
      const timestamp = new Date(result.timestamp);
      expect(timestamp.getTime()).toBeGreaterThan(0);
    });
  });

  describe("collectFromRetailJournal", () => {
    it("should return CollectorResult with Retail Journal source", async () => {
      const result = await collectFromRetailJournal();
      expect(result.source).toBe("Retail Journal");
      expect(result).toHaveProperty("added");
      expect(result).toHaveProperty("duplicates");
      expect(result).toHaveProperty("errors");
    });

    it("should have valid numeric counts", async () => {
      const result = await collectFromRetailJournal();
      expect(typeof result.added).toBe("number");
      expect(typeof result.duplicates).toBe("number");
      expect(typeof result.errors).toBe("number");
      expect(result.added).toBeGreaterThanOrEqual(0);
      expect(result.duplicates).toBeGreaterThanOrEqual(0);
      expect(result.errors).toBeGreaterThanOrEqual(0);
    });
  });

  describe("collectFromWWD", () => {
    it("should return CollectorResult with WWD source", async () => {
      const result = await collectFromWWD();
      expect(result.source).toBe("WWD");
      expect(result).toHaveProperty("added");
      expect(result).toHaveProperty("duplicates");
      expect(result).toHaveProperty("errors");
    });

    it("should collect fashion-related news", async () => {
      const result = await collectFromWWD();
      expect(result.added).toBeGreaterThanOrEqual(0);
    });
  });

  describe("collectFromGoogleNews", () => {
    it("should return CollectorResult with Google News source", async () => {
      const result = await collectFromGoogleNews();
      expect(result.source).toBe("Google News");
      expect(result).toHaveProperty("added");
      expect(result).toHaveProperty("duplicates");
      expect(result).toHaveProperty("errors");
    });

    it("should have valid timestamp format", async () => {
      const result = await collectFromGoogleNews();
      expect(result.timestamp).toMatch(/^\d{4}-\d{2}-\d{2}T/);
    });
  });

  describe("runAllDailyCollectors", () => {
    it("should return aggregated results from all collectors", async () => {
      const result = await runAllDailyCollectors();
      expect(result).toHaveProperty("results");
      expect(result).toHaveProperty("totalAdded");
      expect(result).toHaveProperty("totalDuplicates");
      expect(result).toHaveProperty("totalErrors");
      expect(result).toHaveProperty("timestamp");
    });

    it("should have array of results from each collector", async () => {
      const result = await runAllDailyCollectors();
      expect(Array.isArray(result.results)).toBe(true);
      expect(result.results.length).toBeGreaterThanOrEqual(0);
    });

    it("should aggregate counts correctly", async () => {
      const result = await runAllDailyCollectors();
      expect(typeof result.totalAdded).toBe("number");
      expect(typeof result.totalDuplicates).toBe("number");
      expect(typeof result.totalErrors).toBe("number");
      expect(result.totalAdded).toBeGreaterThanOrEqual(0);
      expect(result.totalDuplicates).toBeGreaterThanOrEqual(0);
      expect(result.totalErrors).toBeGreaterThanOrEqual(0);
    });

    it("should include all four collector sources", async () => {
      const result = await runAllDailyCollectors();
      const sources = result.results.map((r) => r.source);
      expect(sources).toContain("LinkedIn");
      expect(sources).toContain("Retail Journal");
      expect(sources).toContain("WWD");
      expect(sources).toContain("Google News");
    });

    it("should have valid timestamp", async () => {
      const result = await runAllDailyCollectors();
      const timestamp = new Date(result.timestamp);
      expect(timestamp.getTime()).toBeGreaterThan(0);
    });
  });

  describe("getCollectorStatus", () => {
    it("should return collector status object", async () => {
      const status = await getCollectorStatus();
      expect(status).toHaveProperty("nextRun");
      expect(status).toHaveProperty("isRunning");
      expect(status).toHaveProperty("status");
    });

    it("should have isRunning as boolean", async () => {
      const status = await getCollectorStatus();
      expect(typeof status.isRunning).toBe("boolean");
    });

    it("should have valid nextRun timestamp", async () => {
      const status = await getCollectorStatus();
      const nextRun = new Date(status.nextRun);
      expect(nextRun.getTime()).toBeGreaterThan(Date.now());
    });

    it("should schedule for 08:00 UTC", async () => {
      const status = await getCollectorStatus();
      const nextRun = new Date(status.nextRun);
      expect(nextRun.getUTCHours()).toBe(8);
      expect(nextRun.getUTCMinutes()).toBe(0);
    });

    it("should have descriptive status message", async () => {
      const status = await getCollectorStatus();
      expect(typeof status.status).toBe("string");
      expect(status.status.length).toBeGreaterThan(0);
    });
  });

  describe("Collector Integration", () => {
    it("should run all collectors without errors", async () => {
      const result = await runAllDailyCollectors();
      expect(result.totalErrors).toBe(0);
    });

    it("should maintain data consistency across runs", async () => {
      const result1 = await runAllDailyCollectors();
      const result2 = await runAllDailyCollectors();

      // Both runs should complete successfully
      expect(result1.totalAdded).toBeGreaterThanOrEqual(0);
      expect(result2.totalAdded).toBeGreaterThanOrEqual(0);
    }, { timeout: 60000 });

    it("should handle multiple collectors sequentially", async () => {
      const result = await runAllDailyCollectors();
      expect(result.results.length).toBe(4);

      // Each collector should have completed
      for (const collectorResult of result.results) {
        expect(collectorResult).toHaveProperty("source");
        expect(collectorResult).toHaveProperty("added");
        expect(collectorResult).toHaveProperty("duplicates");
        expect(collectorResult).toHaveProperty("errors");
      }
    }, { timeout: 60000 });
  });
});
