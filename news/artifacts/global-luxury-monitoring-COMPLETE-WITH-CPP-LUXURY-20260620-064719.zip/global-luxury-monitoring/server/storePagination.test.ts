import { describe, it, expect } from "vitest";

describe("StorePagination", () => {
  const mockStores = Array.from({ length: 130 }, (_, i) => ({
    id: i + 1,
    brandName: `Brand ${i + 1}`,
    city: "Zurich",
    locationAddress: `Street ${i + 1}`,
  }));

  const itemsPerPage = 10;

  it("should calculate correct number of pages", () => {
    const totalPages = Math.ceil(mockStores.length / itemsPerPage);
    expect(totalPages).toBe(13);
  });

  it("should paginate stores correctly", () => {
    const currentPage = 1;
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedStores = mockStores.slice(startIndex, endIndex);

    expect(paginatedStores).toHaveLength(10);
    expect(paginatedStores[0].id).toBe(1);
    expect(paginatedStores[9].id).toBe(10);
  });

  it("should paginate to page 2 correctly", () => {
    const currentPage = 2;
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedStores = mockStores.slice(startIndex, endIndex);

    expect(paginatedStores).toHaveLength(10);
    expect(paginatedStores[0].id).toBe(11);
    expect(paginatedStores[9].id).toBe(20);
  });

  it("should paginate to last page correctly", () => {
    const currentPage = 13;
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedStores = mockStores.slice(startIndex, endIndex);

    expect(paginatedStores).toHaveLength(10);
    expect(paginatedStores[0].id).toBe(121);
    expect(paginatedStores[9].id).toBe(130);
  });

  it("should handle single page correctly", () => {
    const singlePageStores = mockStores.slice(0, 10);
    const totalPages = Math.ceil(singlePageStores.length / itemsPerPage);

    expect(totalPages).toBe(1);
  });

  it("should handle empty stores list", () => {
    const emptyStores: typeof mockStores = [];
    const totalPages = Math.ceil(emptyStores.length / itemsPerPage);

    expect(totalPages).toBe(0);
  });

  it("should calculate correct start and end indices for each page", () => {
    for (let page = 1; page <= 13; page++) {
      const startIndex = (page - 1) * itemsPerPage;
      const endIndex = startIndex + itemsPerPage;

      if (page < 13) {
        expect(endIndex - startIndex).toBe(itemsPerPage);
      } else {
        expect(endIndex - startIndex).toBe(itemsPerPage);
      }
    }
  });

  it("should handle pagination with filtered stores", () => {
    const filteredStores = mockStores.filter((s) => s.id % 2 === 0); // 65 stores
    const totalPages = Math.ceil(filteredStores.length / itemsPerPage);

    expect(filteredStores).toHaveLength(65);
    expect(totalPages).toBe(7);
  });

  it("should maintain store order during pagination", () => {
    const currentPage = 5;
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedStores = mockStores.slice(startIndex, endIndex);

    for (let i = 0; i < paginatedStores.length - 1; i++) {
      expect(paginatedStores[i].id).toBeLessThan(paginatedStores[i + 1].id);
    }
  });

  it("should calculate correct page info display", () => {
    const currentPage = 3;
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = Math.min(currentPage * itemsPerPage, mockStores.length);
    const displayStart = startIndex + 1;
    const displayEnd = endIndex;

    expect(displayStart).toBe(21);
    expect(displayEnd).toBe(30);
  });

  it("should handle last page with fewer items", () => {
    const currentPage = 13;
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = Math.min(currentPage * itemsPerPage, mockStores.length);
    const itemsOnPage = endIndex - startIndex;

    expect(itemsOnPage).toBe(10);
  });

  it("should validate page boundaries", () => {
    const totalPages = Math.ceil(mockStores.length / itemsPerPage);

    // Page 1 should be valid
    expect(1).toBeGreaterThanOrEqual(1);
    expect(1).toBeLessThanOrEqual(totalPages);

    // Last page should be valid
    expect(totalPages).toBeGreaterThanOrEqual(1);
    expect(totalPages).toBeLessThanOrEqual(totalPages);

    // Out of bounds should be invalid
    expect(0).toBeLessThan(1);
    expect(totalPages + 1).toBeGreaterThan(totalPages);
  });

  it("should calculate pagination for different page sizes", () => {
    const pageSize5 = Math.ceil(mockStores.length / 5);
    const pageSize20 = Math.ceil(mockStores.length / 20);
    const pageSize50 = Math.ceil(mockStores.length / 50);

    expect(pageSize5).toBe(26);
    expect(pageSize20).toBe(7);
    expect(pageSize50).toBe(3);
  });
});
