import { describe, it, expect } from "vitest";
import {
  calculateLinearOffset,
  haversineDistance,
  arrangeMarkersOnStreet,
  applyMarkerSpacing,
  interpolateCoordinate,
  extractStreetName,
  calculateMarkerDensity,
  getVisibleMarkers,
  MarkerPosition,
} from "./markerArrangement";

describe("markerArrangement", () => {
  // Test haversineDistance
  describe("haversineDistance", () => {
    it("should calculate distance between two points", () => {
      // Zurich to Geneva (approx 225 km)
      const distance = haversineDistance(47.3769, 8.5472, 46.2044, 6.1432);
      expect(distance).toBeGreaterThan(220);
      expect(distance).toBeLessThan(230);
    });

    it("should return 0 for same point", () => {
      const distance = haversineDistance(47.3769, 8.5472, 47.3769, 8.5472);
      expect(distance).toBe(0);
    });

    it("should calculate distance on Bahnhofstrasse", () => {
      // Bahnhofstrasse start to end (approx 1.2 km)
      const distance = haversineDistance(47.3773, 8.5391, 47.3707, 8.5391);
      expect(distance).toBeGreaterThan(0.7);
      expect(distance).toBeLessThan(1.5);
    });
  });

  // Test calculateLinearOffset
  describe("calculateLinearOffset", () => {
    it("should return 0 at start point", () => {
      const offset = calculateLinearOffset(47.3773, 8.5391, 47.3773, 8.5391, 47.3707, 8.5391);
      expect(offset).toBe(0);
    });

    it("should return 1 at end point", () => {
      const offset = calculateLinearOffset(47.3707, 8.5391, 47.3773, 8.5391, 47.3707, 8.5391);
      expect(offset).toBe(1);
    });

    it("should return 0.5 at midpoint", () => {
      const midLat = (47.3773 + 47.3707) / 2;
      const offset = calculateLinearOffset(midLat, 8.5391, 47.3773, 8.5391, 47.3707, 8.5391);
      expect(offset).toBeGreaterThan(0.4);
      expect(offset).toBeLessThan(0.6);
    });

    it("should clamp to 0-1 range", () => {
      const offset = calculateLinearOffset(47.4, 8.5391, 47.3773, 8.5391, 47.3707, 8.5391);
      expect(offset).toBeGreaterThanOrEqual(0);
      expect(offset).toBeLessThanOrEqual(1);
    });
  });

  // Test interpolateCoordinate
  describe("interpolateCoordinate", () => {
    it("should interpolate at start", () => {
      const value = interpolateCoordinate(0, 100, 0);
      expect(value).toBe(0);
    });

    it("should interpolate at end", () => {
      const value = interpolateCoordinate(0, 100, 1);
      expect(value).toBe(100);
    });

    it("should interpolate at midpoint", () => {
      const value = interpolateCoordinate(0, 100, 0.5);
      expect(value).toBe(50);
    });

    it("should interpolate negative ranges", () => {
      const value = interpolateCoordinate(-100, 100, 0.5);
      expect(value).toBe(0);
    });
  });

  // Test applyMarkerSpacing
  describe("applyMarkerSpacing", () => {
    it("should not modify single marker", () => {
      const markers = [{ offset: 0.5, id: "1" }];
      const result = applyMarkerSpacing(markers, 0.1);
      expect(result).toHaveLength(1);
      expect(result[0].offset).toBe(0.5);
    });

    it("should space out close markers", () => {
      const markers = [
        { offset: 0.1, id: "1" },
        { offset: 0.12, id: "2" },
        { offset: 0.14, id: "3" },
      ];
      const result = applyMarkerSpacing(markers, 0.05);
      expect(result).toHaveLength(3);
      expect(result[1].offset).toBeGreaterThanOrEqual(result[0].offset + 0.05);
      expect(result[2].offset).toBeGreaterThanOrEqual(result[1].offset + 0.05);
    });

    it("should clamp offsets to 1", () => {
      const markers = [
        { offset: 0.95, id: "1" },
        { offset: 0.96, id: "2" },
        { offset: 0.97, id: "3" },
      ];
      const result = applyMarkerSpacing(markers, 0.1);
      expect(result[result.length - 1].offset).toBeLessThanOrEqual(1);
    });

    it("should preserve order", () => {
      const markers = [
        { offset: 0.1, id: "1" },
        { offset: 0.5, id: "2" },
        { offset: 0.9, id: "3" },
      ];
      const result = applyMarkerSpacing(markers, 0.05);
      expect(result[0].id).toBe("1");
      expect(result[1].id).toBe("2");
      expect(result[2].id).toBe("3");
    });
  });

  // Test arrangeMarkersOnStreet
  describe("arrangeMarkersOnStreet", () => {
    it("should arrange markers on Bahnhofstrasse", () => {
      const markers = [
        { lat: 47.3773, lng: 8.5391, newsId: "1", brand: "Rolex", title: "Opening", date: new Date() },
        { lat: 47.3740, lng: 8.5391, newsId: "2", brand: "Dior", title: "Opening", date: new Date() },
        { lat: 47.3707, lng: 8.5391, newsId: "3", brand: "Gucci", title: "Opening", date: new Date() },
      ];

      const result = arrangeMarkersOnStreet(
        markers,
        47.3773,
        8.5391,
        47.3707,
        8.5391,
        "Bahnhofstrasse",
        "Zurich"
      );

      expect(result).toHaveLength(3);
      expect(result[0].offset).toBeLessThan(result[1].offset);
      expect(result[1].offset).toBeLessThan(result[2].offset);
      expect(result[0].streetName).toBe("Bahnhofstrasse");
      expect(result[0].city).toBe("Zurich");
    });

    it("should handle single marker", () => {
      const markers = [
        { lat: 47.3740, lng: 8.5391, newsId: "1", brand: "Prada", title: "Opening", date: new Date() },
      ];

      const result = arrangeMarkersOnStreet(
        markers,
        47.3773,
        8.5391,
        47.3707,
        8.5391,
        "Bahnhofstrasse",
        "Zurich"
      );

      expect(result).toHaveLength(1);
      expect(result[0].offset).toBeGreaterThan(0);
      expect(result[0].offset).toBeLessThan(1);
    });

    it("should handle empty markers", () => {
      const result = arrangeMarkersOnStreet(
        [],
        47.3773,
        8.5391,
        47.3707,
        8.5391,
        "Bahnhofstrasse",
        "Zurich"
      );

      expect(result).toHaveLength(0);
    });
  });

  // Test extractStreetName
  describe("extractStreetName", () => {
    it("should extract street from simple address", () => {
      const name = extractStreetName("Bahnhofstrasse 100, Zurich");
      expect(name).toBe("Bahnhofstrasse 100");
    });

    it("should handle address without comma", () => {
      const name = extractStreetName("Rue du Rhone");
      expect(name).toBe("Rue du Rhone");
    });

    it("should handle empty string", () => {
      const name = extractStreetName("");
      expect(name).toBe("");
    });
  });

  // Test calculateMarkerDensity
  describe("calculateMarkerDensity", () => {
    it("should calculate density for Bahnhofstrasse", () => {
      const markers: MarkerPosition[] = [
        { newsId: "1", lat: 47.3773, lng: 8.5391, offset: 0, streetName: "Bahnhofstrasse", city: "Zurich", brand: "Rolex", title: "Opening", date: new Date() },
        { newsId: "2", lat: 47.3740, lng: 8.5391, offset: 0.5, streetName: "Bahnhofstrasse", city: "Zurich", brand: "Dior", title: "Opening", date: new Date() },
        { newsId: "3", lat: 47.3707, lng: 8.5391, offset: 1, streetName: "Bahnhofstrasse", city: "Zurich", brand: "Gucci", title: "Opening", date: new Date() },
      ];

      const density = calculateMarkerDensity(markers, 47.3773, 8.5391, 47.3707, 8.5391);
      expect(density).toBeGreaterThan(0);
      expect(density).toBeLessThan(10);
    });

    it("should return 0 for empty markers", () => {
      const density = calculateMarkerDensity([], 47.3773, 8.5391, 47.3707, 8.5391);
      expect(density).toBe(0);
    });
  });

  // Test getVisibleMarkers
  describe("getVisibleMarkers", () => {
    const markers: MarkerPosition[] = Array.from({ length: 20 }, (_, i) => ({
      newsId: i.toString(),
      lat: 47.3773 - (i * 0.0001),
      lng: 8.5391,
      offset: i / 20,
      streetName: "Bahnhofstrasse",
      city: "Zurich",
      brand: "Brand" + i,
      title: "Opening " + i,
      date: new Date(),
    }));

    it("should show all markers at high zoom", () => {
      const visible = getVisibleMarkers(markers, 15);
      expect(visible).toHaveLength(20);
    });

    it("should show every 2nd marker at medium zoom", () => {
      const visible = getVisibleMarkers(markers, 13);
      expect(visible.length).toBeLessThan(20);
      expect(visible.length).toBeGreaterThan(5);
    });

    it("should show every 5th marker at low zoom", () => {
      const visible = getVisibleMarkers(markers, 10);
      expect(visible.length).toBeLessThan(10);
    });

    it("should show no markers at very low zoom", () => {
      const visible = getVisibleMarkers(markers, 8);
      expect(visible).toHaveLength(0);
    });
  });
});
