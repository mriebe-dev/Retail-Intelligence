/**
 * Batch import CPP-LUXURY scraped articles into the database
 * Uses direct MySQL connection with duplicate detection
 */

import * as fs from 'fs';
import mysql from 'mysql2/promise';
import * as dotenv from 'dotenv';
import { createHash } from 'crypto';

dotenv.config();

const DATA_FILE = '/home/ubuntu/global-luxury-monitoring/cpp-luxury-scraped.json';
const BATCH_SIZE = 100;

function urlHash(url) {
  return createHash('md5').update(url).digest('hex').slice(0, 32);
}

function categoryFromBrand(brand) {
  // DB enum: 'Fashion','Watches','Jewelry','Home','Other'
  const JEWELRY = ['Cartier', 'Van Cleef', 'Bulgari', 'Bvlgari', 'Tiffany', 'Chopard',
    'De Beers', 'Graff', 'Harry Winston', 'Piaget', 'Chaumet', 'Boucheron',
    'Pomellato', 'Messika', 'Repossi', 'Tasaki', 'Mikimoto', 'Boodles',
    'Garrard', 'Asprey', 'Mappin'];
  const WATCHES = ['Rolex', 'Patek Philippe', 'Audemars Piguet', 'Vacheron', 'IWC',
    'Jaeger-LeCoultre', 'Omega', 'Longines', 'TAG Heuer', 'Hublot', 'Zenith',
    'Breguet', 'Blancpain', 'Panerai', 'Richard Mille', 'F.P. Journe',
    'A. Lange', 'Roger Dubuis', 'Hamilton', 'Tissot', 'Rado', 'Swatch',
    'Baume & Mercier', 'Montblanc', 'Breitling', 'Tudor', 'Seiko', 'Grand Seiko'];
  const HOME = ['Bolia', 'BOLIA', 'Muji', 'MUJI', 'Miniso', 'MINISO', 'La DoubleJ',
    'Zara Home', 'H&M Home', 'Maisons du Monde', 'Roche Bobois', 'Fendi Casa'];

  const brandLower = brand.toLowerCase();
  if (JEWELRY.some(b => brandLower.includes(b.toLowerCase()))) return 'Jewelry';
  if (WATCHES.some(b => brandLower.includes(b.toLowerCase()))) return 'Watches';
  if (HOME.some(b => brandLower.includes(b.toLowerCase()))) return 'Home';
  return 'Fashion';
}

async function importAll() {
  console.log('🚀 Starting CPP-LUXURY batch import...');

  // Load scraped data
  const articles = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  console.log(`📊 Loaded ${articles.length} scraped articles`);

  // Connect to database
  const db = await mysql.createConnection(process.env.DATABASE_URL);
  console.log('✅ Connected to database');

  // Get existing URL hashes to avoid duplicates
  const [existingRows] = await db.execute('SELECT url_hash FROM luxury_news WHERE url_hash IS NOT NULL');
  const existingHashes = new Set(existingRows.map(r => r.url_hash));
  console.log(`📋 Found ${existingHashes.size} existing entries`);

  let imported = 0;
  let skipped = 0;
  let errors = 0;

  // Process in batches
  for (let i = 0; i < articles.length; i += BATCH_SIZE) {
    const batch = articles.slice(i, i + BATCH_SIZE);
    const values = [];

    for (const article of batch) {
      const hash = urlHash(article.url);
      if (existingHashes.has(hash)) {
        skipped++;
        continue;
      }
      existingHashes.add(hash);

      const category = categoryFromBrand(article.brand);
      const now = Date.now();

      values.push([
        hash,                                    // url_hash
        article.brand.slice(0, 254),             // brand_name
        (article.city || '').slice(0, 254),      // city
        (article.country || '').slice(0, 254),   // country
        '',                                       // street
        article.openingDate || '2020-01-01',     // date
        article.source,                          // source
        article.url.slice(0, 999),               // link
        (article.title + (article.description ? ' - ' + article.description : '')).slice(0, 4999), // description
        'new',                                   // status
        category,                                // category
      ]);
    }

    if (values.length === 0) continue;

    try {
      await db.query(
        `INSERT IGNORE INTO luxury_news 
         (url_hash, brand_name, city, country, street, date, source, link, description, status, category)
         VALUES ?`,
        [values]
      );
      imported += values.length;
    } catch (err) {
      // Try one by one
      for (const val of values) {
        try {
          await db.query(
            `INSERT IGNORE INTO luxury_news 
             (url_hash, brand_name, city, country, street, date, source, link, description, status, category)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            val
          );
          imported++;
        } catch (e) {
          errors++;
        }
      }
    }

    if ((i / BATCH_SIZE) % 10 === 0) {
      console.log(`Progress: ${i + batch.length}/${articles.length} | Imported: ${imported} | Skipped: ${skipped} | Errors: ${errors}`);
    }
  }

  await db.end();

  console.log('\n✅ IMPORT COMPLETE!');
  console.log(`📊 Imported: ${imported}`);
  console.log(`⏭️  Skipped (duplicates): ${skipped}`);
  console.log(`❌ Errors: ${errors}`);
  console.log(`📈 Total new entries: ${imported}`);
}

importAll().catch(console.error);
