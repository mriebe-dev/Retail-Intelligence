import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Navigation from "./components/Navigation";
import Home from "./pages/Home";
import SwitzerlandPage from "./pages/Switzerland";
import GlobalPage from "./pages/Global";
import AdminPage from "./pages/Admin";
import CityPageLayout from './pages/CityPageLayout';
import { MapPage } from './pages/MapPage';
import CityPage from "./pages/CityPage";
import StoreDetail from "./pages/StoreDetail";
import { StoreDetailPage } from "./pages/StoreDetailPage";
import AlpineDestinations from "./pages/AlpineDestinations";
import StreetAnalysis from "./pages/StreetAnalysis";
import GlobalCities from "./pages/GlobalCities";
import NewsArchive from "./pages/NewsArchive";
import NewsAnalytics from "./pages/NewsAnalytics";
import VideoPage from "./pages/VideoPage";
import { AdminPanel } from "./pages/AdminPanel";
import { StoreComparisonDashboard } from "./pages/StoreComparisonDashboard";
import { GlobalStoresMap } from "./pages/GlobalStoresMap";
import MarketAnalyticsDashboard from "./pages/MarketAnalyticsDashboard";
import CitiesOverview from "./pages/CitiesOverview";
import BrandGroups from "./pages/BrandGroups";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/switzerland"} component={SwitzerlandPage} />
      <Route path={"/global"} component={GlobalPage} />
        <Route path="/city/:country/:city" component={CityPageLayout} />
      <Route path="/maps" component={MapPage} />
      <Route path="/global-stores-map" component={GlobalStoresMap} />
      <Route path={"/city/:city"} component={CityPageLayout} />
      <Route path={"/:store/:id"} component={StoreDetail} />
      <Route path={"/store-detail/:id"} component={StoreDetailPage} />
      <Route path={"/alpine"} component={AlpineDestinations} />      <Route path={"/street/:city/:street"} component={StreetAnalysis} />
      <Route path={"/global-cities"} component={GlobalCities} />
      <Route path={"/cities"} component={CitiesOverview} />
      <Route path={"/brands"} component={BrandGroups} />
      <Route path={"/brands/:brand"} component={BrandGroups} />
      <Route path={"/news-archive"} component={NewsArchive} />
      <Route path={"/news-analytics"} component={NewsAnalytics} />      <Route path={"/ video"} component={VideoPage} />
      <Route path={"/ admin"} component={AdminPage} />      <Route path={"/ admin-panel"} component={AdminPanel} />
      <Route path={"/ store-comparison"} component={StoreComparisonDashboard} />
      <Route path={"/ market-analytics"} component={MarketAnalyticsDashboard} />
      <Route path={"/ 404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Navigation />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
