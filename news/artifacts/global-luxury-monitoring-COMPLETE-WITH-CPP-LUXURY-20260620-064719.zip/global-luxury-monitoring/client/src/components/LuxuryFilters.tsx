import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { X } from "lucide-react";

export interface FilterOptions {
  searchText: string;
  newsType: string;
  source: string;
  dateFrom: string;
  dateTo: string;
  brand: string;
}

interface LuxuryFiltersProps {
  onFilterChange: (filters: FilterOptions) => void;
  brands: string[];
  newsTypes: string[];
  sources: string[];
}

export function LuxuryFilters({
  onFilterChange,
  brands,
  newsTypes,
  sources,
}: LuxuryFiltersProps) {
  const [filters, setFilters] = useState<FilterOptions>({
    searchText: "",
    newsType: "",
    source: "",
    dateFrom: "",
    dateTo: "",
    brand: "",
  });

  const handleFilterChange = useCallback(
    (newFilters: Partial<FilterOptions>) => {
      const updatedFilters = { ...filters, ...newFilters };
      setFilters(updatedFilters);
      onFilterChange(updatedFilters);
    },
    [filters, onFilterChange]
  );

  const handleReset = useCallback(() => {
    const emptyFilters: FilterOptions = {
      searchText: "",
      newsType: "",
      source: "",
      dateFrom: "",
      dateTo: "",
      brand: "",
    };
    setFilters(emptyFilters);
    onFilterChange(emptyFilters);
  }, [onFilterChange]);

  const hasActiveFilters =
    filters.searchText ||
    filters.newsType ||
    filters.source ||
    filters.dateFrom ||
    filters.dateTo ||
    filters.brand;

  return (
    <Card className="p-4 mb-6 bg-white border border-gray-200">
      <div className="space-y-4">
        {/* Search Text */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Search
          </label>
          <Input
            type="text"
            placeholder="Search by brand, address, or description..."
            value={filters.searchText}
            onChange={(e) =>
              handleFilterChange({ searchText: e.target.value })
            }
            className="w-full"
          />
        </div>

        {/* Filter Row 1 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* News Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              News Type
            </label>
            <Select
              value={filters.newsType}
              onValueChange={(value) =>
                handleFilterChange({ newsType: value })
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="All types" />
              </SelectTrigger>
              <SelectContent>
                {newsTypes && newsTypes.length > 0 ? (
                  <>
                    <SelectItem value="all">All types</SelectItem>
                    {newsTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </>
                ) : (
                  <SelectItem value="all">All types</SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Source */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Source
            </label>
            <Select
              value={filters.source}
              onValueChange={(value) => handleFilterChange({ source: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="All sources" />
              </SelectTrigger>
              <SelectContent>
                {sources && sources.length > 0 ? (
                  <>
                    <SelectItem value="all">All sources</SelectItem>
                    {sources.map((src) => (
                      <SelectItem key={src} value={src}>
                        {src}
                      </SelectItem>
                    ))}
                  </>
                ) : (
                  <SelectItem value="all">All sources</SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Brand */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Brand
            </label>
            <Select
              value={filters.brand}
              onValueChange={(value) => handleFilterChange({ brand: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="All brands" />
              </SelectTrigger>
              <SelectContent>
                {brands && brands.length > 0 ? (
                  <>
                    <SelectItem value="all">All brands</SelectItem>
                    {brands.map((brand) => (
                      <SelectItem key={brand} value={brand}>
                        {brand}
                      </SelectItem>
                    ))}
                  </>
                ) : (
                  <SelectItem value="all">All brands</SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Reset Button */}
          <div className="flex items-end">
            {hasActiveFilters && (
              <Button
                variant="outline"
                onClick={handleReset}
                className="w-full flex items-center justify-center gap-2"
              >
                <X className="w-4 h-4" />
                Clear Filters
              </Button>
            )}
          </div>
        </div>

        {/* Filter Row 2 - Date Range */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Date From */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              From Date
            </label>
            <Input
              type="date"
              value={filters.dateFrom}
              onChange={(e) =>
                handleFilterChange({ dateFrom: e.target.value })
              }
              className="w-full"
            />
          </div>

          {/* Date To */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              To Date
            </label>
            <Input
              type="date"
              value={filters.dateTo}
              onChange={(e) => handleFilterChange({ dateTo: e.target.value })}
              className="w-full"
            />
          </div>
        </div>
      </div>
    </Card>
  );
}
