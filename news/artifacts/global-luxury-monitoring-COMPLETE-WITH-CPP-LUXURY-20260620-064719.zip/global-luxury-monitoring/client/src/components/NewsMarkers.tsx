import { useEffect, useState } from 'react';
import { MapPin, ExternalLink } from 'lucide-react';

interface NewsMarker {
  id: string;
  brand: string;
  street: string;
  city: string;
  country: string;
  latitude: number;
  longitude: number;
  date: string;
  source: string;
  link: string;
  status: 'new' | 'archived' | 'featured';
  category: string;
}

interface NewsMarkersProps {
  news: NewsMarker[];
  onMarkerClick?: (newsId: string) => void;
  selectedNewsId?: string;
}

export default function NewsMarkers({ news, onMarkerClick, selectedNewsId }: NewsMarkersProps) {
  const [activeMarker, setActiveMarker] = useState<string | null>(selectedNewsId || null);

  // Gruppiere News nach Straße
  const groupedByStreet = news.reduce((acc, item) => {
    const key = `${item.street}, ${item.city}`;
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(item);
    return acc;
  }, {} as Record<string, NewsMarker[]>);

  const handleMarkerClick = (newsId: string) => {
    setActiveMarker(newsId);
    onMarkerClick?.(newsId);
  };

  return (
    <div className="space-y-4">
      {/* Marker-Übersicht */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-3">
          <MapPin className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-gray-900">
            {news.length} News-Standorte
          </h3>
        </div>
        <p className="text-sm text-gray-600">
          Klicken Sie auf einen Marker auf der Karte, um Details anzuzeigen
        </p>
      </div>

      {/* Gruppierte News nach Straße */}
      <div className="space-y-3">
        {Object.entries(groupedByStreet).map(([street, streetNews]) => (
          <div key={street} className="border border-gray-200 rounded-lg overflow-hidden">
            <div className="bg-gray-50 px-4 py-2 border-b border-gray-200">
              <h4 className="font-semibold text-gray-900">{street}</h4>
              <p className="text-sm text-gray-600">{streetNews.length} News</p>
            </div>
            <div className="divide-y divide-gray-200">
              {streetNews.map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleMarkerClick(item.id)}
                  className={`p-3 cursor-pointer transition-colors ${
                    activeMarker === item.id
                      ? 'bg-blue-100 border-l-4 border-blue-600'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <p className="font-semibold text-gray-900">{item.brand}</p>
                      <p className="text-sm text-gray-600">{item.category}</p>
                      <p className="text-xs text-gray-500 mt-1">{item.date}</p>
                    </div>
                    <span
                      className={`text-xs font-semibold px-2 py-1 rounded ${
                        item.status === 'featured'
                          ? 'bg-yellow-100 text-yellow-800'
                          : item.status === 'new'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {item.status === 'featured'
                        ? 'Featured'
                        : item.status === 'new'
                        ? 'New'
                        : 'Archived'}
                    </span>
                  </div>
                  {item.link && (
                    <a
                      href={item.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 mt-2"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <span>View Source</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
