import React, { useEffect, useRef, useState } from 'react';

interface NewsMarker {
  id: string;
  brand: string;
  city: string;
  street: string;
  address: string;
  latitude: number;
  longitude: number;
  date: string;
  status: 'new' | 'featured' | 'archived';
  category?: 'fashion' | 'watches' | 'jewelry' | 'home' | 'other';
  source?: string;
  link?: string;
}

interface NewsMarkersMapProps {
  city: string;
  markers: NewsMarker[];
  onMarkerClick?: (marker: NewsMarker) => void;
}

const getCategoryIcon = (category?: string) => {
  switch (category) {
    case 'watches':
      return '⌚';
    case 'jewelry':
      return '💎';
    case 'home':
      return '🏠';
    case 'fashion':
    default:
      return '👗';
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'new':
      return '#10b981'; // green
    case 'featured':
      return '#f59e0b'; // amber
    case 'archived':
      return '#6b7280'; // gray
    default:
      return '#3b82f6'; // blue
  }
};

export default function NewsMarkersMap({ city, markers, onMarkerClick }: NewsMarkersMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const infoWindowRef = useRef<google.maps.InfoWindow | null>(null);
  const [mapReady, setMapReady] = useState(false);

  // Initialize map
  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    const map = new google.maps.Map(mapRef.current, {
      zoom: 13,
      center: { lat: 47.3769, lng: 8.5472 }, // Default to Zurich
      styles: [
        {
          featureType: 'poi',
          elementType: 'labels',
          stylers: [{ visibility: 'off' }],
        },
      ],
    });

    mapInstanceRef.current = map;
    infoWindowRef.current = new google.maps.InfoWindow();
    setMapReady(true);
  }, []);

  // Add/update markers
  useEffect(() => {
    if (!mapInstanceRef.current || !mapReady || markers.length === 0) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    // Add new markers
    markers.forEach(newsMarker => {
      if (!newsMarker.latitude || !newsMarker.longitude) return;

      const marker = new google.maps.Marker({
        position: {
          lat: newsMarker.latitude,
          lng: newsMarker.longitude,
        },
        map: mapInstanceRef.current,
        title: `${newsMarker.brand} - ${newsMarker.street}`,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 12,
          fillColor: getStatusColor(newsMarker.status),
          fillOpacity: 0.8,
          strokeColor: '#ffffff',
          strokeWeight: 2,
        },
      });

      marker.addListener('click', () => {
        const content = `
          <div class="p-4 max-w-xs">
            <div class="flex items-center justify-between mb-2">
              <h3 class="font-bold text-lg">${newsMarker.brand}</h3>
              <span class="text-2xl">${getCategoryIcon(newsMarker.category)}</span>
            </div>
            <p class="text-sm text-gray-600 mb-2">${newsMarker.street}</p>
            <p class="text-sm text-gray-600 mb-2">${newsMarker.address}</p>
            <p class="text-xs text-gray-500 mb-3">
              ${new Date(newsMarker.date).toLocaleDateString('de-CH')}
            </p>
            <div class="flex gap-2 items-center">
              <span class="px-2 py-1 rounded text-xs font-semibold" style="background-color: ${getStatusColor(newsMarker.status)}; color: white;">
                ${newsMarker.status.toUpperCase()}
              </span>
              ${newsMarker.link ? `<a href="${newsMarker.link}" target="_blank" class="text-blue-600 text-xs hover:underline">Quelle</a>` : ''}
            </div>
          </div>
        `;

        if (infoWindowRef.current && mapInstanceRef.current) {
          infoWindowRef.current.setContent(content);
          infoWindowRef.current.open(mapInstanceRef.current, marker);
        }

        if (onMarkerClick) {
          onMarkerClick(newsMarker);
        }
      });

      markersRef.current.push(marker);
    });

    // Fit bounds to all markers
    if (markersRef.current.length > 0 && mapInstanceRef.current) {
      const bounds = new google.maps.LatLngBounds();
      markersRef.current.forEach(marker => {
        const pos = marker.getPosition();
        if (pos) bounds.extend(pos);
      });
      mapInstanceRef.current.fitBounds(bounds);
    }
  }, [markers, mapReady, onMarkerClick]);

  return (
    <div className="w-full h-full rounded-lg overflow-hidden shadow-lg">
      <div
        ref={mapRef}
        className="w-full h-full"
        style={{ minHeight: '400px' }}
      />
    </div>
  );
}
