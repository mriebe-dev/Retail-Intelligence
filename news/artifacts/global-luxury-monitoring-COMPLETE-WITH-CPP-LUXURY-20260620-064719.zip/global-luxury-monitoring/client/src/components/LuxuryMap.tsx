import { useRef } from "react";
import { MapView } from "@/components/Map";
import { trpc } from "@/lib/trpc";

interface LuxuryMapProps {
  city?: string;
  country?: string;
  height?: string;
}

export function LuxuryMap({ city, country, height = "h-96" }: LuxuryMapProps) {
  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const infoWindowRef = useRef<google.maps.InfoWindow | null>(null);

  // Fetch luxury stores for the given city/country
  const { data: stores, isLoading } = trpc.luxury.list.useQuery({
    city,
    country,
  });

  // City coordinates for centering the map
  const cityCoordinates: Record<string, { lat: number; lng: number }> = {
    zurich: { lat: 47.3769, lng: 8.5472 },
    geneva: { lat: 46.2044, lng: 6.1432 },
    basel: { lat: 47.5596, lng: 7.5886 },
    bern: { lat: 46.9479, lng: 7.4474 },
    lausanne: { lat: 46.5197, lng: 6.6323 },
    winterthur: { lat: 47.5, lng: 8.7167 },
    "st. gallen": { lat: 47.4229, lng: 9.3767 },
    lugano: { lat: 46.0051, lng: 8.9603 },
    lucerne: { lat: 47.0502, lng: 8.3093 },
    paris: { lat: 48.8566, lng: 2.3522 },
    london: { lat: 51.5074, lng: -0.1278 },
    "new york": { lat: 40.7128, lng: -74.006 },
    milan: { lat: 45.4642, lng: 9.1900 },
    tokyo: { lat: 35.6762, lng: 139.6503 },
    "hong kong": { lat: 22.3193, lng: 114.1694 },
  };

  const centerCoord = city
    ? cityCoordinates[city.toLowerCase()] || { lat: 47.3769, lng: 8.5472 }
    : { lat: 20, lng: 0 };

  const handleMapReady = (map: google.maps.Map | null) => {
    if (!map) return;
    mapRef.current = map;
    map.setCenter(centerCoord);
    map.setZoom(city ? 13 : 2);

    // Clear existing markers
    markersRef.current.forEach((marker) => marker.setMap(null));
    markersRef.current = [];

    if (!stores || stores.length === 0) return;

    // Create markers for each store
    stores.forEach((store) => {
      // Generate approximate coordinates based on city
      const storeCoord = cityCoordinates[store.city.toLowerCase()] || centerCoord;

      // Add slight random offset for multiple stores in same city
      const lat = storeCoord.lat + (Math.random() - 0.5) * 0.05;
      const lng = storeCoord.lng + (Math.random() - 0.5) * 0.05;

      const marker = new google.maps.Marker({
        position: { lat, lng },
        map,
        title: `${store.brandName} - ${store.locationAddress}`,
      });

      marker.addListener("click", () => {
        if (infoWindowRef.current) {
          infoWindowRef.current.close();
        }

        const content = `
          <div class="p-3 max-w-xs">
            <h3 class="font-bold text-sm">${store.brandName}</h3>
            <p class="text-xs text-gray-600">${store.city}, ${store.country}</p>
            <p class="text-xs mt-1">${store.locationAddress || "Address not available"}</p>
            <p class="text-xs text-blue-600 mt-2">${store.newsType}</p>
            <p class="text-xs text-gray-500 mt-1">${new Date(store.date).toLocaleDateString()}</p>
          </div>
        `;

        infoWindowRef.current = new google.maps.InfoWindow({ content });
        infoWindowRef.current.open(map, marker);
      });

      markersRef.current.push(marker);
    });

    // Fit bounds if multiple markers
    if (markersRef.current.length > 1) {
      const bounds = new google.maps.LatLngBounds();
      markersRef.current.forEach((marker) => {
        bounds.extend(marker.getPosition()!);
      });
      map.fitBounds(bounds);
    }
  };

  return (
    <div className={`w-full ${height} rounded-lg overflow-hidden shadow-md`}>
      {isLoading && (
        <div className="w-full h-full flex items-center justify-center bg-gray-100">
          <p className="text-gray-600">Loading map...</p>
        </div>
      )}
      {!isLoading && (
        <MapView
        initialCenter={centerCoord}
        initialZoom={city ? 13 : 2}
        onMapReady={handleMapReady}
      />
      )}
    </div>
  );
}
