import React, { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface Store {
  id: string;
  name: string;
  brand: string;
  address: string;
  city: string;
  country: string;
  squareMeters?: number;
  openingDate?: string;
  openingHours?: Record<string, string>;
  photoUrls?: string[];
  latitude?: number;
  longitude?: number;
}

interface StoreCluster {
  address: string;
  city: string;
  country: string;
  storeCount: number;
  stores: Store[];
  latitude: number;
  longitude: number;
}

interface StoreMarkerClusterProps {
  stores: Store[];
  onStoreSelect?: (store: Store) => void;
  onClusterSelect?: (cluster: StoreCluster) => void;
}

/**
 * Groups stores by address and creates clusters for multi-store buildings
 */
export const StoreMarkerCluster: React.FC<StoreMarkerClusterProps> = ({
  stores,
  onStoreSelect,
  onClusterSelect,
}) => {
  const [selectedCluster, setSelectedCluster] = useState<StoreCluster | null>(null);
  const [expandedStoreId, setExpandedStoreId] = useState<string | null>(null);

  // Group stores by address to create clusters
  const clusters = useMemo(() => {
    const clusterMap = new Map<string, StoreCluster>();

    stores.forEach((store) => {
      const addressKey = normalizeAddress(store.address);

      if (!clusterMap.has(addressKey)) {
        clusterMap.set(addressKey, {
          address: store.address,
          city: store.city,
          country: store.country,
          storeCount: 0,
          stores: [],
          latitude: store.latitude || 0,
          longitude: store.longitude || 0,
        });
      }

      const cluster = clusterMap.get(addressKey)!;
      cluster.stores.push(store);
      cluster.storeCount = cluster.stores.length;

      // Update coordinates if available
      if (store.latitude && store.longitude) {
        cluster.latitude = store.latitude;
        cluster.longitude = store.longitude;
      }
    });

    return Array.from(clusterMap.values());
  }, [stores]);

  const handleClusterClick = (cluster: StoreCluster) => {
    setSelectedCluster(cluster);
    onClusterSelect?.(cluster);
  };

  const handleStoreClick = (store: Store) => {
    setExpandedStoreId(expandedStoreId === store.id ? null : store.id);
    onStoreSelect?.(store);
  };

  return (
    <div className="w-full space-y-4">
      {/* Cluster Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {clusters.map((cluster) => (
          <Card
            key={cluster.address}
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => handleClusterClick(cluster)}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold flex items-center justify-between">
                <span className="truncate">{cluster.address}</span>
                {cluster.storeCount > 1 && (
                  <Badge variant="secondary" className="ml-2">
                    {cluster.storeCount}
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-gray-600 mb-2">
                {cluster.city}, {cluster.country}
              </p>
              {cluster.storeCount > 1 ? (
                <p className="text-xs font-medium text-blue-600">
                  {cluster.storeCount} Stores im Gebäude
                </p>
              ) : (
                <p className="text-xs text-gray-500">1 Store</p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Selected Cluster Details */}
      {selectedCluster && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-base">
              {selectedCluster.address}
              {selectedCluster.storeCount > 1 && (
                <Badge className="ml-2">{selectedCluster.storeCount} Stores</Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {selectedCluster.stores.map((store) => (
              <div
                key={store.id}
                className="border rounded-lg p-3 hover:bg-gray-100 cursor-pointer transition-colors"
                onClick={() => handleStoreClick(store)}
              >
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-semibold text-sm">{store.brand}</p>
                    <p className="text-xs text-gray-600">{store.name}</p>
                  </div>
                  {store.squareMeters && (
                    <Badge variant="outline" className="text-xs">
                      {store.squareMeters} m²
                    </Badge>
                  )}
                </div>

                {/* Expanded Store Details */}
                {expandedStoreId === store.id && (
                  <div className="mt-3 pt-3 border-t space-y-2 text-xs">
                    {store.openingDate && (
                      <p>
                        <span className="font-semibold">Eröffnung:</span> {store.openingDate}
                      </p>
                    )}
                    {store.openingHours && Object.keys(store.openingHours).length > 0 && (
                      <div>
                        <p className="font-semibold mb-1">Öffnungszeiten:</p>
                        <div className="space-y-1">
                          {Object.entries(store.openingHours).map(([day, hours]) => (
                            <p key={day} className="text-gray-700">
                              {day}: {hours}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}
                    {store.photoUrls && store.photoUrls.length > 0 && (
                      <div>
                        <p className="font-semibold mb-1">Fotos:</p>
                        <div className="grid grid-cols-2 gap-2">
                          {store.photoUrls.slice(0, 2).map((url, idx) => (
                            <img
                              key={idx}
                              src={url}
                              alt={`${store.brand} ${idx + 1}`}
                              className="w-full h-20 object-cover rounded"
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

/**
 * Normalizes address for clustering (removes extra spaces, converts to lowercase)
 */
function normalizeAddress(address: string): string {
  return address
    .toLowerCase()
    .trim()
    .replace(/\s+/g, ' ')
    .replace(/,\s*/g, ',');
}

export type { Store, StoreCluster };
