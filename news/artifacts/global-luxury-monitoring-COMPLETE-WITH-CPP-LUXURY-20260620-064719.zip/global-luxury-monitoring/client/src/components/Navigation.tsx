import { useState } from 'react';
import { Link } from 'wouter';
import { ChevronDown } from 'lucide-react';
import { trpc } from '@/lib/trpc';

const SWISS_CITIES = [
  { name: 'Zürich', slug: 'zurich' },
  { name: 'Genf', slug: 'geneva' },
  { name: 'Basel', slug: 'basel' },
  { name: 'Bern', slug: 'bern' },
  { name: 'Lausanne', slug: 'lausanne' },
  { name: 'Winterthur', slug: 'winterthur' },
  { name: 'St. Gallen', slug: 'st-gallen' },
  { name: 'Lugano', slug: 'lugano' },
  { name: 'Luzern', slug: 'lucerne' },
];

const ALPINE_DESTINATIONS = [
  { name: 'St. Moritz', slug: 'st-moritz' },
  { name: 'Gstaad', slug: 'gstaad' },
  { name: 'Zermatt', slug: 'zermatt' },
  { name: 'Interlaken', slug: 'interlaken' },
];

const GLOBAL_CITIES = [
  { name: 'Paris', slug: 'paris' },
  { name: 'London', slug: 'london' },
  { name: 'New York', slug: 'new-york' },
  { name: 'Mailand', slug: 'milan' },
  { name: 'Tokio', slug: 'tokyo' },
  { name: 'Hongkong', slug: 'hong-kong' },
];

export default function Navigation() {
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const { data: stores } = trpc.luxury.list.useQuery({});

  // Calculate store counts per city
  const getStoreCount = (cityName: string) => {
    if (!stores) return 0;
    return stores.filter(s => s.city === cityName).length;
  };

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/">
            <a className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <span className="text-blue-600">🌍</span>
              Global Luxury Monitoring
            </a>
          </Link>

          {/* Navigation Items */}
          <div className="flex items-center gap-8">
            {/* HOME */}
            <Link href="/">
              <a className="text-gray-700 hover:text-blue-600 font-medium">HOME</a>
            </Link>

            {/* CITIES DROPDOWN */}
            <div className="relative group">
              <button
                onClick={() => setOpenDropdown(openDropdown === 'cities' ? null : 'cities')}
                className="flex items-center gap-1 text-gray-700 hover:text-blue-600 font-medium"
              >
                Städte ({SWISS_CITIES.length})
                <ChevronDown size={16} />
              </button>
              {openDropdown === 'cities' && (
                <div className="absolute left-0 mt-0 w-56 bg-white border border-gray-200 rounded-lg shadow-lg py-2">
                  {SWISS_CITIES.map(city => {
                    const count = getStoreCount(city.name);
                    return (
                      <Link key={city.slug} href={`/city/${city.slug}`}>
                        <a className="block px-4 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600">
                          {city.name} ({count})
                        </a>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>

            {/* ALPEN DROPDOWN */}
            <div className="relative group">
              <button
                onClick={() => setOpenDropdown(openDropdown === 'alpen' ? null : 'alpen')}
                className="flex items-center gap-1 text-gray-700 hover:text-blue-600 font-medium"
              >
                Alpen ({ALPINE_DESTINATIONS.length})
                <ChevronDown size={16} />
              </button>
              {openDropdown === 'alpen' && (
                <div className="absolute left-0 mt-0 w-56 bg-white border border-gray-200 rounded-lg shadow-lg py-2">
                  {ALPINE_DESTINATIONS.map(city => {
                    const count = getStoreCount(city.name);
                    return (
                      <Link key={city.slug} href={`/city/${city.slug}`}>
                        <a className="block px-4 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600">
                          {city.name} ({count})
                        </a>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>

            {/* CITIES OVERVIEW */}
            <Link href="/cities">
              <a className="text-gray-700 hover:text-blue-600 font-medium">
                Cities Overview
              </a>
            </Link>

            {/* GLOBAL DROPDOWN */}
            <div className="relative group">
              <button
                onClick={() => setOpenDropdown(openDropdown === 'global' ? null : 'global')}
                className="flex items-center gap-1 text-gray-700 hover:text-blue-600 font-medium"
              >
                Global ({GLOBAL_CITIES.length})
                <ChevronDown size={16} />
              </button>
              {openDropdown === 'global' && (
                <div className="absolute left-0 mt-0 w-56 bg-white border border-gray-200 rounded-lg shadow-lg py-2">
                  <Link href="/global-cities">
                    <a className="block px-4 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600 font-semibold border-b border-gray-200">
                      Alle globalen Städte →
                    </a>
                  </Link>
                  {GLOBAL_CITIES.map(city => {
                    const count = getStoreCount(city.name);
                    return (
                      <Link key={city.slug} href={`/city/${city.slug}`}>
                        <a className="block px-4 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600">
                          {city.name} ({count})
                        </a>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>

            {/* BRANDS */}
            <Link href="/brands">
              <a className="text-gray-700 hover:text-purple-600 font-medium">
                Brands
              </a>
            </Link>

            {/* MARKET ANALYSIS */}
            <Link href="/market-analytics">
              <a className="text-gray-700 hover:text-blue-600 font-medium">
                Market Analysis
              </a>
            </Link>

            {/* HIGHLIGHTS */}
            <a href="#highlights" className="text-gray-700 hover:text-blue-600 font-medium">
              Highlights
            </a>

            {/* NEWS ARCHIVE */}
            <Link href="/news-archive">
              <a className="text-gray-700 hover:text-blue-600 font-medium">
                News Archive
              </a>
            </Link>

            {/* ADMIN */}
            <Link href="/admin">
              <a className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
                Admin
              </a>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
