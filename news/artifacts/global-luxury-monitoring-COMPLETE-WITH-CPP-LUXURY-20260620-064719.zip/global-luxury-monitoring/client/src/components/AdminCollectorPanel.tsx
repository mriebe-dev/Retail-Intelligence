import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Loader2, Play, RefreshCw, CheckCircle2, AlertCircle, Clock } from "lucide-react";

interface CollectorResult {
  source: string;
  added: number;
  duplicates: number;
  errors: number;
  timestamp: string;
}

interface CollectorStatus {
  lastRun?: string;
  nextRun: string;
  isRunning: boolean;
  status: string;
}

export function AdminCollectorPanel() {
  const [isRunning, setIsRunning] = useState(false);
  const [lastResults, setLastResults] = useState<CollectorResult[] | null>(null);
  const [collectorStatus, setCollectorStatus] = useState<CollectorStatus | null>(null);

  const runCollectorMutation = trpc.news.runCollector.useMutation();
  const statusQuery = trpc.news.collectorStatus.useQuery();

  useEffect(() => {
    if (statusQuery.data) {
      setCollectorStatus(statusQuery.data);
    }
  }, [statusQuery.data]);

  const handleRunCollector = async () => {
    setIsRunning(true);
    try {
      const result = await runCollectorMutation.mutateAsync();
      setLastResults(result.results);
      
      // Refresh status
      statusQuery.refetch();
    } catch (error) {
      console.error("Error running collector:", error);
    } finally {
      setIsRunning(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString("de-CH");
  };

  const getTotalStats = () => {
    if (!lastResults) return { added: 0, duplicates: 0, errors: 0 };
    return {
      added: lastResults.reduce((sum, r) => sum + r.added, 0),
      duplicates: lastResults.reduce((sum, r) => sum + r.duplicates, 0),
      errors: lastResults.reduce((sum, r) => sum + r.errors, 0),
    };
  };

  const stats = getTotalStats();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">News Collector Management</h2>
        <p className="text-muted-foreground mt-2">
          Manage automated luxury retail news collection from multiple sources
        </p>
      </div>

      {/* Status Card */}
      {collectorStatus && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Collector Schedule
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Status</p>
                <p className="font-semibold">{collectorStatus.status}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Next Run</p>
                <p className="font-semibold">{formatDate(collectorStatus.nextRun)}</p>
              </div>
            </div>
            {collectorStatus.lastRun && (
              <div>
                <p className="text-sm text-muted-foreground">Last Run</p>
                <p className="font-semibold">{formatDate(collectorStatus.lastRun)}</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Control Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Play className="h-5 w-5" />
            Manual Trigger
          </CardTitle>
          <CardDescription>
            Run the news collector immediately to fetch the latest luxury retail news
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button
            onClick={handleRunCollector}
            disabled={isRunning}
            size="lg"
            className="w-full"
          >
            {isRunning ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Running Collectors...
              </>
            ) : (
              <>
                <Play className="mr-2 h-4 w-4" />
                Run All Collectors Now
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Results Card */}
      {lastResults && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <RefreshCw className="h-5 w-5" />
              Latest Results
            </CardTitle>
            <CardDescription>
              Summary of the last collector run
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Summary Stats */}
            <div className="grid grid-cols-3 gap-4">
              <div className="rounded-lg bg-green-50 p-4 dark:bg-green-950">
                <p className="text-sm text-muted-foreground">Added</p>
                <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {stats.added}
                </p>
              </div>
              <div className="rounded-lg bg-yellow-50 p-4 dark:bg-yellow-950">
                <p className="text-sm text-muted-foreground">Duplicates</p>
                <p className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">
                  {stats.duplicates}
                </p>
              </div>
              <div className="rounded-lg bg-red-50 p-4 dark:bg-red-950">
                <p className="text-sm text-muted-foreground">Errors</p>
                <p className="text-2xl font-bold text-red-600 dark:text-red-400">
                  {stats.errors}
                </p>
              </div>
            </div>

            {/* Per-Source Results */}
            <div className="space-y-3">
              <h3 className="font-semibold">Per-Source Breakdown</h3>
              {lastResults.map((result) => (
                <div
                  key={result.source}
                  className="rounded-lg border p-4 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">{result.source}</h4>
                    {result.errors === 0 ? (
                      <Badge variant="outline" className="bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-400">
                        <CheckCircle2 className="mr-1 h-3 w-3" />
                        Success
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-400">
                        <AlertCircle className="mr-1 h-3 w-3" />
                        Error
                      </Badge>
                    )}
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">Added: </span>
                      <span className="font-semibold text-green-600 dark:text-green-400">
                        {result.added}
                      </span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Duplicates: </span>
                      <span className="font-semibold text-yellow-600 dark:text-yellow-400">
                        {result.duplicates}
                      </span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Errors: </span>
                      <span className="font-semibold text-red-600 dark:text-red-400">
                        {result.errors}
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {formatDate(result.timestamp)}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Info Card */}
      <Card>
        <CardHeader>
          <CardTitle>Collector Sources</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <h4 className="font-semibold text-sm mb-1">LinkedIn</h4>
            <p className="text-sm text-muted-foreground">
              Luxury retail news from LinkedIn posts and industry updates
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-1">Retail Journal</h4>
            <p className="text-sm text-muted-foreground">
              Retail industry news and store opening announcements
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-1">WWD (Women's Wear Daily)</h4>
            <p className="text-sm text-muted-foreground">
              Fashion and luxury brand news from industry publications
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-1">Google News</h4>
            <p className="text-sm text-muted-foreground">
              Filtered luxury retail news from Google News aggregation
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
