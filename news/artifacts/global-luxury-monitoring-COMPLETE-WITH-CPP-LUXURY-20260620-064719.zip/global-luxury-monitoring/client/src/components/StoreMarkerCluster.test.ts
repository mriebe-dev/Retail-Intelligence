import { describe, it, expect } from 'vitest';

// Mock store data for testing
const mockStores = [
  {
    id: '1',
    name: 'Chanel Flagship',
    brand: 'Chanel',
    address: 'Bahnhofstrasse 1, Zurich',
    city: 'Zurich',
    country: 'Switzerland',
    squareMeters: 500,
    openingDate: '2023-01-15',
    latitude: 47.378,
    longitude: 8.5391,
  },
  {
    id: '2',
    name: 'Gucci Store',
    brand: 'Gucci',
    address: 'Bahnhofstrasse 1, Zurich',
    city: 'Zurich',
    country: 'Switzerland',
    squareMeters: 350,
    openingDate: '2022-06-20',
    latitude: 47.378,
    longitude: 8.5391,
  },
  {
    id: '3',
    name: 'Dior Boutique',
    brand: 'Dior',
    address: 'Rennweg 1, Zurich',
    city: 'Zurich',
    country: 'Switzerland',
    squareMeters: 280,
    openingDate: '2023-09-10',
    latitude: 47.376,
    longitude: 8.5421,
  },
  {
    id: '4',
    name: 'Prada Store',
    brand: 'Prada',
    address: 'Bahnhofstrasse 1, Zurich',
    city: 'Zurich',
    country: 'Switzerland',
    squareMeters: 420,
    openingDate: '2023-03-05',
    latitude: 47.378,
    longitude: 8.5391,
  },
];

describe('StoreMarkerCluster', () => {
  describe('Address Clustering', () => {
    it('should group stores by address', () => {
      // Simulate clustering logic
      const addressMap = new Map<string, typeof mockStores>();

      mockStores.forEach((store) => {
        const key = store.address.toLowerCase().trim();
        if (!addressMap.has(key)) {
          addressMap.set(key, []);
        }
        addressMap.get(key)!.push(store);
      });

      expect(addressMap.size).toBe(2); // Two unique addresses
      expect(addressMap.get('bahnhofstrasse 1, zurich')!.length).toBe(3); // 3 stores
      expect(addressMap.get('rennweg 1, zurich')!.length).toBe(1); // 1 store
    });

    it('should handle address normalization', () => {
      const addresses = [
        'Bahnhofstrasse 1, Zurich',
        'bahnhofstrasse 1, zurich',
        'BAHNHOFSTRASSE 1, ZURICH',
        'Bahnhofstrasse  1,  Zurich', // Extra spaces
      ];

      const normalized = addresses.map((addr) =>
        addr.toLowerCase().trim().replace(/\s+/g, ' ')
      );

      // All should normalize to the same value
      expect(normalized[0]).toBe(normalized[1]);
      expect(normalized[1]).toBe(normalized[2]);
      expect(normalized[2]).toBe(normalized[3]);
    });
  });

  describe('Multi-Store Building Detection', () => {
    it('should detect buildings with 2+ stores', () => {
      const addressMap = new Map<string, typeof mockStores>();

      mockStores.forEach((store) => {
        const key = store.address.toLowerCase().trim();
        if (!addressMap.has(key)) {
          addressMap.set(key, []);
        }
        addressMap.get(key)!.push(store);
      });

      const multiStoreBuildings = Array.from(addressMap.entries()).filter(
        ([_, stores]) => stores.length > 1
      );

      expect(multiStoreBuildings.length).toBe(1); // One building with multiple stores
      expect(multiStoreBuildings[0][1].length).toBe(3); // 3 stores in that building
    });

    it('should handle buildings with up to 6 stores', () => {
      const largeBuilding = Array.from({ length: 6 }, (_, i) => ({
        id: `${i + 1}`,
        name: `Store ${i + 1}`,
        brand: `Brand ${i + 1}`,
        address: 'Bahnhofstrasse 1, Zurich',
        city: 'Zurich',
        country: 'Switzerland',
        squareMeters: 300 + i * 50,
        openingDate: '2023-01-01',
        latitude: 47.378,
        longitude: 8.5391,
      }));

      expect(largeBuilding.length).toBe(6);
      expect(largeBuilding.every((s) => s.address === 'Bahnhofstrasse 1, Zurich')).toBe(true);
    });
  });

  describe('Cluster Statistics', () => {
    it('should calculate correct store count per cluster', () => {
      const clusters = new Map<string, number>();

      mockStores.forEach((store) => {
        const key = store.address.toLowerCase().trim();
        clusters.set(key, (clusters.get(key) || 0) + 1);
      });

      expect(clusters.get('bahnhofstrasse 1, zurich')).toBe(3);
      expect(clusters.get('rennweg 1, zurich')).toBe(1);
    });

    it('should provide cluster summary data', () => {
      const addressMap = new Map<string, typeof mockStores>();

      mockStores.forEach((store) => {
        const key = store.address.toLowerCase().trim();
        if (!addressMap.has(key)) {
          addressMap.set(key, []);
        }
        addressMap.get(key)!.push(store);
      });

      const clusterSummaries = Array.from(addressMap.entries()).map(([address, stores]) => ({
        address,
        storeCount: stores.length,
        city: stores[0].city,
        country: stores[0].country,
        totalSquareMeters: stores.reduce((sum, s) => sum + (s.squareMeters || 0), 0),
      }));

      expect(clusterSummaries.length).toBe(2);
      expect(clusterSummaries[0].totalSquareMeters).toBe(500 + 350 + 420); // 1270 m²
      expect(clusterSummaries[1].totalSquareMeters).toBe(280); // 280 m²
    });
  });

  describe('Store Details in Cluster', () => {
    it('should preserve all store details within cluster', () => {
      const bahnhofstrassStores = mockStores.filter(
        (s) => s.address === 'Bahnhofstrasse 1, Zurich'
      );

      bahnhofstrassStores.forEach((store) => {
        expect(store).toHaveProperty('id');
        expect(store).toHaveProperty('brand');
        expect(store).toHaveProperty('squareMeters');
        expect(store).toHaveProperty('openingDate');
        expect(store).toHaveProperty('latitude');
        expect(store).toHaveProperty('longitude');
      });

      expect(bahnhofstrassStores.map((s) => s.brand)).toEqual(['Chanel', 'Gucci', 'Prada']);
    });

    it('should maintain store order within cluster', () => {
      const bahnhofstrassStores = mockStores.filter(
        (s) => s.address === 'Bahnhofstrasse 1, Zurich'
      );

      const firstStore = bahnhofstrassStores[0];
      expect(firstStore.brand).toBe('Chanel');

      const secondStore = bahnhofstrassStores[1];
      expect(secondStore.brand).toBe('Gucci');
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty store list', () => {
      const emptyStores: typeof mockStores = [];
      const addressMap = new Map<string, typeof mockStores>();

      emptyStores.forEach((store) => {
        const key = store.address.toLowerCase().trim();
        if (!addressMap.has(key)) {
          addressMap.set(key, []);
        }
        addressMap.get(key)!.push(store);
      });

      expect(addressMap.size).toBe(0);
    });

    it('should handle stores with missing optional fields', () => {
      const storeWithoutOptionals = {
        id: '1',
        name: 'Store',
        brand: 'Brand',
        address: 'Address',
        city: 'City',
        country: 'Country',
      };

      expect(storeWithoutOptionals).not.toHaveProperty('squareMeters');
      expect(storeWithoutOptionals).not.toHaveProperty('openingDate');
      expect(storeWithoutOptionals).not.toHaveProperty('latitude');
    });

    it('should handle duplicate addresses with case variations', () => {
      const addresses = [
        'Bahnhofstrasse 1, Zurich',
        'BAHNHOFSTRASSE 1, ZURICH',
        'bahnhofstrasse 1, zurich',
      ];

      const normalized = addresses.map((a) => a.toLowerCase().trim());
      const unique = new Set(normalized);

      expect(unique.size).toBe(1); // All normalize to same value
    });
  });
});
