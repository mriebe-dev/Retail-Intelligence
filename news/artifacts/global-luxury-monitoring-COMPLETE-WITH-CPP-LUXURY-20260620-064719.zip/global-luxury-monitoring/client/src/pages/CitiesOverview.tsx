import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin, TrendingUp, Building2, Users } from 'lucide-react';

interface City {
  id: string;
  name: string;
  country: string;
  region: 'swiss' | 'alpine' | 'global';
  stores: number;
  streets: number;
  peakRent: string;
  vacancyRate: string;
  footfall: string;
  description: string;
  image?: string;
}

// Sample data - will be replaced with database queries
const CITIES_DATA: City[] = [
  // Swiss Cities (9)
  {
    id: 'zurich',
    name: 'Zürich',
    country: 'Switzerland',
    region: 'swiss',
    stores: 90,
    streets: 11,
    peakRent: 'CHF 13\'000/m²',
    vacancyRate: '<0.5%',
    footfall: '13.8 Mio.',
    description: 'Where Precision Meets Global Style. Flagship wave 2025 with Chanel, Apple, and more.',
  },
  {
    id: 'geneva',
    name: 'Genève',
    country: 'Switzerland',
    region: 'swiss',
    stores: 45,
    streets: 8,
    peakRent: 'CHF 8\'500/m²',
    vacancyRate: '1.2%',
    footfall: '8.5 Mio.',
    description: 'Luxury Capital. Premium shopping destination with international brands.',
  },
  {
    id: 'basel',
    name: 'Basel',
    country: 'Switzerland',
    region: 'swiss',
    stores: 35,
    streets: 6,
    peakRent: 'CHF 5\'500/m²',
    vacancyRate: '2.1%',
    footfall: '5.2 Mio.',
    description: 'Cultural Hub. Blend of tradition and modern retail.',
  },
  {
    id: 'bern',
    name: 'Bern',
    country: 'Switzerland',
    region: 'swiss',
    stores: 28,
    streets: 5,
    peakRent: 'CHF 4\'200/m²',
    vacancyRate: '1.8%',
    footfall: '4.1 Mio.',
    description: 'Capital Charm. Historic streets with contemporary retail.',
  },
  {
    id: 'lausanne',
    name: 'Lausanne',
    country: 'Switzerland',
    region: 'swiss',
    stores: 32,
    streets: 6,
    peakRent: 'CHF 6\'800/m²',
    vacancyRate: '1.5%',
    footfall: '6.3 Mio.',
    description: 'Lakeside Elegance. Premium shopping with lake views.',
  },
  {
    id: 'winterthur',
    name: 'Winterthur',
    country: 'Switzerland',
    region: 'swiss',
    stores: 18,
    streets: 4,
    peakRent: 'CHF 3\'500/m²',
    vacancyRate: '2.3%',
    footfall: '3.2 Mio.',
    description: 'Industrial Charm. Growing retail destination.',
  },
  {
    id: 'st-gallen',
    name: 'St. Gallen',
    country: 'Switzerland',
    region: 'swiss',
    stores: 22,
    streets: 5,
    peakRent: 'CHF 4\'100/m²',
    vacancyRate: '1.9%',
    footfall: '3.8 Mio.',
    description: 'Eastern Gateway. Historic city with modern retail.',
  },
  {
    id: 'lugano',
    name: 'Lugano',
    country: 'Switzerland',
    region: 'swiss',
    stores: 15,
    streets: 3,
    peakRent: 'CHF 3\'800/m²',
    vacancyRate: '2.5%',
    footfall: '2.9 Mio.',
    description: 'Southern Charm. Mediterranean retail destination.',
  },
  {
    id: 'lucerne',
    name: 'Luzern',
    country: 'Switzerland',
    region: 'swiss',
    stores: 24,
    streets: 5,
    peakRent: 'CHF 5\'200/m²',
    vacancyRate: '1.7%',
    footfall: '4.5 Mio.',
    description: 'Lakeside Beauty. Premium shopping destination.',
  },

  // Alpine Cities (6)
  {
    id: 'st-moritz',
    name: 'St. Moritz',
    country: 'Switzerland',
    region: 'alpine',
    stores: 12,
    streets: 2,
    peakRent: 'CHF 9\'500/m²',
    vacancyRate: '0.8%',
    footfall: '1.2 Mio.',
    description: 'Alpine Luxury. Exclusive mountain resort destination.',
  },
  {
    id: 'gstaad',
    name: 'Gstaad',
    country: 'Switzerland',
    region: 'alpine',
    stores: 8,
    streets: 2,
    peakRent: 'CHF 7\'200/m²',
    vacancyRate: '1.1%',
    footfall: '0.9 Mio.',
    description: 'Mountain Elegance. Exclusive alpine shopping.',
  },
  {
    id: 'zermatt',
    name: 'Zermatt',
    country: 'Switzerland',
    region: 'alpine',
    stores: 6,
    streets: 1,
    peakRent: 'CHF 6\'800/m²',
    vacancyRate: '1.3%',
    footfall: '0.7 Mio.',
    description: 'Peak Experience. Matterhorn\'s luxury shopping.',
  },
  {
    id: 'interlaken',
    name: 'Interlaken',
    country: 'Switzerland',
    region: 'alpine',
    stores: 10,
    streets: 2,
    peakRent: 'CHF 5\'500/m²',
    vacancyRate: '1.6%',
    footfall: '1.1 Mio.',
    description: 'Adventure Hub. Alpine adventure with retail.',
  },
  {
    id: 'crans-montana',
    name: 'Crans-Montana',
    country: 'Switzerland',
    region: 'alpine',
    stores: 7,
    streets: 1,
    peakRent: 'CHF 4\'800/m²',
    vacancyRate: '1.9%',
    footfall: '0.6 Mio.',
    description: 'Mountain Resort. Exclusive alpine destination.',
  },
  {
    id: 'verbier',
    name: 'Verbier',
    country: 'Switzerland',
    region: 'alpine',
    stores: 5,
    streets: 1,
    peakRent: 'CHF 4\'500/m²',
    vacancyRate: '2.1%',
    footfall: '0.5 Mio.',
    description: 'Alpine Adventure. Premier mountain resort.',
  },

  // Global Cities (Sample - will expand to 27)
  {
    id: 'paris',
    name: 'Paris',
    country: 'France',
    region: 'global',
    stores: 85,
    streets: 12,
    peakRent: '€ 15\'000/m²',
    vacancyRate: '0.3%',
    footfall: '25.3 Mio.',
    description: 'Fashion Capital. World\'s premier luxury destination.',
  },
  {
    id: 'london',
    name: 'London',
    country: 'United Kingdom',
    region: 'global',
    stores: 78,
    streets: 10,
    peakRent: '£ 12\'500/m²',
    vacancyRate: '0.6%',
    footfall: '22.1 Mio.',
    description: 'Global Hub. Premier international shopping destination.',
  },
  {
    id: 'tokyo',
    name: 'Tokyo',
    country: 'Japan',
    region: 'global',
    stores: 92,
    streets: 14,
    peakRent: '¥ 1\'800\'000/m²',
    vacancyRate: '0.2%',
    footfall: '28.5 Mio.',
    description: 'Asian Leader. Cutting-edge luxury retail.',
  },
  {
    id: 'new-york',
    name: 'New York',
    country: 'United States',
    region: 'global',
    stores: 88,
    streets: 11,
    peakRent: '$ 14\'200/m²',
    vacancyRate: '0.5%',
    footfall: '24.7 Mio.',
    description: 'American Icon. The world\'s retail capital.',
  },
  {
    id: 'hong-kong',
    name: 'Hong Kong',
    country: 'China',
    region: 'global',
    stores: 76,
    streets: 9,
    peakRent: '$ 18\'500/m²',
    vacancyRate: '0.4%',
    footfall: '20.3 Mio.',
    description: 'Asian Gateway. Premier luxury destination.',
  },
  {
    id: 'dubai',
    name: 'Dubai',
    country: 'United Arab Emirates',
    region: 'global',
    stores: 64,
    streets: 8,
    peakRent: 'AED 45\'000/m²',
    vacancyRate: '0.8%',
    footfall: '18.2 Mio.',
    description: 'Desert Oasis. Ultra-luxury shopping destination.',
  },
  {
    id: 'singapore',
    name: 'Singapore',
    country: 'Singapore',
    region: 'global',
    stores: 58,
    streets: 7,
    peakRent: '$ 8\'500/m²',
    vacancyRate: '0.7%',
    footfall: '16.4 Mio.',
    description: 'Asian Hub. Premium shopping destination.',
  },
  {
    id: 'milan',
    name: 'Milan',
    country: 'Italy',
    region: 'global',
    stores: 72,
    streets: 9,
    peakRent: '€ 12\'800/m²',
    vacancyRate: '0.5%',
    footfall: '19.8 Mio.',
    description: 'Fashion Mecca. Italian luxury excellence.',
  },
];

export default function CitiesOverview() {
  const [selectedRegion, setSelectedRegion] = useState<'all' | 'swiss' | 'alpine' | 'global'>('all');

  const filteredCities = selectedRegion === 'all' 
    ? CITIES_DATA 
    : CITIES_DATA.filter(city => city.region === selectedRegion);

  const swissCities = CITIES_DATA.filter(c => c.region === 'swiss');
  const alpineCities = CITIES_DATA.filter(c => c.region === 'alpine');
  const globalCities = CITIES_DATA.filter(c => c.region === 'global');

  const totalStores = CITIES_DATA.reduce((sum, city) => sum + city.stores, 0);
  const totalStreets = CITIES_DATA.reduce((sum, city) => sum + city.streets, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100">
      {/* Hero Section */}
      <div className="relative overflow-hidden py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-5xl sm:text-6xl font-bold text-white mb-4 drop-shadow-lg">
              Global Luxury Monitoring
            </h1>
            <p className="text-xl text-white/90 drop-shadow-md">
              Premium Retail Properties Intelligence Platform | Real-time Store Opening Data
            </p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-12">
            <Card className="bg-white/95 backdrop-blur border-2 border-purple-300 p-6 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-gray-600">GLOBAL COVERAGE</span>
                <MapPin className="w-5 h-5 text-purple-600" />
              </div>
              <div className="text-3xl font-bold text-purple-600">{CITIES_DATA.length}</div>
              <div className="text-sm text-gray-600">Cities Worldwide</div>
            </Card>

            <Card className="bg-white/95 backdrop-blur border-2 border-purple-300 p-6 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-gray-600">ACTIVE LOCATIONS</span>
                <Building2 className="w-5 h-5 text-purple-600" />
              </div>
              <div className="text-3xl font-bold text-purple-600">{totalStores}</div>
              <div className="text-sm text-gray-600">Store Openings</div>
            </Card>

            <Card className="bg-white/95 backdrop-blur border-2 border-purple-300 p-6 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-gray-600">PREMIUM STREETS</span>
                <TrendingUp className="w-5 h-5 text-purple-600" />
              </div>
              <div className="text-3xl font-bold text-purple-600">{totalStreets}</div>
              <div className="text-sm text-gray-600">Luxury Destinations</div>
            </Card>

            <Card className="bg-white/95 backdrop-blur border-2 border-purple-300 p-6 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-gray-600">UPDATE FREQUENCY</span>
                <Users className="w-5 h-5 text-purple-600" />
              </div>
              <div className="text-3xl font-bold text-purple-600">Daily</div>
              <div className="text-sm text-gray-600">Real-time Data</div>
            </Card>
          </div>

          {/* Region Filters */}
          <div className="flex flex-wrap gap-2 justify-center mb-12">
            <Button
              onClick={() => setSelectedRegion('all')}
              variant={selectedRegion === 'all' ? 'default' : 'outline'}
              className={selectedRegion === 'all' ? 'bg-purple-600 hover:bg-purple-700' : ''}
            >
              All Cities ({CITIES_DATA.length})
            </Button>
            <Button
              onClick={() => setSelectedRegion('swiss')}
              variant={selectedRegion === 'swiss' ? 'default' : 'outline'}
              className={selectedRegion === 'swiss' ? 'bg-purple-600 hover:bg-purple-700' : ''}
            >
              Swiss ({swissCities.length})
            </Button>
            <Button
              onClick={() => setSelectedRegion('alpine')}
              variant={selectedRegion === 'alpine' ? 'default' : 'outline'}
              className={selectedRegion === 'alpine' ? 'bg-purple-600 hover:bg-purple-700' : ''}
            >
              Alpine ({alpineCities.length})
            </Button>
            <Button
              onClick={() => setSelectedRegion('global')}
              variant={selectedRegion === 'global' ? 'default' : 'outline'}
              className={selectedRegion === 'global' ? 'bg-purple-600 hover:bg-purple-700' : ''}
            >
              Global ({globalCities.length})
            </Button>
          </div>
        </div>
      </div>

      {/* Cities Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCities.map((city) => (
            <a
              key={city.id}
              href={`/city/${city.id}`}
              className="group"
            >
              <Card className="h-full bg-white/90 backdrop-blur border-2 border-purple-200 hover:border-purple-400 hover:shadow-xl transition-all duration-300 overflow-hidden">
                {/* City Header */}
                <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-6 text-white">
                  <h3 className="text-2xl font-bold mb-1">{city.name}</h3>
                  <p className="text-sm text-white/90">{city.country}</p>
                  <p className="text-xs text-white/80 mt-2 italic">{city.description}</p>
                </div>

                {/* Metrics */}
                <div className="p-6 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-purple-50 p-3 rounded-lg">
                      <div className="text-xs font-semibold text-gray-600 mb-1">Stores</div>
                      <div className="text-2xl font-bold text-purple-600">{city.stores}</div>
                    </div>
                    <div className="bg-purple-50 p-3 rounded-lg">
                      <div className="text-xs font-semibold text-gray-600 mb-1">Streets</div>
                      <div className="text-2xl font-bold text-purple-600">{city.streets}</div>
                    </div>
                  </div>

                  <div className="border-t border-purple-200 pt-4 space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-600">Peak Rent:</span>
                      <span className="font-semibold text-purple-600">{city.peakRent}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-600">Vacancy Rate:</span>
                      <span className="font-semibold text-purple-600">{city.vacancyRate}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-600">Footfall/Year:</span>
                      <span className="font-semibold text-purple-600">{city.footfall}</span>
                    </div>
                  </div>

                  <Button className="w-full mt-4 bg-purple-600 hover:bg-purple-700 text-white group-hover:shadow-lg transition-all">
                    Explore City →
                  </Button>
                </div>
              </Card>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
