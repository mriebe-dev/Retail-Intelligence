import React, { useState } from 'react';
import { trpc } from '../lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { AlertCircle, CheckCircle2, Loader2, Play, Square } from 'lucide-react';

/**
 * Admin Panel for Batch Operations
 * Handles batch photo fetching, store updates, and system management
 */

export function AdminPanel() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<'idle' | 'running' | 'completed' | 'error'>('idle');
  const [message, setMessage] = useState('');
  const [results, setResults] = useState<{
    totalStores?: number;
    successfulUpdates?: number;
    failedUpdates?: number;
    results?: any[];
    success?: boolean;
    error?: string;
  } | null>(null);

  // Get count of stores needing photos
  const storesNeedingPhotosQuery = trpc.places.getStoresNeedingPhotosCount.useQuery();
  
  // Batch update mutation
  const batchUpdateMutation = trpc.places.batchUpdateAllStores.useMutation({
    onSuccess: (data) => {
      setResults(data);
      setStatus('completed');
      setIsRunning(false);
      if (data.success) {
        setMessage(`✅ Batch-Verarbeitung abgeschlossen! ${data.successfulUpdates ?? 0} von ${data.totalStores ?? 0} Stores aktualisiert.`);
      } else {
        setMessage(`❌ Fehler: ${data.error || 'Unbekannter Fehler'}`);
      }
    },
    onError: (error) => {
      setStatus('error');
      setIsRunning(false);
      setMessage(`❌ Fehler: ${error.message}`);
    },
  });

  const handleStartBatchUpdate = async () => {
    setIsRunning(true);
    setStatus('running');
    setProgress(0);
    setMessage('Starte Batch-Verarbeitung...');
    setResults(null);

    try {
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + Math.random() * 20;
        });
      }, 1000);

      await batchUpdateMutation.mutateAsync({
        limit: 100, // Process 100 stores at a time
      });

      clearInterval(progressInterval);
      setProgress(100);
    } catch (error) {
      setProgress(0);
    }
  };

  const handleCancel = () => {
    setIsRunning(false);
    setStatus('idle');
    setProgress(0);
    setMessage('Batch-Verarbeitung abgebrochen');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Admin Panel</h1>
          <p className="text-lg text-slate-600">Batch-Operationen und System-Management</p>
        </div>

        {/* Batch Photo Fetching Card */}
        <Card className="border-2 border-slate-200 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-slate-200">
            <CardTitle className="flex items-center gap-2">
              📸 Batch-Foto-Abruf
            </CardTitle>
            <CardDescription>
              Rufe automatisch Fotos für alle Stores via Google Places API ab
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            {/* Status Information */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <p className="text-sm text-slate-600 font-medium">Stores ohne Fotos</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">
                  {typeof storesNeedingPhotosQuery.data === 'object' && storesNeedingPhotosQuery.data?.count ? storesNeedingPhotosQuery.data.count : '-'}
                </p>
              </div>
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <p className="text-sm text-slate-600 font-medium">Status</p>
                <p className="text-lg font-bold text-slate-900 mt-2 capitalize">
                  {status === 'idle' && '🟢 Bereit'}
                  {status === 'running' && '🟡 Läuft'}
                  {status === 'completed' && '✅ Abgeschlossen'}
                  {status === 'error' && '❌ Fehler'}
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            {isRunning && (
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <p className="text-sm font-medium text-slate-700">Fortschritt</p>
                  <p className="text-sm font-bold text-slate-900">{Math.round(progress)}%</p>
                </div>
                <Progress value={progress} className="h-3" />
              </div>
            )}

            {/* Status Message */}
            {message && (
              <Alert className={`border-2 ${
                status === 'completed' ? 'border-green-200 bg-green-50' :
                status === 'error' ? 'border-red-200 bg-red-50' :
                status === 'running' ? 'border-blue-200 bg-blue-50' :
                'border-slate-200 bg-slate-50'
              }`}>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className={`${
                  status === 'completed' ? 'text-green-800' :
                  status === 'error' ? 'text-red-800' :
                  status === 'running' ? 'text-blue-800' :
                  'text-slate-800'
                }`}>
                  {message}
                </AlertDescription>
              </Alert>
            )}

            {/* Results Summary */}
            {results && (
              <div className="bg-green-50 border-2 border-green-200 rounded-lg p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  <p className="font-bold text-green-900">Batch-Verarbeitung abgeschlossen</p>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-green-700 font-medium">Gesamt</p>
                    <p className="text-2xl font-bold text-green-900">{results.totalStores}</p>
                  </div>
                  <div>
                    <p className="text-green-700 font-medium">Erfolgreich</p>
                    <p className="text-2xl font-bold text-green-600">{results.successfulUpdates}</p>
                  </div>
                  <div>
                    <p className="text-red-700 font-medium">Fehler</p>
                    <p className="text-2xl font-bold text-red-600">{results.failedUpdates}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              {!isRunning ? (
                <Button
                  onClick={handleStartBatchUpdate}
                  disabled={isRunning || (typeof storesNeedingPhotosQuery.data === 'object' && storesNeedingPhotosQuery.data?.count ? storesNeedingPhotosQuery.data.count : 0) === 0}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded-lg flex items-center justify-center gap-2"
                >
                  <Play className="h-4 w-4" />
                  Batch-Verarbeitung starten
                </Button>
              ) : (
                <Button
                  onClick={handleCancel}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-2 rounded-lg flex items-center justify-center gap-2"
                >
                  <Square className="h-4 w-4" />
                  Abbrechen
                </Button>
              )}
            </div>

            {/* Information Box */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-900">
              <p className="font-medium mb-2">ℹ️ Informationen:</p>
              <ul className="space-y-1 text-blue-800">
                <li>• Ruft Fotos für alle Stores ohne Fotos ab</li>
                <li>• Nutzt Google Places API für automatische Foto-Extraktion</li>
                <li>• Speichert Fotos in S3 und aktualisiert die Datenbank</li>
                <li>• Kann mehrere Minuten dauern, je nach Anzahl der Stores</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Additional Admin Features */}
        <Card className="border-2 border-slate-200 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50 border-b border-slate-200">
            <CardTitle>📊 Weitere Admin-Funktionen</CardTitle>
            <CardDescription>Kommende Features</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <p className="font-medium text-slate-900">Store-Daten exportieren</p>
                  <p className="text-sm text-slate-600">Exportiere alle Store-Daten als CSV</p>
                </div>
                <Button disabled className="text-slate-500">Bald</Button>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <p className="font-medium text-slate-900">Datenbank-Backup</p>
                  <p className="text-sm text-slate-600">Erstelle ein Backup der aktuellen Datenbank</p>
                </div>
                <Button disabled className="text-slate-500">Bald</Button>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <p className="font-medium text-slate-900">System-Logs</p>
                  <p className="text-sm text-slate-600">Zeige System-Logs und Fehler-Reports</p>
                </div>
                <Button disabled className="text-slate-500">Bald</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
