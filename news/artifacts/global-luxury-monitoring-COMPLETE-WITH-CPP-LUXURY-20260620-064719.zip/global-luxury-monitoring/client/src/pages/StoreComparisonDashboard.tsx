import React, { useState } from 'react';
import { trpc } from '../lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { X, Plus, Download } from 'lucide-react';

/**
 * Store Comparison Dashboard
 * Compare multiple stores side-by-side with detailed metrics
 */

interface SelectedStore {
  id: string;
  brandName: string;
  city: string;
  street: string;
  country: string;
  openingDate: string;
  category: string;
  photoUrl?: string;
  openingHours?: string;
  squareMeters?: number;
}

export function StoreComparisonDashboard() {
  const [selectedStores, setSelectedStores] = useState<SelectedStore[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);

  // Search stores
  const searchResults = trpc.news.list.useQuery(
    { brand: searchQuery },
    { enabled: searchQuery.length > 2 }
  );

  const handleAddStore = (store: any) => {
    if (!selectedStores.find(s => s.id === store.id)) {
      setSelectedStores([...selectedStores, {
        id: store.id,
        brandName: store.brandName,
        city: store.city,
        street: store.street,
        country: store.country,
        openingDate: store.openingDate,
        category: store.category,
        photoUrl: store.photoUrl,
        openingHours: store.openingHours,
        squareMeters: store.squareMeters,
      }]);
      setSearchQuery('');
      setShowSearch(false);
    }
  };

  const handleRemoveStore = (storeId: string) => {
    setSelectedStores(selectedStores.filter(s => s.id !== storeId));
  };

  const handleExportComparison = () => {
    const csv = [
      ['Brand', 'Stadt', 'Straße', 'Land', 'Eröffnung', 'Kategorie', 'Größe (m²)'],
      ...selectedStores.map(s => [
        s.brandName,
        s.city,
        s.street,
        s.country,
        s.openingDate,
        s.category,
        s.squareMeters || '-',
      ]),
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `store-comparison-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Store-Vergleich Dashboard</h1>
          <p className="text-lg text-slate-600">Vergleiche mehrere Stores nebeneinander</p>
        </div>

        {/* Add Store Section */}
        <Card className="border-2 border-slate-200 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-slate-200">
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Store hinzufügen
            </CardTitle>
            <CardDescription>
              Suche und füge Stores zum Vergleich hinzu
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Nach Brand, Stadt oder Straße suchen..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setShowSearch(true)}
                  className="flex-1"
                />
                <Button
                  onClick={() => setShowSearch(!showSearch)}
                  variant="outline"
                >
                  {showSearch ? 'Schließen' : 'Suchen'}
                </Button>
              </div>

              {/* Search Results */}
              {showSearch && searchResults.data && Array.isArray(searchResults.data) && searchResults.data.length > 0 && (
                <div className="border border-slate-200 rounded-lg max-h-96 overflow-y-auto">
                  {searchResults.data.map((store: any) => (
                    <div
                      key={store.id}
                      className="flex items-center justify-between p-3 border-b border-slate-100 hover:bg-slate-50"
                    >
                      <div className="flex-1">
                        <p className="font-semibold text-slate-900">{store.brandName}</p>
                        <p className="text-sm text-slate-600">
                          {store.street}, {store.city}, {store.country}
                        </p>
                      </div>
                      <Button
                        onClick={() => handleAddStore(store)}
                        size="sm"
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              {/* Selected Stores Count */}
              <div className="text-sm text-slate-600">
                {selectedStores.length} Store(s) ausgewählt
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Comparison Table */}
        {selectedStores.length > 0 && (
          <Card className="border-2 border-slate-200 shadow-lg overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50 border-b border-slate-200">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Vergleich ({selectedStores.length} Stores)</CardTitle>
                  <CardDescription>Detaillierte Übersicht aller ausgewählten Stores</CardDescription>
                </div>
                <Button
                  onClick={handleExportComparison}
                  className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
                >
                  <Download className="h-4 w-4" />
                  Als CSV exportieren
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-6 overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b-2 border-slate-300 bg-slate-50">
                    <th className="text-left p-3 font-semibold text-slate-900">Brand</th>
                    <th className="text-left p-3 font-semibold text-slate-900">Stadt</th>
                    <th className="text-left p-3 font-semibold text-slate-900">Straße</th>
                    <th className="text-left p-3 font-semibold text-slate-900">Land</th>
                    <th className="text-left p-3 font-semibold text-slate-900">Eröffnung</th>
                    <th className="text-left p-3 font-semibold text-slate-900">Kategorie</th>
                    <th className="text-left p-3 font-semibold text-slate-900">Größe (m²)</th>
                    <th className="text-center p-3 font-semibold text-slate-900">Aktion</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedStores.map((store, idx) => (
                    <tr
                      key={store.id}
                      className={`border-b border-slate-200 ${
                        idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'
                      } hover:bg-blue-50 transition-colors`}
                    >
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          {store.photoUrl && (
                            <img
                              src={store.photoUrl}
                              alt={store.brandName}
                              className="h-8 w-8 rounded object-cover"
                            />
                          )}
                          <span className="font-semibold text-slate-900">{store.brandName}</span>
                        </div>
                      </td>
                      <td className="p-3 text-slate-700">{store.city}</td>
                      <td className="p-3 text-slate-700">{store.street}</td>
                      <td className="p-3 text-slate-700">{store.country}</td>
                      <td className="p-3 text-slate-700">{store.openingDate}</td>
                      <td className="p-3">
                        <Badge variant="secondary">{store.category}</Badge>
                      </td>
                      <td className="p-3 text-slate-700">
                        {store.squareMeters ? `${store.squareMeters.toLocaleString()}` : '-'}
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => handleRemoveStore(store.id)}
                          className="text-red-600 hover:text-red-800 transition-colors"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>
        )}

        {/* Empty State */}
        {selectedStores.length === 0 && (
          <Card className="border-2 border-dashed border-slate-300 bg-slate-50">
            <CardContent className="pt-12 pb-12 text-center">
              <p className="text-lg text-slate-600 mb-4">Keine Stores ausgewählt</p>
              <p className="text-sm text-slate-500">
                Verwende die Suchfunktion oben, um Stores zum Vergleich hinzuzufügen
              </p>
            </CardContent>
          </Card>
        )}

        {/* Comparison Insights */}
        {selectedStores.length > 1 && (
          <Card className="border-2 border-slate-200 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-amber-50 to-orange-50 border-b border-slate-200">
              <CardTitle>📊 Vergleichs-Insights</CardTitle>
              <CardDescription>Automatisch berechnete Metriken</CardDescription>
            </CardHeader>
            <CardContent className="pt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <p className="text-sm text-slate-600 font-medium">Durchschnittliche Größe</p>
                <p className="text-2xl font-bold text-slate-900 mt-2">
                  {selectedStores.filter(s => s.squareMeters).length > 0
                    ? Math.round(
                        selectedStores
                          .filter(s => s.squareMeters)
                          .reduce((sum, s) => sum + (s.squareMeters || 0), 0) /
                          selectedStores.filter(s => s.squareMeters).length
                      ).toLocaleString()
                    : '-'}
                  {selectedStores.filter(s => s.squareMeters).length > 0 ? ' m²' : ''}
                </p>
              </div>
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <p className="text-sm text-slate-600 font-medium">Länder</p>
                <p className="text-2xl font-bold text-slate-900 mt-2">
                  {new Set(selectedStores.map(s => s.country)).size}
                </p>
              </div>
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <p className="text-sm text-slate-600 font-medium">Städte</p>
                <p className="text-2xl font-bold text-slate-900 mt-2">
                  {new Set(selectedStores.map(s => s.city)).size}
                </p>
              </div>
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <p className="text-sm text-slate-600 font-medium">Kategorien</p>
                <p className="text-2xl font-bold text-slate-900 mt-2">
                  {new Set(selectedStores.map(s => s.category)).size}
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
