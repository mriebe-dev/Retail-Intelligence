import { useState } from "react";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronRight, MapPin, Store } from "lucide-react";

const ALPINE_DESTINATIONS = [
  {
    slug: "st-moritz",
    name: "St. Moritz",
    description:
      "Das legendäre Schweizer Luxus-Skiresort mit exklusiven Boutiquen und Flagship Stores von Prada und Moncler.",
    highlights: [
      "Prada Flagship Store",
      "Moncler Boutique",
      "Cartier",
      "Louis Vuitton",
      "Hermès",
    ],
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800",
    stats: {
      stores: 24,
      flagships: 3,
      avgRent: "CHF 2,800/m²",
      vacancy: "1.5%",
    },
  },
  {
    slug: "gstaad",
    name: "Gstaad",
    description:
      "Exklusives Bergresort mit gehobenen Boutiquen und internationalen Luxusmarken.",
    highlights: [
      "Gucci",
      "Prada",
      "Louis Vuitton",
      "Hermès",
      "Burberry",
    ],
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800",
    stats: {
      stores: 18,
      flagships: 2,
      avgRent: "CHF 2,500/m²",
      vacancy: "2.0%",
    },
  },
  {
    slug: "zermatt",
    name: "Zermatt",
    description:
      "Bergdorf am Fuße des Matterhorns mit ausgewählten Luxus-Boutiquen und Sportmarken.",
    highlights: [
      "Gucci",
      "Prada",
      "Canada Goose",
      "Moncler",
      "Rolex",
    ],
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800",
    stats: {
      stores: 12,
      flagships: 1,
      avgRent: "CHF 2,200/m²",
      vacancy: "2.5%",
    },
  },
  {
    slug: "interlaken",
    name: "Interlaken",
    description:
      "Beliebtes Touristenziel mit vielfältigem Luxus-Einzelhandel zwischen den Berner Alpen.",
    highlights: [
      "Louis Vuitton",
      "Gucci",
      "Hermès",
      "Cartier",
      "Swatch",
    ],
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800",
    stats: {
      stores: 16,
      flagships: 2,
      avgRent: "CHF 2,000/m²",
      vacancy: "3.0%",
    },
  },
];

export default function AlpineDestinations() {
  const [selectedDestination, setSelectedDestination] = useState<string | null>(
    null
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <div className="relative h-96 bg-gradient-to-r from-blue-600 to-blue-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full -mr-48 -mt-48"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white rounded-full -ml-48 -mb-48"></div>
        </div>

        <div className="relative h-full flex flex-col justify-center items-center text-center px-4">
          <MapPin className="w-16 h-16 mb-4" />
          <h1 className="text-5xl font-bold mb-4">Alpine Luxus-Destinationen</h1>
          <p className="text-xl max-w-2xl">
            Entdecken Sie die exklusivsten Luxus-Retail-Standorte in den Schweizer Alpen
          </p>
        </div>
      </div>

      {/* Destinations Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {ALPINE_DESTINATIONS.map((destination) => (
            <Card
              key={destination.slug}
              className="overflow-hidden hover:shadow-lg transition-shadow"
            >
              {/* Image */}
              <div className="relative h-48 bg-gray-200 overflow-hidden">
                <img
                  src={destination.image}
                  alt={destination.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-20"></div>
              </div>

              {/* Content */}
              <div className="p-6">
                {/* Title */}
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  {destination.name}
                </h2>

                {/* Description */}
                <p className="text-gray-600 mb-4 text-sm">
                  {destination.description}
                </p>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-4 mb-6 py-4 border-y border-gray-200">
                  <div>
                    <div className="text-2xl font-bold text-blue-600">
                      {destination.stats.stores}
                    </div>
                    <div className="text-xs text-gray-600">Stores</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-blue-600">
                      {destination.stats.flagships}
                    </div>
                    <div className="text-xs text-gray-600">Flagship Stores</div>
                  </div>
                  <div>
                    <div className="text-sm font-bold text-gray-900">
                      {destination.stats.avgRent}
                    </div>
                    <div className="text-xs text-gray-600">Ø Miete</div>
                  </div>
                  <div>
                    <div className="text-sm font-bold text-gray-900">
                      {destination.stats.vacancy}
                    </div>
                    <div className="text-xs text-gray-600">Leerstand</div>
                  </div>
                </div>

                {/* Highlights */}
                <div className="mb-6">
                  <h3 className="text-sm font-semibold text-gray-900 mb-3">
                    Marken vor Ort
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {destination.highlights.map((brand) => (
                      <span
                        key={brand}
                        className="inline-block bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-xs font-medium"
                      >
                        {brand}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Action Button */}
                <Link href={`/city/${destination.slug}`}>
                  <a className="w-full">
                    <Button className="w-full flex items-center justify-center gap-2">
                      <Store className="w-4 h-4" />
                      Standorte anzeigen
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </a>
                </Link>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Market Insights Section */}
      <div className="bg-gray-100 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Alpine Markt-Insights
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Saisonalität
              </h3>
              <p className="text-gray-600 text-sm">
                Alpine Destinationen zeigen starke Saisonalität mit höheren Besucherzahlen in Winter und Sommer. Luxus-Einzelhandel profitiert von internationalen Touristen.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Premiumpositionierung
              </h3>
              <p className="text-gray-600 text-sm">
                Alpine Resorts konzentrieren sich auf High-End-Marken mit starkem Fokus auf Uhren, Schmuck und Sportluxus-Kategorien.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Wachstumstrends
              </h3>
              <p className="text-gray-600 text-sm">
                Neue Flagship-Eröffnungen bei Prada und Moncler in St. Moritz signalisieren verstärktes Engagement in Alpine Luxus-Destinationen.
              </p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
