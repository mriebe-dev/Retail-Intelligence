import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { TrendingUp, Building2, MapPin, Shirt, Zap } from "lucide-react";

interface OpeningTrend {
  date: string;
  count: number;
  cumulative: number;
}

interface BrandStats {
  brand: string;
  openings: number;
  percentage: number;
}

interface CityStats {
  city: string;
  openings: number;
  percentage: number;
}

interface StreetStats {
  street: string;
  city: string;
  openings: number;
  brands: number;
}

interface CategoryStats {
  category: string;
  count: number;
  percentage: number;
}

export function MarketAnalytics() {
  const [selectedCity, setSelectedCity] = useState<string>("Zurich");

  // Fetch all analytics data
  const overviewQuery = trpc.analytics.overview.useQuery();
  const trendsQuery = trpc.analytics.openingTrends.useQuery({});
  const topBrandsQuery = trpc.analytics.topBrands.useQuery({ limit: 20 });
  const cityDistributionQuery = trpc.analytics.cityDistribution.useQuery();
  const topStreetsQuery = trpc.analytics.topStreets.useQuery({ limit: 20 });
  const categoryDistributionQuery = trpc.analytics.categoryDistribution.useQuery();
  const yearOverYearQuery = trpc.analytics.yearOverYear.useQuery();
  const brandsByCityQuery = trpc.analytics.brandsByCity.useQuery({ city: selectedCity });

  const overview = overviewQuery.data;
  const trends = trendsQuery.data || [];
  const topBrands = topBrandsQuery.data || [];
  const cityDistribution = cityDistributionQuery.data || [];
  const topStreets = topStreetsQuery.data || [];
  const categoryDistribution = categoryDistributionQuery.data || [];
  const yearOverYear = yearOverYearQuery.data || [];
  const brandsByCity = brandsByCityQuery.data || [];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Market Analytics</h1>
        <p className="text-muted-foreground mt-2">
          Comprehensive insights into luxury retail market trends and performance
        </p>
      </div>

      {/* Overview Cards */}
      {overview && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-blue-600" />
                Total Openings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overview.totalOpenings}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {overview.dateRange.start} to {overview.dateRange.end}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Shirt className="h-4 w-4 text-purple-600" />
                Unique Brands
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overview.totalBrands}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Active luxury brands
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Building2 className="h-4 w-4 text-green-600" />
                Cities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overview.totalCities}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Global markets covered
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <MapPin className="h-4 w-4 text-red-600" />
                Streets
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overview.totalStreets}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Premium shopping locations
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Opening Trends */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Opening Trends Over Time
          </CardTitle>
          <CardDescription>
            Monthly store openings and cumulative growth
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {trends.length > 0 ? (
              <>
                <div className="text-sm text-muted-foreground">
                  Latest month: {trends[trends.length - 1].count} openings
                </div>
                <div className="space-y-2">
                  {trends.slice(-12).map((trend, idx) => (
                    <div key={idx} className="flex items-center gap-4">
                      <div className="w-20 text-sm font-medium">{trend.date}</div>
                      <div className="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full"
                          style={{
                            width: `${Math.min((trend.count / 10) * 100, 100)}%`,
                          }}
                        />
                      </div>
                      <div className="w-12 text-right text-sm font-semibold">
                        {trend.count}
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <p className="text-muted-foreground">No trend data available</p>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Brands */}
        <Card>
          <CardHeader>
            <CardTitle>Top Brands</CardTitle>
            <CardDescription>
              Brands with most store openings
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topBrands.length > 0 ? (
                topBrands.map((brand, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="font-medium text-sm">{brand.brand}</div>
                      <div className="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-1">
                        <div
                          className="bg-purple-600 h-2 rounded-full"
                          style={{ width: `${brand.percentage}%` }}
                        />
                      </div>
                    </div>
                    <div className="ml-4 text-right">
                      <div className="font-semibold text-sm">{brand.openings}</div>
                      <div className="text-xs text-muted-foreground">
                        {brand.percentage.toFixed(1)}%
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground">No brand data available</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Category Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Category Distribution</CardTitle>
            <CardDescription>
              Breakdown by product category
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {categoryDistribution.length > 0 ? (
                categoryDistribution.map((category, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{category.category}</Badge>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-sm">{category.count}</div>
                      <div className="text-xs text-muted-foreground">
                        {category.percentage.toFixed(1)}%
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground">No category data available</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* City Distribution */}
      <Card>
        <CardHeader>
          <CardTitle>City Distribution</CardTitle>
          <CardDescription>
            Geographic breakdown of store openings
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {cityDistribution.length > 0 ? (
              cityDistribution.map((city, idx) => (
                <div
                  key={idx}
                  className="rounded-lg border p-4 cursor-pointer hover:bg-accent transition-colors"
                  onClick={() => setSelectedCity(city.city)}
                >
                  <div className="font-semibold">{city.city}</div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm text-muted-foreground">Openings</span>
                    <span className="text-lg font-bold">{city.openings}</span>
                  </div>
                  <div className="text-xs text-muted-foreground mt-2">
                    {city.percentage.toFixed(1)}% of total
                  </div>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground">No city data available</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Top Streets */}
      <Card>
        <CardHeader>
          <CardTitle>Top Shopping Streets</CardTitle>
          <CardDescription>
            Most active luxury retail locations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topStreets.length > 0 ? (
              topStreets.map((street, idx) => (
                <div key={idx} className="flex items-center justify-between border-b pb-3 last:border-0">
                  <div>
                    <div className="font-medium">{street.street}</div>
                    <div className="text-sm text-muted-foreground">{street.city}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{street.openings}</div>
                    <div className="text-xs text-muted-foreground">
                      {street.brands} brands
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground">No street data available</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Year-over-Year Comparison */}
      <Card>
        <CardHeader>
          <CardTitle>Year-over-Year Comparison</CardTitle>
          <CardDescription>
            Annual growth trends
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {yearOverYear.length > 0 ? (
              yearOverYear.map((year, idx) => (
                <div key={idx} className="flex items-center gap-4">
                  <div className="w-16 font-semibold">{year.year}</div>
                  <div className="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-3">
                    <div
                      className="bg-green-600 h-3 rounded-full"
                      style={{
                        width: `${Math.min((year.count / Math.max(...yearOverYear.map((y) => y.count))) * 100, 100)}%`,
                      }}
                    />
                  </div>
                  <div className="w-12 text-right font-semibold">{year.count}</div>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground">No year-over-year data available</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Brands by Selected City */}
      {selectedCity && (
        <Card>
          <CardHeader>
            <CardTitle>Top Brands in {selectedCity}</CardTitle>
            <CardDescription>
              Brand performance in the selected city
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {brandsByCity.length > 0 ? (
                brandsByCity.map((brand, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="font-medium text-sm">{brand.brand}</div>
                      <div className="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-1">
                        <div
                          className="bg-orange-600 h-2 rounded-full"
                          style={{ width: `${brand.percentage}%` }}
                        />
                      </div>
                    </div>
                    <div className="ml-4 text-right">
                      <div className="font-semibold text-sm">{brand.openings}</div>
                      <div className="text-xs text-muted-foreground">
                        {brand.percentage.toFixed(1)}%
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground">
                  No brand data available for {selectedCity}
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
