import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { LuxuryMap } from "@/components/LuxuryMap";
import { LuxuryFilters, type FilterOptions } from "@/components/LuxuryFilters";
import { Card } from "@/components/ui/card";
import { Loader2, MapPin, TrendingUp, Home } from "lucide-react";
import { useState, useMemo } from "react";

// City metadata with hero images and descriptions
const CITY_DATA: Record<string, { name: string; country: string; description: string; heroImage: string; mainStreet: string; metrics: Record<string, string | number> }> = {
  zurich: {
    name: "Zürich",
    country: "Switzerland",
    description: "Zürich ist das führende Luxus-Retail-Zentrum der Schweiz mit der renommierten Bahnhofstrasse als Haupteinkaufsmeile.",
    heroImage: "https://images.unsplash.com/photo-1488747807830-63789f68bb65?w=1200&h=400&fit=crop",
    mainStreet: "Bahnhofstrasse",
    metrics: {
      "Neueröffnungen 2024": 8,
      "Flagship Stores": 12,
      "Durchschnittliche Miete": "CHF 3,500/m²",
      "Leerstand": "2.5%",
    },
  },
  geneva: {
    name: "Genf",
    country: "Switzerland",
    description: "Genf ist bekannt für seine exklusiven Boutiquen an der Rue du Rhône und als Zentrum für Uhren- und Schmuckmarken.",
    heroImage: "https://images.unsplash.com/photo-1488747807830-63789f68bb65?w=1200&h=400&fit=crop",
    mainStreet: "Rue du Rhône",
    metrics: {
      "Neueröffnungen 2024": 6,
      "Flagship Stores": 9,
      "Durchschnittliche Miete": "CHF 3,200/m²",
      "Leerstand": "3.0%",
    },
  },
  basel: {
    name: "Basel",
    country: "Switzerland",
    description: "Basel bietet eine vielfältige Einzelhandelslandschaft mit Fokus auf Kunstgalerien und gehobene Boutiquen.",
    heroImage: "https://images.unsplash.com/photo-1488747807830-63789f68bb65?w=1200&h=400&fit=crop",
    mainStreet: "Freie Strasse",
    metrics: {
      "Neueröffnungen 2024": 4,
      "Flagship Stores": 6,
      "Durchschnittliche Miete": "CHF 2,200/m²",
      "Leerstand": "4.0%",
    },
  },
  bern: {
    name: "Bern",
    country: "Switzerland",
    description: "Berns Altstadt mit ihren Arkaden bietet ein einzigartiges Einkaufserlebnis mit internationalen Marken.",
    heroImage: "https://images.unsplash.com/photo-1488747807830-63789f68bb65?w=1200&h=400&fit=crop",
    mainStreet: "Marktgasse",
    metrics: {
      "Neueröffnungen 2024": 3,
      "Flagship Stores": 5,
      "Durchschnittliche Miete": "CHF 1,800/m²",
      "Leerstand": "3.5%",
    },
  },
  lausanne: {
    name: "Lausanne",
    country: "Switzerland",
    description: "Lausanne ist ein wichtiges Einzelhandelszentrum mit modernen Shopping-Malls und exklusiven Boutiquen.",
    heroImage: "https://images.unsplash.com/photo-1488747807830-63789f68bb65?w=1200&h=400&fit=crop",
    mainStreet: "Rue de Bourg",
    metrics: {
      "Neueröffnungen 2024": 5,
      "Flagship Stores": 7,
      "Durchschnittliche Miete": "CHF 2,000/m²",
      "Leerstand": "3.8%",
    },
  },
  winterthur: {
    name: "Winterthur",
    country: "Switzerland",
    description: "Winterthur entwickelt sich zu einem wichtigen Einzelhandelszentrum mit Fokus auf Mode und Lifestyle.",
    heroImage: "https://images.unsplash.com/photo-1488747807830-63789f68bb65?w=1200&h=400&fit=crop",
    mainStreet: "Marktgasse",
    metrics: {
      "Neueröffnungen 2024": 3,
      "Flagship Stores": 4,
      "Durchschnittliche Miete": "CHF 1,500/m²",
      "Leerstand": "4.5%",
    },
  },
  "st-gallen": {
    name: "St. Gallen",
    country: "Switzerland",
    description: "St. Gallen ist ein regionales Einzelhandelszentrum mit gehobenen Boutiquen und internationalen Marken.",
    heroImage: "https://images.unsplash.com/photo-1488747807830-63789f68bb65?w=1200&h=400&fit=crop",
    mainStreet: "Marktplatz",
    metrics: {
      "Neueröffnungen 2024": 2,
      "Flagship Stores": 3,
      "Durchschnittliche Miete": "CHF 1,200/m²",
      "Leerstand": "5.0%",
    },
  },
  lugano: {
    name: "Lugano",
    country: "Switzerland",
    description: "Lugano ist bekannt für seine gehobenen Boutiquen und zieht internationale Käufer an.",
    heroImage: "https://images.unsplash.com/photo-1488747807830-63789f68bb65?w=1200&h=400&fit=crop",
    mainStreet: "Via Nassa",
    metrics: {
      "Neueröffnungen 2024": 2,
      "Flagship Stores": 3,
      "Durchschnittliche Miete": "CHF 1,800/m²",
      "Leerstand": "4.0%",
    },
  },
  lucerne: {
    name: "Luzern",
    country: "Switzerland",
    description: "Luzern ist ein touristisches Einzelhandelszentrum mit gehobenen Boutiquen und internationalen Marken.",
    heroImage: "https://images.unsplash.com/photo-1488747807830-63789f68bb65?w=1200&h=400&fit=crop",
    mainStreet: "Bahnhofstrasse",
    metrics: {
      "Neueröffnungen 2024": 3,
      "Flagship Stores": 4,
      "Durchschnittliche Miete": "CHF 1,600/m²",
      "Leerstand": "4.5%",
    },
  },
};

export default function CityPage() {
  const [, params] = useRoute("/city/:city");
  const cityParam = params?.city?.toLowerCase().replace(" ", "-");
  const cityInfo = CITY_DATA[cityParam || ""];

  const [filters, setFilters] = useState<FilterOptions>({
    searchText: "",
    brand: "",
    newsType: "",
    source: "",
    dateFrom: "",
    dateTo: "",
  });

  const { data: stores, isLoading } = trpc.luxury.list.useQuery(
    { city: cityInfo?.name || "" },
    { enabled: !!cityInfo }
  );

  // Group stores by street
  const storesByStreet = useMemo(() => {
    if (!stores) return {};

    const grouped: Record<string, typeof stores> = {};
    stores.forEach((store: typeof stores[0]) => {
      // Extract street name from address (simple heuristic)
      const streetMatch = store.locationAddress?.match(/^([^,]+)/);
      const street = streetMatch ? streetMatch[1].trim() : "Sonstige";

      if (!grouped[street]) {
        grouped[street] = [];
      }
      grouped[street].push(store);
    });

    return grouped;
  }, [stores]);

  // Apply filters
  const filteredStores = useMemo(() => {
    if (!stores) return {};

    const filtered: Record<string, typeof stores> = {};

    Object.entries(storesByStreet).forEach(([street, streetStores]) => {
      const filteredList = streetStores.filter((store: typeof streetStores[0]) => {
        const matchesSearch =
          !filters.searchText ||
          store.brandName.toLowerCase().includes(filters.searchText.toLowerCase()) ||
          store.summary?.toLowerCase().includes(filters.searchText.toLowerCase());

        const matchesBrand = !filters.brand || store.brandName === filters.brand;
        const matchesNewsType = !filters.newsType || store.newsType === filters.newsType;
        const matchesSource = !filters.source || store.sourceName === filters.source;

        return matchesSearch && matchesBrand && matchesNewsType && matchesSource;
      });

      if (filteredList.length > 0) {
        filtered[street] = filteredList;
      }
    });

    return filtered;
  }, [storesByStreet, filters]);

  if (!cityInfo) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-500">City not found</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="animate-spin w-8 h-8" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div
        className="relative h-96 bg-cover bg-center"
        style={{
          backgroundImage: `url('${cityInfo.heroImage}')`,
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-5xl font-bold mb-2">{cityInfo.name}</h1>
            <p className="text-xl text-gray-200">{cityInfo.country}</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Description */}
        <div className="mb-8">
          <p className="text-lg text-gray-700 leading-relaxed">{cityInfo.description}</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {Object.entries(cityInfo.metrics).map(([key, value]) => (
            <Card key={key} className="p-4">
              <p className="text-sm text-gray-600 mb-1">{key}</p>
              <p className="text-2xl font-bold text-blue-600">{value}</p>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <div className="mb-8">
          <LuxuryFilters
            onFilterChange={setFilters}
            brands={Array.from(new Set(stores?.map((s: typeof stores[0]) => s.brandName) || []))}
            newsTypes={Array.from(new Set(stores?.map((s: typeof stores[0]) => s.newsType) || []))}
            sources={Array.from(new Set(stores?.map((s: typeof stores[0]) => s.sourceName).filter((x: any) => Boolean(x)) || [])) as string[]}
          />
        </div>

        {/* Map and Store List */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Map */}
          <div className="lg:col-span-1">
            <Card className="p-4 sticky top-4">
              <h2 className="text-xl font-bold mb-4">Standort-Karte</h2>
              <LuxuryMap city={cityInfo.name} country={cityInfo.country} />
            </Card>
          </div>

          {/* Store Lists by Street */}
          <div className="lg:col-span-2">
            {Object.entries(filteredStores).length > 0 ? (
              Object.entries(filteredStores).map(([street, streetStores]) => (
                <div key={street} className="mb-8">
                  <h2 className="text-2xl font-bold mb-4 pb-2 border-b-2 border-blue-600">
                    {street}
                    <span className="text-sm text-gray-600 ml-2">({streetStores.length} Stores)</span>
                  </h2>

                  <div className="space-y-4">
                    {streetStores
                      .sort((a: typeof streetStores[0], b: typeof streetStores[0]) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .map((store: typeof streetStores[0]) => (
                        <Card key={store.id} className="p-4 hover:shadow-md transition-shadow">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h3 className="font-bold text-lg">{store.brandName}</h3>
                              <p className="text-gray-600 text-sm">{store.locationAddress}</p>
                            </div>
                            <div className="flex gap-2">
                              <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                                {store.newsType}
                              </span>
                              {store.sourceName && (
                                <span className="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded">
                                  {store.sourceName}
                                </span>
                              )}
                            </div>
                          </div>

                          <p className="text-sm text-gray-700 mb-2">{store.summary}</p>

                          <div className="flex justify-between items-center text-xs text-gray-500">
                            <span>{new Date(store.date).toLocaleDateString("de-CH")}</span>
                            {store.sourceUrl && (
                              <a
                                href={store.sourceUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:underline"
                              >
                                View Source
                              </a>
                            )}
                          </div>
                        </Card>
                      ))}
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center text-gray-500 py-8">
                No stores found matching your filters
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
