import { useState } from "react";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronRight, Globe, Store } from "lucide-react";

const GLOBAL_CITIES = [
  {
    slug: "paris",
    name: "Paris",
    country: "Frankreich",
    description:
      "Die Hauptstadt der Mode mit der legendären Avenue des Champs-Élysées und exklusiven Boutiquen in Le Marais und Rue Saint-Honoré.",
    highlights: [
      "Chanel",
      "Louis Vuitton",
      "Dior",
      "Hermès",
      "Cartier",
    ],
    image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800",
    stats: {
      stores: 156,
      flagships: 18,
      avgRent: "EUR 3,800/m²",
      vacancy: "1.8%",
    },
  },
  {
    slug: "london",
    name: "London",
    country: "Vereinigtes Königreich",
    description:
      "Globales Luxus-Einkaufszentrum mit Bond Street, Regent Street und Harrods als Hauptattraktionen.",
    highlights: [
      "Burberry",
      "Selfridges",
      "Harrods",
      "Gucci",
      "Prada",
    ],
    image: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=800",
    stats: {
      stores: 142,
      flagships: 15,
      avgRent: "GBP 3,200/m²",
      vacancy: "2.2%",
    },
  },
  {
    slug: "new-york",
    name: "New York",
    country: "Vereinigte Staaten",
    description:
      "Die Welthauptstadt des Luxus mit der Fifth Avenue, SoHo und der Upper East Side als Premium-Standorte.",
    highlights: [
      "Saks Fifth Avenue",
      "Bergdorf Goodman",
      "Bloomingdale's",
      "Gucci",
      "Louis Vuitton",
    ],
    image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800",
    stats: {
      stores: 189,
      flagships: 22,
      avgRent: "USD 4,500/m²",
      vacancy: "1.5%",
    },
  },
  {
    slug: "milan",
    name: "Mailand",
    country: "Italien",
    description:
      "Italiens Modehauptstadt mit der Quadrilatero d'Oro (Goldenes Viereck) als Zentrum des Luxus-Einzelhandels.",
    highlights: [
      "Prada",
      "Gucci",
      "Armani",
      "Dolce & Gabbana",
      "Versace",
    ],
    image: "https://images.unsplash.com/photo-1488747807830-63789f68bb65?w=800",
    stats: {
      stores: 128,
      flagships: 14,
      avgRent: "EUR 3,200/m²",
      vacancy: "2.5%",
    },
  },
  {
    slug: "tokyo",
    name: "Tokio",
    country: "Japan",
    description:
      "Asiens führendes Luxus-Einzelhandelszentrum mit Ginza, Shibuya und Shinjuku als Haupteinkaufsmeilen.",
    highlights: [
      "Isetan",
      "Mitsukoshi",
      "Louis Vuitton",
      "Chanel",
      "Hermès",
    ],
    image: "https://images.unsplash.com/photo-1540959375944-7049f642e9a9?w=800",
    stats: {
      stores: 174,
      flagships: 19,
      avgRent: "JPY 450,000/m²",
      vacancy: "1.2%",
    },
  },
  {
    slug: "hong-kong",
    name: "Hongkong",
    country: "China",
    description:
      "Asiatisches Einkaufsparadies mit Causeway Bay, Central und Tsim Sha Tsui als Luxus-Destinationen.",
    highlights: [
      "Harbour City",
      "IFC Mall",
      "Lane Crawford",
      "Gucci",
      "Prada",
    ],
    image: "https://images.unsplash.com/photo-1519167758481-83f19106ae4f?w=800",
    stats: {
      stores: 151,
      flagships: 16,
      avgRent: "HKD 2,800/m²",
      vacancy: "1.9%",
    },
  },
];

export default function GlobalCities() {
  const [selectedCity, setSelectedCity] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <div className="relative h-96 bg-gradient-to-r from-purple-600 to-purple-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full -mr-48 -mt-48"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white rounded-full -ml-48 -mb-48"></div>
        </div>

        <div className="relative h-full flex flex-col justify-center items-center text-center px-4">
          <Globe className="w-16 h-16 mb-4" />
          <h1 className="text-5xl font-bold mb-4">Globale Luxus-Städte</h1>
          <p className="text-xl max-w-2xl">
            Entdecken Sie die weltweit führenden Luxus-Retail-Destinationen in Paris, London, New York, Mailand, Tokio und Hongkong
          </p>
        </div>
      </div>

      {/* Cities Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {GLOBAL_CITIES.map((city) => (
            <Card
              key={city.slug}
              className="overflow-hidden hover:shadow-lg transition-shadow"
            >
              {/* Image */}
              <div className="relative h-48 bg-gray-200 overflow-hidden">
                <img
                  src={city.image}
                  alt={city.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-20"></div>
              </div>

              {/* Content */}
              <div className="p-6">
                {/* Title */}
                <div className="mb-2">
                  <h2 className="text-2xl font-bold text-gray-900">
                    {city.name}
                  </h2>
                  <p className="text-sm text-gray-600">{city.country}</p>
                </div>

                {/* Description */}
                <p className="text-gray-600 mb-4 text-sm">
                  {city.description}
                </p>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-4 mb-6 py-4 border-y border-gray-200">
                  <div>
                    <div className="text-2xl font-bold text-purple-600">
                      {city.stats.stores}
                    </div>
                    <div className="text-xs text-gray-600">Stores</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-purple-600">
                      {city.stats.flagships}
                    </div>
                    <div className="text-xs text-gray-600">Flagship Stores</div>
                  </div>
                  <div>
                    <div className="text-sm font-bold text-gray-900">
                      {city.stats.avgRent}
                    </div>
                    <div className="text-xs text-gray-600">Ø Miete</div>
                  </div>
                  <div>
                    <div className="text-sm font-bold text-gray-900">
                      {city.stats.vacancy}
                    </div>
                    <div className="text-xs text-gray-600">Leerstand</div>
                  </div>
                </div>

                {/* Highlights */}
                <div className="mb-6">
                  <h3 className="text-sm font-semibold text-gray-900 mb-3">
                    Marken vor Ort
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {city.highlights.map((brand) => (
                      <span
                        key={brand}
                        className="inline-block bg-purple-50 text-purple-700 px-3 py-1 rounded-full text-xs font-medium"
                      >
                        {brand}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Action Button */}
                <Link href={`/city/${city.slug}`}>
                  <a className="w-full">
                    <Button className="w-full flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700">
                      <Store className="w-4 h-4" />
                      Standorte anzeigen
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </a>
                </Link>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Global Market Insights Section */}
      <div className="bg-gray-100 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Globale Markt-Insights
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Marktführer
              </h3>
              <p className="text-gray-600 text-sm">
                New York führt mit 189 Stores und der höchsten Mietpreisen (USD 4,500/m²) weltweit. Paris folgt mit 156 Stores und einer starken Präsenz von französischen Luxusmarken.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Asiatisches Wachstum
              </h3>
              <p className="text-gray-600 text-sm">
                Tokio und Hongkong zeigen starkes Wachstum mit niedriger Leerstandsquote (1.2% und 1.9%). Asiatische Konsumenten treiben die Nachfrage nach Luxusmarken an.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Europäische Stabilität
              </h3>
              <p className="text-gray-600 text-sm">
                Paris, London und Mailand zeigen stabile Märkte mit etablierten Luxus-Ökosystemen. Diese Städte bleiben die Zentren der globalen Modebranche.
              </p>
            </Card>
          </div>
        </div>
      </div>

      {/* Statistics Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">
          Globale Statistiken
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <Card className="p-6 text-center">
            <div className="text-4xl font-bold text-purple-600 mb-2">
              940
            </div>
            <p className="text-gray-600">Gesamtstores</p>
          </Card>

          <Card className="p-6 text-center">
            <div className="text-4xl font-bold text-purple-600 mb-2">
              104
            </div>
            <p className="text-gray-600">Flagship Stores</p>
          </Card>

          <Card className="p-6 text-center">
            <div className="text-4xl font-bold text-purple-600 mb-2">
              6
            </div>
            <p className="text-gray-600">Kontinente</p>
          </Card>

          <Card className="p-6 text-center">
            <div className="text-4xl font-bold text-purple-600 mb-2">
              1.8%
            </div>
            <p className="text-gray-600">Ø Leerstand</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
