import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Search, Download } from "lucide-react";

export default function NewsArchive() {
  const [city, setCity] = useState<string>("");
  const [brand, setBrand] = useState<string>("");
  const [status, setStatus] = useState<"new" | "archived" | "featured" | "">(
    ""
  );
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch news with filters
  const { data: news, isLoading, refetch } = trpc.news.list.useQuery({
    city: city || undefined,
    brand: brand || undefined,
    status: (status as any) || undefined,
  });

  // Migration mutation
  const migrationMutation = trpc.news.migrateFromStores.useMutation({
    onSuccess: () => {
      refetch();
    },
  });

  // Filter news by search query
  const filteredNews = news?.filter(
    (item) =>
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.brandName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.city.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">News Archive</h1>
          <p className="text-muted-foreground">
            Browse and manage luxury retail news from around the world
          </p>
        </div>

        {/* Migration Button */}
        <Card className="mb-8 p-6 bg-blue-50 border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold mb-1">Migrate Stores to News</h3>
              <p className="text-sm text-muted-foreground">
                Import all existing store data into the news archive
              </p>
            </div>
            <Button
              onClick={() => migrationMutation.mutate()}
              disabled={migrationMutation.isPending}
              className="gap-2"
            >
              {migrationMutation.isPending && (
                <Loader2 className="h-4 w-4 animate-spin" />
              )}
              {migrationMutation.isPending ? "Migrating..." : "Start Migration"}
            </Button>
          </div>
          {migrationMutation.data && (
            <div className="mt-4 p-3 bg-white rounded border border-green-200">
              <p className="text-sm text-green-700">
                ✓ Migration complete: {migrationMutation.data.migrated} migrated,{" "}
                {migrationMutation.data.skipped} skipped,{" "}
                {migrationMutation.data.errors} errors
              </p>
            </div>
          )}
        </Card>

        {/* Filters */}
        <Card className="mb-8 p-6">
          <h3 className="font-semibold mb-4">Filters</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search news..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">City</label>
              <Input
                placeholder="Filter by city"
                value={city}
                onChange={(e) => setCity(e.target.value)}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Brand</label>
              <Input
                placeholder="Filter by brand"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Status</label>
              <Select value={status || "all"} onValueChange={(value: any) => setStatus(value === "all" ? "" : value)}>
                <SelectTrigger>
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="archived">Archived</SelectItem>
                  <SelectItem value="featured">Featured</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        {/* News List */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-lg">
              News ({filteredNews?.length || 0})
            </h3>
            <Button variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : filteredNews && filteredNews.length > 0 ? (
            <div className="grid gap-4">
              {filteredNews.map((item) => (
                <Card key={item.id} className="p-6 hover:shadow-lg transition-shadow">
                  <div className="flex gap-4">
                    {/* Photo */}
                    {item.photoUrl && (
                      <div className="w-24 h-24 flex-shrink-0">
                        <img
                          src={item.photoUrl}
                          alt={item.brandName}
                          className="w-full h-full object-cover rounded"
                        />
                      </div>
                    )}

                    {/* Content */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4 className="font-semibold text-lg">
                            {item.brandName}
                          </h4>
                          <p className="text-sm text-muted-foreground">
                            {item.city}, {item.country}
                          </p>
                        </div>
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-medium ${
                            item.status === "new"
                              ? "bg-blue-100 text-blue-700"
                              : item.status === "featured"
                              ? "bg-purple-100 text-purple-700"
                              : "bg-gray-100 text-gray-700"
                          }`}
                        >
                          {item.status}
                        </span>
                      </div>

                      <p className="text-sm mb-3 line-clamp-2">
                        {item.description}
                      </p>

                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <div className="flex gap-4">
                          <span>{item.date}</span>
                          <span>{item.source}</span>
                          {item.street && <span>{item.street}</span>}
                        </div>
                        {item.link && (
                          <a
                            href={item.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline"
                          >
                            View Source →
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center">
              <p className="text-muted-foreground">
                No news found. Try adjusting your filters or start the migration.
              </p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
