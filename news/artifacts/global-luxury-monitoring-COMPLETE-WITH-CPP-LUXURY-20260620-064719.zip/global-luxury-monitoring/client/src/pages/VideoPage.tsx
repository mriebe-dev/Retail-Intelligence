import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Play } from 'lucide-react';

export default function VideoPage() {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Video Section */}
      <section className="relative w-full h-screen bg-black flex items-center justify-center overflow-hidden">
        {/* Video Background */}
        <div className="absolute inset-0 w-full h-full">
          <video
            className="w-full h-full object-cover"
            poster="https://images.unsplash.com/photo-1556740738-b6a63e27c4df?w=1920&h=1080&fit=crop"
            controls={isPlaying}
          >
            <source
              src="https://commondatastorage.googleapis.com/gtv-videos-library/sample/BigBuckBunny.mp4"
              type="video/mp4"
            />
            Your browser does not support the video tag.
          </video>
        </div>

        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-black/40" />

        {/* Play Button Overlay */}
        {!isPlaying && (
          <button
            onClick={() => setIsPlaying(true)}
            className="relative z-10 flex items-center justify-center w-24 h-24 rounded-full bg-white/20 hover:bg-white/30 transition-all duration-300 backdrop-blur-sm border border-white/30"
          >
            <Play className="w-10 h-10 text-white fill-white" />
          </button>
        )}

        {/* Content Overlay */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center z-5 px-4">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-4 drop-shadow-lg">
            Global Luxury Monitoring
          </h1>
          <p className="text-xl md:text-2xl text-white/90 drop-shadow-lg">
            Switzerland's Leading Retail Intelligence Platform
          </p>
        </div>

        {/* Video Duration Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 flex items-center gap-4 text-white text-sm">
          <span>00:00</span>
          <div className="w-64 h-1 bg-white/30 rounded-full" />
          <span>01:29</span>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-b from-background to-muted">
        <div className="max-w-4xl mx-auto flex flex-col items-center gap-8">
          {/* Statistics */}
          <div className="grid grid-cols-3 gap-8 w-full">
            <div className="text-center">
              <div className="text-4xl font-bold text-foreground mb-2">125+</div>
              <div className="text-sm text-muted-foreground">Städte weltweit</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-foreground mb-2">430+</div>
              <div className="text-sm text-muted-foreground">Premium Straßen</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-foreground mb-2">1,087</div>
              <div className="text-sm text-muted-foreground">Store Eröffnungen</div>
            </div>
          </div>

          {/* Primary CTA Button */}
          <Button
            size="lg"
            className="w-full sm:w-auto px-12 py-6 text-lg font-semibold rounded-full bg-gradient-to-r from-orange-500 to-pink-600 hover:from-orange-600 hover:to-pink-700 text-white shadow-lg"
          >
            Vollständigen Bericht kaufen
          </Button>

          {/* Secondary CTA Button - 14 Day Trial */}
          <div className="relative">
            <Button
              variant="outline"
              size="lg"
              className="w-full sm:w-auto px-12 py-6 text-lg font-semibold rounded-full border-2 border-pink-500 text-pink-600 hover:bg-pink-50 transition-all duration-300"
            >
              14-Tage Trial starten
            </Button>
            {/* Highlight Circle */}
            <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full border-2 border-pink-500 animate-pulse" />
          </div>

          {/* Description Text */}
          <p className="text-center text-muted-foreground max-w-2xl mt-4">
            Entdecken Sie die umfassendste Analyse der wertvollsten Einkaufsstraßen weltweit.
            Vertrauen Sie auf 20+ Jahre Datenanalyse und tägliche Aktualisierungen.
          </p>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-background">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Warum Global Luxury Monitoring?</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="p-6 rounded-lg border border-border bg-card">
              <h3 className="text-xl font-semibold mb-3">Real-time Daten</h3>
              <p className="text-muted-foreground">
                Tägliche Aktualisierung aller Store-Eröffnungen, Schließungen und Marktveränderungen.
              </p>
            </div>
            
            <div className="p-6 rounded-lg border border-border bg-card">
              <h3 className="text-xl font-semibold mb-3">Globale Abdeckung</h3>
              <p className="text-muted-foreground">
                125+ Städte in 60+ Ländern mit Premium-Straßen und Luxus-Marken.
              </p>
            </div>
            
            <div className="p-6 rounded-lg border border-border bg-card">
              <h3 className="text-xl font-semibold mb-3">Deep Dive Analyse</h3>
              <p className="text-muted-foreground">
                Detaillierte Marktanalyse pro Straße mit Ownership-Struktur und Trends.
              </p>
            </div>
            
            <div className="p-6 rounded-lg border border-border bg-card">
              <h3 className="text-xl font-semibold mb-3">Expert Insights</h3>
              <p className="text-muted-foreground">
                Professionelle Analysen von führenden Immobilien- und Retail-Experten.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
