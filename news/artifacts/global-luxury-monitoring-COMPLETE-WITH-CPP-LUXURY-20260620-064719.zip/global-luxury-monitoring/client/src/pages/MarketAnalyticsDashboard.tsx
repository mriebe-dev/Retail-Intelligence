import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, ComposedChart } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Home, Users } from 'lucide-react';

// Mock data for market analytics
const marketData = {
  rentTrends: [
    { month: 'Jan 2024', zurich: 450, geneva: 480, basel: 380, london: 520, paris: 490, tokyo: 510, nyc: 550 },
    { month: 'Feb 2024', zurich: 460, geneva: 485, basel: 385, london: 530, paris: 495, tokyo: 515, nyc: 560 },
    { month: 'Mar 2024', zurich: 470, geneva: 490, basel: 390, london: 540, paris: 500, tokyo: 520, nyc: 570 },
    { month: 'Apr 2024', zurich: 480, geneva: 495, basel: 395, london: 550, paris: 505, tokyo: 525, nyc: 580 },
    { month: 'May 2024', zurich: 490, geneva: 500, basel: 400, london: 560, paris: 510, tokyo: 530, nyc: 590 },
  ],
  vacancyRates: [
    { city: 'Zurich', rate: 4.2, trend: -0.5, stores: 130 },
    { city: 'Geneva', rate: 3.8, trend: -0.3, stores: 125 },
    { city: 'Basel', rate: 6.5, trend: 0.2, stores: 45 },
    { city: 'London', rate: 5.1, trend: -0.8, stores: 180 },
    { city: 'Paris', rate: 4.9, trend: -0.4, stores: 165 },
    { city: 'Tokyo', rate: 2.3, trend: -0.1, stores: 95 },
    { city: 'NYC', rate: 3.5, trend: -0.6, stores: 140 },
    { city: 'Milan', rate: 5.7, trend: 0.1, stores: 110 },
  ],
  footfallMetrics: [
    { city: 'Zurich', footfall: 2850, avgSpend: 450, conversionRate: 8.5 },
    { city: 'Geneva', footfall: 2650, avgSpend: 520, conversionRate: 9.2 },
    { city: 'London', footfall: 3200, avgSpend: 480, conversionRate: 8.1 },
    { city: 'Paris', footfall: 2950, avgSpend: 510, conversionRate: 8.8 },
    { city: 'Tokyo', footfall: 3100, avgSpend: 580, conversionRate: 9.5 },
    { city: 'NYC', footfall: 3400, avgSpend: 520, conversionRate: 8.3 },
    { city: 'Milan', footfall: 2700, avgSpend: 490, conversionRate: 8.7 },
  ],
  investmentOpportunities: [
    { city: 'Shenzhen', potential: 'High', rentGrowth: '+12%', vacancyRate: 2.1, roi: '18-22%' },
    { city: 'Dubai', potential: 'High', rentGrowth: '+10%', vacancyRate: 3.2, roi: '15-19%' },
    { city: 'Bangkok', potential: 'Medium', rentGrowth: '+8%', vacancyRate: 4.5, roi: '12-16%' },
    { city: 'Mumbai', potential: 'High', rentGrowth: '+11%', vacancyRate: 2.8, roi: '16-20%' },
    { city: 'Singapore', potential: 'Medium', rentGrowth: '+6%', vacancyRate: 3.8, roi: '10-14%' },
  ],
};

export default function MarketAnalyticsDashboard() {
  const [selectedCities, setSelectedCities] = useState(['zurich', 'geneva', 'london', 'paris']);
  const [timeRange, setTimeRange] = useState('6m');

  const rentTrendsData = marketData.rentTrends.map(item => ({
    month: item.month,
    ...(selectedCities.includes('zurich') && { zurich: item.zurich }),
    ...(selectedCities.includes('geneva') && { geneva: item.geneva }),
    ...(selectedCities.includes('london') && { london: item.london }),
    ...(selectedCities.includes('paris') && { paris: item.paris }),
    ...(selectedCities.includes('tokyo') && { tokyo: item.tokyo }),
    ...(selectedCities.includes('nyc') && { nyc: item.nyc }),
  }));

  const COLORS = ['#ec4899', '#f43f5e', '#3b82f6', '#8b5cf6', '#ec4899', '#f97316', '#22c55e'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className="text-4xl font-bold text-white flex items-center gap-3 mb-2">
            <TrendingUp className="w-10 h-10" />
            Market Analytics Dashboard
          </h1>
          <p className="text-white/80">Real-time luxury retail market intelligence and investment opportunities</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <Card className="mb-8 bg-white/80 backdrop-blur border-purple-200">
          <CardHeader>
            <CardTitle className="text-lg">Market Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-sm font-semibold mb-3 block">Select Cities</label>
                <div className="flex flex-wrap gap-2">
                  {['zurich', 'geneva', 'london', 'paris', 'tokyo', 'nyc', 'basel'].map(city => (
                    <button
                      key={city}
                      onClick={() => setSelectedCities(prev => 
                        prev.includes(city) ? prev.filter(c => c !== city) : [...prev, city]
                      )}
                      className={`px-3 py-1 rounded-full text-sm font-medium transition-all ${
                        selectedCities.includes(city)
                          ? 'bg-purple-600 text-white'
                          : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                      }`}
                    >
                      {city.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm font-semibold mb-3 block">Time Range</label>
                <Select value={timeRange} onValueChange={setTimeRange}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3m">Last 3 Months</SelectItem>
                    <SelectItem value="6m">Last 6 Months</SelectItem>
                    <SelectItem value="1y">Last Year</SelectItem>
                    <SelectItem value="2y">Last 2 Years</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Rent Trends */}
        <Card className="mb-8 bg-white/80 backdrop-blur border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-purple-600" />
              Rent Trends (€/sqm/year)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={rentTrendsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb' }} />
                <Legend />
                {selectedCities.includes('zurich') && <Line type="monotone" dataKey="zurich" stroke="#ec4899" strokeWidth={2} />}
                {selectedCities.includes('geneva') && <Line type="monotone" dataKey="geneva" stroke="#f43f5e" strokeWidth={2} />}
                {selectedCities.includes('london') && <Line type="monotone" dataKey="london" stroke="#3b82f6" strokeWidth={2} />}
                {selectedCities.includes('paris') && <Line type="monotone" dataKey="paris" stroke="#8b5cf6" strokeWidth={2} />}
                {selectedCities.includes('tokyo') && <Line type="monotone" dataKey="tokyo" stroke="#f97316" strokeWidth={2} />}
                {selectedCities.includes('nyc') && <Line type="monotone" dataKey="nyc" stroke="#22c55e" strokeWidth={2} />}
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Vacancy Rates & Footfall */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Vacancy Rates */}
          <Card className="bg-white/80 backdrop-blur border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Home className="w-5 h-5 text-purple-600" />
                Vacancy Rates by City
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={marketData.vacancyRates}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="city" />
                  <YAxis />
                  <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb' }} />
                  <Bar dataKey="rate" fill="#ec4899" name="Vacancy Rate (%)" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Footfall Metrics */}
          <Card className="bg-white/80 backdrop-blur border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-600" />
                Footfall & Conversion
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <ScatterChart>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="footfall" name="Daily Footfall" />
                  <YAxis dataKey="conversionRate" name="Conversion Rate (%)" />
                  <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb' }} cursor={{ strokeDasharray: '3 3' }} />
                  <Scatter name="Cities" data={marketData.footfallMetrics} fill="#8b5cf6" />
                </ScatterChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Investment Opportunities */}
        <Card className="bg-white/80 backdrop-blur border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-600" />
              Investment Opportunities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {marketData.investmentOpportunities.map((opp, idx) => (
                <div key={idx} className="p-4 rounded-lg border-2 border-green-200 bg-green-50">
                  <h4 className="font-bold text-lg mb-2">{opp.city}</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Potential:</span>
                      <span className={`font-semibold ${opp.potential === 'High' ? 'text-green-600' : 'text-yellow-600'}`}>
                        {opp.potential}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Rent Growth:</span>
                      <span className="font-semibold text-green-600">{opp.rentGrowth}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Vacancy:</span>
                      <span className="font-semibold">{opp.vacancyRate}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">ROI:</span>
                      <span className="font-semibold text-green-600">{opp.roi}</span>
                    </div>
                  </div>
                  <Button className="w-full mt-3 bg-green-600 hover:bg-green-700 text-white">
                    View Details
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
