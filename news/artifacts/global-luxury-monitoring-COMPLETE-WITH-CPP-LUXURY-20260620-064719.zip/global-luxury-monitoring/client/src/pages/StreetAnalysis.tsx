import { useRoute } from "wouter";
import { useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, TrendingUp, Store, MapPin, Calendar } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

export default function StreetAnalysis() {
  const [, params] = useRoute("/street/:city/:street");
  const city = params?.city || "";
  const street = decodeURIComponent(params?.street || "");

  const { data: stores, isLoading } = trpc.luxury.list.useQuery({});

  // Filter stores for this street
  const streetStores = useMemo(() => {
    if (!stores) return [];
    return stores.filter(
      (s) =>
        s.city?.toLowerCase() === city.toLowerCase() &&
        s.locationAddress?.includes(street)
    );
  }, [stores, city, street]);

  // Calculate metrics
  const metrics = useMemo(() => {
    if (streetStores.length === 0) {
      return {
        totalStores: 0,
        brands: 0,
        categories: [],
        avgRent: "N/A",
        vacancy: "N/A",
        recentOpenings: 0,
      };
    }

    const categories = Array.from(new Set(streetStores.map((s) => s.newsType)));
    const recentOpenings = streetStores.filter((s) => {
      const date = new Date(s.date);
      const oneYearAgo = new Date();
      oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
      return date > oneYearAgo;
    }).length;

    return {
      totalStores: streetStores.length,
      brands: Array.from(new Set(streetStores.map((s) => s.brandName))).length,
      categories,
      avgRent: "CHF 3,500/m²", // Placeholder
      vacancy: "2.5%", // Placeholder
      recentOpenings,
    };
  }, [streetStores]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-gray-500">Laden...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4 mb-4">
            <Link href={`/city/${city}`}>
              <a className="flex items-center gap-2 text-blue-600 hover:text-blue-700">
                <ArrowLeft className="w-4 h-4" />
                Zurück zu {city}
              </a>
            </Link>
          </div>
          <h1 className="text-4xl font-bold text-gray-900">{street}</h1>
          <p className="text-gray-600 mt-2">
            Deep Dive Analysis für {street} in {city}
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Stores</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {metrics.totalStores}
                </p>
              </div>
              <Store className="w-10 h-10 text-blue-200" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Marken</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {metrics.brands}
                </p>
              </div>
              <TrendingUp className="w-10 h-10 text-green-200" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Neueröffnungen</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {metrics.recentOpenings}
                </p>
              </div>
              <Calendar className="w-10 h-10 text-orange-200" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Ø Miete</p>
                <p className="text-2xl font-bold text-gray-900 mt-2">
                  {metrics.avgRent}
                </p>
              </div>
              <MapPin className="w-10 h-10 text-red-200" />
            </div>
          </Card>
        </div>

        {/* Store List */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Stores auf {street}
          </h2>

          {streetStores.length === 0 ? (
            <Card className="p-12 text-center">
              <p className="text-gray-500">
                Keine Stores auf dieser Straße gefunden.
              </p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {streetStores.map((store) => (
                <Card key={store.id} className="p-6 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900">
                        {store.brandName}
                      </h3>
                      <p className="text-gray-600 text-sm mt-1">
                        {store.locationAddress}
                      </p>
                      <div className="flex items-center gap-4 mt-4">
                        <span className="inline-block bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-xs font-medium">
                          {store.newsType}
                        </span>
                        <span className="text-gray-500 text-sm">
                          {new Date(store.date).toLocaleDateString("de-CH")}
                        </span>
                      </div>
                      {store.summary && (
                        <p className="text-gray-600 text-sm mt-3">
                          {store.summary}
                        </p>
                      )}
                    </div>
                    <Link href={`/store/${store.id}`}>
                      <a>
                        <Button variant="outline" size="sm">
                          Details
                        </Button>
                      </a>
                    </Link>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Category Breakdown */}
        {metrics.categories.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Kategorien
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {metrics.categories.map((category) => {
                const count = streetStores.filter(
                  (s) => s.newsType === category
                ).length;
                const percentage = (count / streetStores.length) * 100;

                return (
                  <Card key={category} className="p-6">
                    <h3 className="font-semibold text-gray-900 mb-3">
                      {category}
                    </h3>
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-blue-600">
                        {count}
                      </span>
                      <span className="text-gray-500 text-sm">
                        {percentage.toFixed(1)}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2 mt-4">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${percentage}%` }}
                      ></div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Market Insights */}
        <div className="bg-white rounded-lg border border-gray-200 p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Markt-Insights
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">
                Positionierung
              </h3>
              <p className="text-gray-600">
                {street} ist eine der führenden Luxus-Einzelhandelstraßen in{" "}
                {city} mit {metrics.totalStores} etablierten Stores und{" "}
                {metrics.brands} verschiedenen Marken.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">
                Entwicklung
              </h3>
              <p className="text-gray-600">
                In den letzten 12 Monaten wurden {metrics.recentOpenings} neue
                Stores auf {street} eröffnet, was ein starkes Interesse an
                dieser Premium-Location zeigt.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
