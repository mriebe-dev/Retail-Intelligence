'use client';

import React, { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { MapPin, TrendingUp, Globe, ChevronDown, Search, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { MapView } from '@/components/Map';
import { useAuth } from '@/_core/hooks/useAuth';
import { getLoginUrl } from '@/const';

interface Store {
  id: string;
  brandName: string;
  city: string;
  country: string;
  latitude?: number;
  longitude?: number;
  size_sqm?: number;
  opening_date?: string;
  store_type?: string;
  category?: string;
}

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [stores, setStores] = useState<Store[]>([]);
  const [selectedCity, setSelectedCity] = useState('Zurich');
  const [filteredStores, setFilteredStores] = useState<Store[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  // Cities with store counts
  const cities = [
    { name: 'Zurich', count: 130, flag: '🇨🇭' },
    { name: 'Geneva', count: 130, flag: '🇨🇭' },
    { name: 'Basel', count: 0, flag: '🇨🇭' },
    { name: 'Bern', count: 0, flag: '🇨🇭' },
    { name: 'Lausanne', count: 0, flag: '🇨🇭' },
    { name: 'Winterthur', count: 0, flag: '🇨🇭' },
    { name: 'St. Gallen', count: 0, flag: '🇨🇭' },
    { name: 'Lugano', count: 21, flag: '🇨🇭' },
    { name: 'Lucerne', count: 21, flag: '🇨🇭' },
  ];

  // Load stores
  useEffect(() => {
    const loadStores = async () => {
      try {
        setLoading(true);
        const response = await fetch('/comprehensive_luxury_stores.json');
        if (response.ok) {
          const data = await response.json();
          setStores(data.stores || []);
        }
      } catch (error) {
        console.error('Failed to load stores:', error);
      } finally {
        setLoading(false);
      }
    };
    loadStores();
  }, []);

  // Filter stores by city
  useEffect(() => {
    let filtered = stores.filter(store => 
      store.city.toLowerCase() === selectedCity.toLowerCase()
    );

    if (searchTerm) {
      filtered = filtered.filter(store =>
        store.brandName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        store.city.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredStores(filtered.slice(0, 10));
  }, [stores, selectedCity, searchTerm]);

  const totalStores = 16765; // From database (incl. CPP-LUXURY import)
  const totalNews = 16765; // From database
  const uniqueCities = 85; // From database
  const uniqueBrands = 320; // From database
  const newOpenings = stores.filter(s => {
    const date = new Date(s.opening_date || '');
    const now = new Date();
    const twoYearsAgo = new Date(now.getFullYear() - 2, now.getMonth(), now.getDate());
    return date >= twoYearsAgo;
  }).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100 text-gray-900">
      {/* Hero Section with Gradient Background */}
      <div className="relative bg-gradient-to-br from-blue-200 via-purple-200 to-pink-200 min-h-screen pt-20 pb-20">
        {/* Navigation */}
        <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <Globe className="w-8 h-8 text-purple-600" />
                <h1 className="text-2xl font-bold text-gray-900">Global Luxury Monitoring</h1>
              </div>
            
            <div className="hidden md:flex items-center gap-6">
              <Link href="/">
                <span className="hover:text-blue-400 cursor-pointer">HOME</span>
              </Link>
              <div className="group relative">
                <button className="flex items-center gap-1 hover:text-blue-400">
                  Cities (9) <ChevronDown className="w-4 h-4" />
                </button>
              </div>
              <Link href="/">
                <span className="hover:text-blue-400 cursor-pointer">Alpen (4)</span>
              </Link>
              <Link href="/">
                <span className="hover:text-blue-400 cursor-pointer">Global (6)</span>
              </Link>
              <Link href="/">
                <span className="hover:text-blue-400 cursor-pointer">Market Analysis</span>
              </Link>
              <Link href="/">
                <span className="hover:text-blue-400 cursor-pointer">Highlights</span>
              </Link>
              <Link href="/">
                <span className="hover:text-blue-400 cursor-pointer">News Archive</span>
              </Link>
              
              {isAuthenticated ? (
                <Link href="/admin">
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">Admin</Button>
                </Link>
              ) : (
                <a href={getLoginUrl()}>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">Sign In</Button>
                </a>
              )}
            </div>
            </div>
          </div>
        </nav>

        {/* Hero Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <div className="mb-8 inline-block bg-amber-200/80 text-amber-900 px-4 py-2 rounded-full text-sm font-semibold">
            Trusted by Leading Luxury Retailers & Property Managers
          </div>
          
          <h2 className="text-6xl md:text-7xl font-bold text-white mb-6 drop-shadow-lg">
            Global Luxury Monitoring
          </h2>
          
          <p className="text-2xl text-white/90 mb-12 drop-shadow-md">
            Premium Retail Properties Intelligence Platform | Real-time Store Opening Data
          </p>
          
          {/* Key Metrics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
            <div className="bg-white/95 backdrop-blur rounded-2xl p-6 border-2 border-blue-300 shadow-lg">
              <div className="text-4xl font-bold text-purple-600 mb-2">{totalStores}</div>
              <div className="text-sm text-gray-600 font-semibold">LUXURY STORES</div>
              <div className="text-xs text-gray-500 mt-1">Global Coverage</div>
            </div>
            
            <div className="bg-white/95 backdrop-blur rounded-2xl p-6 border-2 border-blue-300 shadow-lg">
              <div className="text-4xl font-bold text-purple-600 mb-2">3,854</div>
              <div className="text-sm text-gray-600 font-semibold">OPENING NEWS</div>
              <div className="text-xs text-gray-500 mt-1">Real-time Data</div>
            </div>
            
            <div className="bg-white/95 backdrop-blur rounded-2xl p-6 border-2 border-blue-300 shadow-lg">
              <div className="text-4xl font-bold text-purple-600 mb-2">{uniqueCities}</div>
              <div className="text-sm text-gray-600 font-semibold">CITIES</div>
              <div className="text-xs text-gray-500 mt-1">Worldwide</div>
            </div>
            
            <div className="bg-white/95 backdrop-blur rounded-2xl p-6 border-2 border-blue-300 shadow-lg">
              <div className="text-4xl font-bold text-purple-600 mb-2">{uniqueBrands}</div>
              <div className="text-sm text-gray-600 font-semibold">BRANDS</div>
              <div className="text-xs text-gray-500 mt-1">Luxury Retail</div>
            </div>
          </div>
          
          {/* Feature Highlights */}
          <div className="flex flex-wrap justify-center gap-6 mb-12">
            <div className="flex items-center gap-2 text-white drop-shadow-md">
              <span className="text-green-300 text-xl">✓</span>
              <span className="font-semibold">20+ Years Luxury Retail Expertise</span>
            </div>
            <div className="flex items-center gap-2 text-white drop-shadow-md">
              <span className="text-green-300 text-xl">✓</span>
              <span className="font-semibold">500+ Properties Tracked</span>
            </div>
            <div className="flex items-center gap-2 text-white drop-shadow-md">
              <span className="text-green-300 text-xl">✓</span>
              <span className="font-semibold">Updated Daily</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Section */}
      <div className="bg-white">

      <div className="flex h-[calc(100vh-80px)]">
        {/* Left Sidebar - Cities */}
        <div className="w-64 bg-gray-900 border-r border-gray-800 overflow-y-auto">
          <div className="p-6">
            <h2 className="text-lg font-semibold mb-4">Swiss Cities</h2>
            <div className="space-y-2">
              {cities.map(city => (
                <button
                  key={city.name}
                  onClick={() => setSelectedCity(city.name)}
                  className={`w-full text-left px-4 py-3 rounded-lg transition ${
                    selectedCity === city.name
                      ? 'bg-blue-600 text-white'
                      : 'hover:bg-gray-800 text-gray-300'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span>{city.name}</span>
                    <span className="text-sm font-semibold">({city.count})</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Hero Section */}
          <div className="relative h-64 bg-gradient-to-r from-gray-900 to-black border-b border-gray-800 overflow-hidden">
            <div 
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663163727382/ZaCeakJTUHAt8mssUX496t/IMG_2686_4893a4d6.png)',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            />
            
            <div className="relative z-10 h-full flex flex-col justify-between p-8">
              <div>
                <h2 className="text-5xl font-bold mb-2">{selectedCity}</h2>
                <p className="text-gray-400">Meets Global Style</p>
              </div>
              
              <div className="grid grid-cols-4 gap-4">
                <div className="bg-gray-800/50 backdrop-blur p-4 rounded-lg border border-gray-700">
                  <div className="text-2xl font-bold">{newOpenings}+</div>
                  <div className="text-sm text-gray-400">New Openings 2024-2026</div>
                </div>
                <div className="bg-gray-800/50 backdrop-blur p-4 rounded-lg border border-gray-700">
                  <div className="text-2xl font-bold">€1.200/m²</div>
                  <div className="text-sm text-gray-400">Avg. Rent</div>
                </div>
                <div className="bg-gray-800/50 backdrop-blur p-4 rounded-lg border border-gray-700">
                  <div className="text-2xl font-bold">&lt;0.5%</div>
                  <div className="text-sm text-gray-400">Vacancy Rate</div>
                </div>
                <div className="bg-gray-800/50 backdrop-blur p-4 rounded-lg border border-gray-700">
                  <div className="text-2xl font-bold">13.8 Mio.</div>
                  <div className="text-sm text-gray-400">Footfall/Year</div>
                </div>
              </div>
            </div>
          </div>

          {/* Content Area - Split */}
          <div className="flex-1 flex overflow-hidden">
            {/* Left: Map */}
            <div className="flex-1 border-r border-gray-800">
              {!loading && stores.length > 0 && (
                <MapView
                  onMapReady={(map) => {
                    // Map is ready
                  }}
                />
              )}
            </div>

            {/* Right: Key Openings List */}
            <div className="w-96 bg-gray-900 border-l border-gray-800 overflow-y-auto">
              <div className="p-6">
                <h3 className="text-xl font-bold mb-4">Key Openings {selectedCity}</h3>
                
                {/* Search */}
                <div className="mb-4 relative">
                  <Search className="absolute left-3 top-3 w-4 h-4 text-gray-500" />
                  <Input
                    placeholder="Search stores..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-500"
                  />
                </div>

                {/* Store List */}
                <div className="space-y-3">
                  {filteredStores.length === 0 ? (
                    <p className="text-gray-400 text-sm">No stores found</p>
                  ) : (
                    filteredStores.map((store) => (
                      <Card 
                        key={store.id}
                        className="bg-gray-800 border-gray-700 p-4 hover:bg-gray-700 transition cursor-pointer"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h4 className="font-semibold text-white">{store.brandName}</h4>
                            <p className="text-sm text-gray-400">{store.city}, {store.country}</p>
                          </div>
                          <span className="text-xs bg-blue-600 text-white px-2 py-1 rounded">
                            New
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                          <MapPin className="w-4 h-4" />
                          <span>{store.store_type || 'Retail'}</span>
                        </div>

                        {store.size_sqm && (
                          <div className="text-xs text-gray-500">
                            {store.size_sqm} sqm
                          </div>
                        )}

                        {store.opening_date && (
                          <div className="text-xs text-gray-500">
                            Opening: {new Date(store.opening_date).toLocaleDateString()}
                          </div>
                        )}
                      </Card>
                    ))
                  )}
                </div>

                <Button className="w-full mt-6 bg-blue-600 hover:bg-blue-700">
                  View All {filteredStores.length} Stores
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
    </div>
  );
}
