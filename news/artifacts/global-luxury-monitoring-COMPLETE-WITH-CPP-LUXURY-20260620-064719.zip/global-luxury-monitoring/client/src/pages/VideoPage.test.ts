import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import VideoPage from './VideoPage';

describe('VideoPage Component', () => {
  it('should render the video page with hero section', () => {
    render(<VideoPage />);
    
    const heading = screen.getByText('Global Luxury Monitoring');
    expect(heading).toBeInTheDocument();
  });

  it('should display the subtitle', () => {
    render(<VideoPage />);
    
    const subtitle = screen.getByText("Switzerland's Leading Retail Intelligence Platform");
    expect(subtitle).toBeInTheDocument();
  });

  it('should render the primary CTA button', () => {
    render(<VideoPage />);
    
    const button = screen.getByText('Vollständigen Bericht kaufen');
    expect(button).toBeInTheDocument();
  });

  it('should render the 14-day trial button', () => {
    render(<VideoPage />);
    
    const button = screen.getByText('14-Tage Trial starten');
    expect(button).toBeInTheDocument();
  });

  it('should display statistics section', () => {
    render(<VideoPage />);
    
    expect(screen.getByText('125+')).toBeInTheDocument();
    expect(screen.getByText('430+')).toBeInTheDocument();
    expect(screen.getByText('1,087')).toBeInTheDocument();
  });

  it('should display features section', () => {
    render(<VideoPage />);
    
    expect(screen.getByText('Warum Global Luxury Monitoring?')).toBeInTheDocument();
    expect(screen.getByText('Real-time Daten')).toBeInTheDocument();
    expect(screen.getByText('Globale Abdeckung')).toBeInTheDocument();
    expect(screen.getByText('Deep Dive Analyse')).toBeInTheDocument();
    expect(screen.getByText('Expert Insights')).toBeInTheDocument();
  });

  it('should render video element', () => {
    render(<VideoPage />);
    
    const video = screen.getByRole('img', { hidden: true }) || document.querySelector('video');
    expect(video).toBeInTheDocument();
  });

  it('should have play button initially visible', () => {
    const { container } = render(<VideoPage />);
    
    // Check if play button container exists
    const playButton = container.querySelector('button[class*="rounded-full"]');
    expect(playButton).toBeInTheDocument();
  });

  it('should display description text', () => {
    render(<VideoPage />);
    
    const description = screen.getByText(/Entdecken Sie die umfassendste Analyse/);
    expect(description).toBeInTheDocument();
  });

  it('should have proper button styling', () => {
    render(<VideoPage />);
    
    const primaryButton = screen.getByText('Vollständigen Bericht kaufen');
    expect(primaryButton).toHaveClass('bg-gradient-to-r');
    expect(primaryButton).toHaveClass('from-orange-500');
    expect(primaryButton).toHaveClass('to-pink-600');
  });

  it('should have proper trial button styling', () => {
    render(<VideoPage />);
    
    const trialButton = screen.getByText('14-Tage Trial starten');
    expect(trialButton).toHaveClass('border-2');
    expect(trialButton).toHaveClass('border-pink-500');
  });

  it('should display city statistics correctly', () => {
    render(<VideoPage />);
    
    expect(screen.getByText('Städte weltweit')).toBeInTheDocument();
    expect(screen.getByText('Premium Straßen')).toBeInTheDocument();
    expect(screen.getByText('Store Eröffnungen')).toBeInTheDocument();
  });

  it('should display feature descriptions', () => {
    render(<VideoPage />);
    
    expect(screen.getByText(/Tägliche Aktualisierung/)).toBeInTheDocument();
    expect(screen.getByText(/125\+ Städte in 60\+ Ländern/)).toBeInTheDocument();
    expect(screen.getByText(/Detaillierte Marktanalyse/)).toBeInTheDocument();
    expect(screen.getByText(/Professionelle Analysen/)).toBeInTheDocument();
  });
});
