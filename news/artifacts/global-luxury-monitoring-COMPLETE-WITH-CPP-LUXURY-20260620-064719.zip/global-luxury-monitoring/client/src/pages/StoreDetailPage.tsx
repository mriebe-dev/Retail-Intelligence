import React, { useState } from 'react';
import { useParams, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ChevronLeft, ChevronRight, MapPin, Clock, Ruler } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { PhotoGallery } from '../components/PhotoGallery';

/**
 * Store Detail Page with Photo Gallery
 * Displays comprehensive store information including photos, opening hours, and size
 */
export function StoreDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);

  // Fetch store data from tRPC
  const { data: response, isLoading, error } = trpc.places.getStoreById.useQuery(
    { id: id || '' },
    { enabled: !!id }
  );

  const store = response?.store;

  // Prepare photos for gallery
  const photos = store?.photoUrl
    ? [
        {
          url: store.photoUrl,
          title: `${store.brandName} - Storefront`,
          description: `${store.street}, ${store.city}, ${store.country}`,
          type: 'storefront' as const,
        },
      ]
    : [];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading store details...</p>
        </div>
      </div>
    );
  }

  if (error || !store) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Store Not Found</h1>
          <p className="text-muted-foreground mb-6">The store you're looking for doesn't exist.</p>
          <Button onClick={() => setLocation('/')}>Back to Home</Button>
        </div>
      </div>
    );
  }

  // Parse opening hours if available
  const openingHours = store.openingHours ? JSON.parse(store.openingHours) : null;

  // Handle photo gallery navigation
  const handlePreviousPhoto = () => {
    setCurrentPhotoIndex((prev) => (prev === 0 ? 0 : prev - 1));
  };

  const handleNextPhoto = () => {
    setCurrentPhotoIndex((prev) => (prev === 0 ? 0 : prev + 1));
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground py-8">
        <div className="container mx-auto px-4">
          <Button
            variant="ghost"
            className="text-primary-foreground hover:bg-primary/20 mb-4"
            onClick={() => setLocation('/')}
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <h1 className="text-4xl font-bold mb-2">{store.brandName}</h1>
          <p className="text-primary-foreground/80">
            {store.street}, {store.city}, {store.country}
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Photo Gallery */}
          <div className="lg:col-span-2">
            <Card className="overflow-hidden">
              {store.photoUrl ? (
                <div className="relative">
                  <img
                    src={store.photoUrl}
                    alt={`${store.brandName} store`}
                    className="w-full h-96 object-cover"
                  />
                  <div className="absolute inset-0 bg-black/0 hover:bg-black/10 transition-colors"></div>
                  
                  {/* Gallery Navigation */}
                  <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-white/80 hover:bg-white"
                      onClick={handlePreviousPhoto}
                      disabled={currentPhotoIndex === 0}
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <span className="text-sm font-medium text-white bg-black/50 px-3 py-1 rounded">
                      1 / 1
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-white/80 hover:bg-white"
                      onClick={handleNextPhoto}
                      disabled={true}
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="w-full h-96 bg-muted flex items-center justify-center">
                  <p className="text-muted-foreground">No photo available</p>
                </div>
              )}
            </Card>

            {/* Store Description */}
            <Card className="mt-8 p-6">
              <h2 className="text-2xl font-bold mb-4">About This Store</h2>
              <p className="text-foreground/80 leading-relaxed">
                {store.description || 'No description available for this store.'}
              </p>
              
              {/* Store Details Grid */}
              <div className="grid grid-cols-2 gap-6 mt-8">
                {store.squareMeters && (
                  <div className="flex items-start gap-3">
                    <Ruler className="w-5 h-5 text-primary mt-1" />
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Store Size</p>
                      <p className="text-lg font-semibold text-foreground">
                        {store.squareMeters.toLocaleString()} m²
                      </p>
                    </div>
                  </div>
                )}
                
                {store.date && (
                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-primary mt-1" />
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Opened</p>
                      <p className="text-lg font-semibold text-foreground">
                        {new Date(store.date).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* Sidebar Info */}
          <div className="lg:col-span-1">
            {/* Key Information */}
            <Card className="p-6 mb-6">
              <h3 className="text-lg font-bold mb-4">Store Information</h3>
              
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Category</p>
                  <p className="text-foreground font-semibold">{store.category}</p>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Status</p>
                  <div className="inline-block">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      store.status === 'new' ? 'bg-green-100 text-green-800' :
                      store.status === 'featured' ? 'bg-blue-100 text-blue-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {store.status.charAt(0).toUpperCase() + store.status.slice(1)}
                    </span>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Source</p>
                  <p className="text-foreground">{store.source}</p>
                </div>
              </div>
            </Card>

            {/* Opening Hours */}
            {openingHours && Object.keys(openingHours).length > 0 && (
              <Card className="p-6 mb-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Opening Hours
                </h3>
                
                <div className="space-y-2">
                  {Object.entries(openingHours).map(([day, hours]) => (
                    <div key={day} className="flex justify-between text-sm">
                      <span className="font-medium text-foreground">{day}</span>
                      <span className="text-muted-foreground">{hours as string}</span>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Location */}
            <Card className="p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Location
              </h3>
              
              <div className="space-y-2">
                <p className="text-foreground">
                  <span className="font-medium">{store.street}</span>
                </p>
                <p className="text-muted-foreground">
                  {store.city}, {store.country}
                </p>
                
                {store?.latitude && store?.longitude && (
                  <p className="text-xs text-muted-foreground pt-2 border-t">
                    Coordinates: {store.latitude}, {store.longitude}
                  </p>
                )}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
