import { describe, it, expect, vi, beforeEach } from "vitest";

describe("CityPageLayout Street Organization", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should group stores by street correctly", () => {
    const newsData = {
      city: "Zürich",
      country: "Switzerland",
      totalNews: 3,
      byStreet: [
        {
          street: "Bahnhofstrasse",
          count: 2,
          brands: ["Chanel", "Gucci"],
        },
        {
          street: "Rennweg",
          count: 1,
          brands: ["Zimmermann"],
        },
      ],
    };

    // Simulate grouping logic
    const grouped: Record<string, string[]> = {};
    newsData.byStreet.forEach((streetData) => {
      grouped[streetData.street] = streetData.brands;
    });

    expect(Object.keys(grouped)).toContain("Bahnhofstrasse");
    expect(Object.keys(grouped)).toContain("Rennweg");
    expect(grouped["Bahnhofstrasse"]).toHaveLength(2);
    expect(grouped["Rennweg"]).toHaveLength(1);
  });

  it("should sort main street first", () => {
    const mainStreet = "Bahnhofstrasse";
    const streets = ["Rennweg", "Bahnhofstrasse", "Augustinergasse"];

    const sorted = [
      mainStreet,
      ...streets.filter((s) => s !== mainStreet).sort(),
    ];

    expect(sorted[0]).toBe("Bahnhofstrasse");
    expect(sorted[1]).toBe("Augustinergasse");
    expect(sorted[2]).toBe("Rennweg");
  });

  it("should filter stores by year correctly", () => {
    const stores = [
      {
        id: "1",
        brand: "Chanel",
        openingDate: "2025-05-15",
        category: "fashion",
      },
      {
        id: "2",
        brand: "Gucci",
        openingDate: "2024-03-20",
        category: "fashion",
      },
      {
        id: "3",
        brand: "Rolex",
        openingDate: "2026-01-10",
        category: "watches",
      },
    ];

    const filtered2025 = stores.filter((store) => {
      const year = new Date(store.openingDate).getFullYear().toString();
      return year === "2025";
    });

    expect(filtered2025).toHaveLength(1);
    expect(filtered2025[0].brand).toBe("Chanel");
  });

  it("should filter stores by category correctly", () => {
    const stores = [
      { id: "1", brand: "Chanel", category: "fashion" },
      { id: "2", brand: "Gucci", category: "fashion" },
      { id: "3", brand: "Rolex", category: "watches" },
    ];

    const filteredFashion = stores.filter((store) => store.category === "fashion");

    expect(filteredFashion).toHaveLength(2);
    expect(filteredFashion.every((s) => s.category === "fashion")).toBe(true);
  });

  it("should handle empty street groups", () => {
    const newsData = {
      city: "Zürich",
      country: "Switzerland",
      totalNews: 0,
      byStreet: [],
    };

    const grouped: Record<string, string[]> = {};
    newsData.byStreet.forEach((streetData: any) => {
      grouped[streetData.street] = streetData.brands;
    });

    expect(Object.keys(grouped)).toHaveLength(0);
  });

  it("should maintain store metadata correctly", () => {
    const store = {
      id: "1",
      name: "Chanel Flagship",
      street: "Bahnhofstrasse",
      address: "Bahnhofstrasse 52",
      city: "Zürich",
      brand: "Chanel",
      category: "fashion",
      openingDate: "2026-05-15",
      size: "600 m²",
      status: "new" as const,
      description: "New flagship store",
    };

    expect(store.brand).toBe("Chanel");
    expect(store.street).toBe("Bahnhofstrasse");
    expect(store.status).toBe("new");
    expect(store.size).toBe("600 m²");
  });

  it("should expand and collapse streets", () => {
    const expandedStreets = new Set<string>();
    const mainStreet = "Bahnhofstrasse";

    // Initially expanded
    expandedStreets.add(mainStreet);
    expect(expandedStreets.has(mainStreet)).toBe(true);

    // Toggle collapse
    expandedStreets.delete(mainStreet);
    expect(expandedStreets.has(mainStreet)).toBe(false);

    // Toggle expand
    expandedStreets.add(mainStreet);
    expect(expandedStreets.has(mainStreet)).toBe(true);
  });

  it("should display correct city statistics", () => {
    const cityStats = {
      zurich: {
        newOpenings: 33,
        flagshipStores: 12,
        avgRent: "CHF 13'000/m²",
        vacancyRate: "<0.5%",
        footfall: "13.8 Mio.",
      },
    };

    const stats = cityStats.zurich;
    expect(stats.newOpenings).toBe(33);
    expect(stats.flagshipStores).toBe(12);
    expect(stats.avgRent).toContain("CHF");
    expect(stats.vacancyRate).toContain("<");
  });
});
