import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { ArrowLeft, MapPin } from "lucide-react";
import { trpc } from "@/lib/trpc";

const GLOBAL_LOCATIONS = [
  { name: "Paris", slug: "paris", country: "France", description: "Champs-Élysées & Rue Saint-Honoré" },
  { name: "London", slug: "london", country: "United Kingdom", description: "Bond Street & Sloane Street" },
  { name: "New York", slug: "new-york", country: "United States", description: "Fifth Avenue & Madison Avenue" },
  { name: "Milan", slug: "milan", country: "Italy", description: "Via Montenapoleone & Quadrilatero d'Oro" },
  { name: "Tokyo", slug: "tokyo", country: "Japan", description: "Ginza & Shibuya" },
  { name: "Hong Kong", slug: "hong-kong", country: "Hong Kong", description: "Central & Causeway Bay" },
];

export default function GlobalPage() {
  const [selectedLocation, setSelectedLocation] = useState<string | null>(null);
  const { data: stores, isLoading } = trpc.luxury.list.useQuery(
    selectedLocation ? { city: selectedLocation } : {},
    { enabled: !!selectedLocation }
  );

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-3xl font-bold text-slate-900">Global Markets</h1>
                <p className="text-sm text-slate-600">Worldwide luxury retail locations</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {!selectedLocation ? (
          <>
            {/* Locations Grid */}
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-slate-900 mb-8">Select a Location</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {GLOBAL_LOCATIONS.map((location) => (
                  <Card
                    key={location.slug}
                    className="hover:shadow-lg transition-all cursor-pointer"
                    onClick={() => setSelectedLocation(location.name)}
                  >
                    <CardHeader className="pb-3">
                      <CardTitle className="flex items-center gap-2">
                        <MapPin className="w-5 h-5 text-blue-600" />
                        {location.name}
                      </CardTitle>
                      <CardDescription>
                        <div>{location.country}</div>
                        <div className="text-xs mt-1">{location.description}</div>
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button variant="outline" className="w-full">
                        View Locations →
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </>
        ) : (
          <>
            {/* Location Detail View */}
            <div className="mb-8">
              <Button
                variant="outline"
                onClick={() => setSelectedLocation(null)}
                className="mb-4"
              >
                ← Back to Locations
              </Button>
              <h2 className="text-3xl font-bold text-slate-900">{selectedLocation}</h2>
              <p className="text-slate-600 mt-2">
                Luxury retail locations and market activity
              </p>
            </div>

            {/* Stores List */}
            {isLoading ? (
              <div className="text-center py-12">
                <p className="text-slate-600">Loading locations...</p>
              </div>
            ) : stores && stores.length > 0 ? (
              <div className="grid grid-cols-1 gap-4">
                {stores.map((store) => (
                  <Card key={store.id} className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{store.brandName}</CardTitle>
                          <CardDescription>{store.locationAddress}</CardDescription>
                        </div>
                        <span className="text-xs bg-blue-100 text-blue-800 px-3 py-1 rounded-full">
                          {store.newsType}
                        </span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-slate-700 mb-4">{store.summary}</p>
                      <div className="flex justify-between items-center text-xs text-slate-500">
                        <span>{store.date}</span>
                        {store.sourceUrl && (
                          <a
                            href={store.sourceUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline"
                          >
                            View Source →
                          </a>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p className="text-slate-600">No locations found for {selectedLocation}</p>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </div>
  );
}
