import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Download, TrendingUp } from "lucide-react";

export default function NewsAnalytics() {
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [selectedCity, setSelectedCity] = useState<string | null>(null);

  // Fetch news statistics
  const { data: stats, isLoading: statsLoading } = trpc.news.statistics.useQuery();
  
  // Fetch top streets for selected city
  const { data: topStreets, isLoading: streetsLoading } = trpc.news.topStreets.useQuery(
    { city: selectedCity || "", limit: 20 },
    { enabled: !!selectedCity }
  );

  // Fetch news by city
  const { data: cityNews, isLoading: cityNewsLoading } = trpc.news.getByCity.useQuery(
    { city: selectedCity || "", country: selectedCountry || undefined },
    { enabled: !!selectedCity }
  );

  if (statsLoading) {
    return (
      <div className="min-h-screen bg-slate-50 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">Loading statistics...</div>
        </div>
      </div>
    );
  }

  const countries = stats?.countries ? Object.keys(stats.countries).sort() : [];
  const cities = selectedCountry && stats?.countries[selectedCountry] 
    ? Object.keys(stats.countries[selectedCountry]).sort() 
    : [];

  // Prepare data for country chart
  const countryData = countries.map(country => ({
    name: country,
    news: stats?.countries[country] 
      ? Object.values(stats.countries[country]).reduce((sum, city) => sum + (city.count || 0), 0)
      : 0,
  })).sort((a, b) => b.news - a.news).slice(0, 15);

  // Prepare data for city chart
  const cityData = selectedCountry && stats?.countries[selectedCountry]
    ? Object.entries(stats.countries[selectedCountry])
        .map(([city, data]) => ({
          name: city,
          news: data.count || 0,
          streets: data.streets || 0,
        }))
        .sort((a, b) => b.news - a.news)
    : [];

  // Prepare data for street chart
  const streetData = topStreets?.map(street => ({
    name: street.street,
    news: street.count,
    brands: street.brands.length,
  })) || [];

  const COLORS = [
    "#ec4899", "#f43f5e", "#f97316", "#eab308", 
    "#84cc16", "#22c55e", "#10b981", "#14b8a6",
    "#06b6d4", "#0ea5e9", "#3b82f6", "#6366f1",
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-600 to-pink-500 sticky top-0 z-50 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="text-3xl font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-8 h-8" />
            News Analytics Dashboard
          </h1>
          <p className="text-white/80 mt-2">Global luxury retail store opening statistics</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Total News</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-pink-600">{stats?.totalNews || 0}</div>
              <p className="text-xs text-slate-500 mt-1">Store openings worldwide</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Countries</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{countries.length}</div>
              <p className="text-xs text-slate-500 mt-1">Covered regions</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Cities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {stats?.countries ? Object.values(stats.countries).reduce((sum, country) => sum + Object.keys(country).length, 0) : 0}
              </div>
              <p className="text-xs text-slate-500 mt-1">Premium locations</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Selected City</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-amber-600">{cityNews?.totalNews || 0}</div>
              <p className="text-xs text-slate-500 mt-1">{selectedCity || "None"}</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Top Countries Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Top Countries by News Count</CardTitle>
            </CardHeader>
            <CardContent>
              {countryData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={countryData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="news" fill="#ec4899" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center py-8 text-slate-500">No data available</div>
              )}
            </CardContent>
          </Card>

          {/* Country Distribution Pie */}
          <Card>
            <CardHeader>
              <CardTitle>News Distribution by Country</CardTitle>
            </CardHeader>
            <CardContent>
              {countryData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={countryData.slice(0, 8)}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, news }) => `${name}: ${news}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="news"
                    >
                      {countryData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center py-8 text-slate-500">No data available</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Country and City Selection */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Country Selector */}
          <Card>
            <CardHeader>
              <CardTitle>Select Country</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2 max-h-96 overflow-y-auto">
                {countries.map(country => (
                  <Button
                    key={country}
                    variant={selectedCountry === country ? "default" : "outline"}
                    className={`justify-start text-left ${
                      selectedCountry === country ? "bg-pink-600 hover:bg-pink-700" : ""
                    }`}
                    onClick={() => {
                      setSelectedCountry(country);
                      setSelectedCity(null);
                    }}
                  >
                    {country}
                    {stats?.countries[country] && (
                      <span className="ml-auto text-xs">
                        {Object.values(stats.countries[country]).reduce((sum, city) => sum + (city.count || 0), 0)}
                      </span>
                    )}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* City Selector */}
          <Card>
            <CardHeader>
              <CardTitle>Select City</CardTitle>
            </CardHeader>
            <CardContent>
              {selectedCountry ? (
                <div className="grid grid-cols-1 gap-2 max-h-96 overflow-y-auto">
                  {cities.map(city => (
                    <Button
                      key={city}
                      variant={selectedCity === city ? "default" : "outline"}
                      className={`justify-between text-left ${
                        selectedCity === city ? "bg-pink-600 hover:bg-pink-700" : ""
                      }`}
                      onClick={() => setSelectedCity(city)}
                    >
                      <span>{city}</span>
                      <span className="text-xs">
                        {stats?.countries[selectedCountry]?.[city]?.count || 0}
                      </span>
                    </Button>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500">Select a country first</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* City Details */}
        {selectedCity && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top Streets Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Top Streets in {selectedCity}</CardTitle>
              </CardHeader>
              <CardContent>
                {streetsLoading ? (
                  <div className="text-center py-8 text-slate-500">Loading streets...</div>
                ) : streetData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={streetData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="news" fill="#ec4899" name="News Count" />
                      <Bar dataKey="brands" fill="#f97316" name="Unique Brands" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="text-center py-8 text-slate-500">No street data available</div>
                )}
              </CardContent>
            </Card>

            {/* City Summary */}
            <Card>
              <CardHeader>
                <CardTitle>{selectedCity} Summary</CardTitle>
              </CardHeader>
              <CardContent>
                {cityNewsLoading ? (
                  <div className="text-center py-8 text-slate-500">Loading...</div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm text-slate-600">Total News Items</p>
                      <p className="text-2xl font-bold text-pink-600">{cityNews?.totalNews || 0}</p>
                    </div>
                    <div>
                      <p className="text-sm text-slate-600">Premium Streets</p>
                      <p className="text-2xl font-bold text-blue-600">{cityNews?.byStreet.length || 0}</p>
                    </div>
                    <div>
                      <p className="text-sm text-slate-600">Top Street</p>
                      <p className="text-lg font-semibold text-slate-900">
                        {cityNews?.byStreet[0]?.street || "N/A"}
                      </p>
                      <p className="text-sm text-slate-600">
                        {cityNews?.byStreet[0]?.count || 0} openings
                      </p>
                    </div>
                    <Button className="w-full bg-pink-600 hover:bg-pink-700">
                      <Download className="w-4 h-4 mr-2" />
                      Export Report
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
