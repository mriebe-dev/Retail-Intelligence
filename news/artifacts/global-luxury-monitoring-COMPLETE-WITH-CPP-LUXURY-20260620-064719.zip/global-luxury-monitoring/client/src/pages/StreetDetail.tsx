import React, { useState } from 'react';
import { useRoute, useLocation } from 'wouter';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { TrendingUp, Users, AlertCircle, MapPin, Calendar } from 'lucide-react';

interface Street {
  id: string;
  name: string;
  city: string;
  country: string;
  stores: number;
  peakRent: string;
  vacancyRate: string;
  footfall: string;
  description: string;
}

interface StoreCard {
  id: string;
  name: string;
  brand: string;
  address: string;
  size: number;
  openingDate: string;
  category: string;
  image?: string;
  status: 'new' | 'flagship' | 'premium';
}

// Sample data - will be replaced with database queries
const STREETS_DATA: Record<string, Street> = {
  'bahnhofstrasse-zurich': {
    id: 'bahnhofstrasse-zurich',
    name: 'Bahnhofstrasse',
    city: 'Zürich',
    country: 'Switzerland',
    stores: 28,
    peakRent: 'CHF 13\'000/m²',
    vacancyRate: '<0.5%',
    footfall: '13.8 Mio.',
    description: 'Switzerland\'s most prestigious shopping street. Home to world-leading luxury brands and flagship stores.',
  },
  'rennweg-zurich': {
    id: 'rennweg-zurich',
    name: 'Rennweg',
    city: 'Zürich',
    country: 'Switzerland',
    stores: 12,
    peakRent: 'CHF 8\'500/m²',
    vacancyRate: '1.2%',
    footfall: '8.2 Mio.',
    description: 'Premium shopping destination with boutique brands and exclusive retailers.',
  },
  'via-frattina-roma': {
    id: 'via-frattina-roma',
    name: 'Via Frattina',
    city: 'Roma',
    country: 'Italy',
    stores: 18,
    peakRent: '€ 9\'200/m²',
    vacancyRate: '0.8%',
    footfall: '9.5 Mio.',
    description: 'One of Rome\'s most iconic luxury shopping streets in the historic center.',
  },
};

const STORES_SAMPLE: StoreCard[] = [
  {
    id: '1',
    name: 'Chanel',
    brand: 'Chanel',
    address: 'Bahnhofstrasse 52',
    size: 600,
    openingDate: 'Frühjahr/Sommer 2026',
    category: 'Luxury Fashion',
    status: 'flagship',
  },
  {
    id: '2',
    name: 'Van Cleef & Arpels',
    brand: 'Van Cleef & Arpels',
    address: 'Bahnhofstrasse 11',
    size: 268,
    openingDate: 'Mai 2025',
    category: 'Jewelry',
    status: 'new',
  },
  {
    id: '3',
    name: 'Messika',
    brand: 'Messika',
    address: 'Bahnhofstrasse 37',
    size: 120,
    openingDate: 'Januar 2026',
    category: 'Jewelry',
    status: 'new',
  },
  {
    id: '4',
    name: 'Tiffany & Co.',
    brand: 'Tiffany & Co.',
    address: 'Bahnhofstrasse 39',
    size: 746,
    openingDate: 'Mai 2024',
    category: 'Jewelry',
    status: 'flagship',
  },
  {
    id: '5',
    name: 'Gucci',
    brand: 'Gucci',
    address: 'Bahnhofstrasse 44',
    size: 80,
    openingDate: '2013/2020',
    category: 'Luxury Fashion',
    status: 'premium',
  },
  {
    id: '6',
    name: 'Balenciaga',
    brand: 'Balenciaga',
    address: 'Bahnhofstrasse 54',
    size: 300,
    openingDate: '4. Dezember 2025',
    category: 'Luxury Fashion',
    status: 'new',
  },
];

export default function StreetDetail() {
  const [location] = useLocation();
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Extract city and street from URL or use defaults
  const pathParts = location.split('/').filter(Boolean);
  const city = pathParts[2] || 'zurich';
  const street = pathParts[3] || 'bahnhofstrasse';

  const streetId = `${street}-${city}`;
  const streetData = STREETS_DATA[streetId] || STREETS_DATA['bahnhofstrasse-zurich'];

  const filteredStores = STORES_SAMPLE.filter(store => {
    const categoryMatch = filterCategory === 'all' || store.category === filterCategory;
    const statusMatch = filterStatus === 'all' || store.status === filterStatus;
    return categoryMatch && statusMatch;
  });

  const categories = ['all', ...Array.from(new Set(STORES_SAMPLE.map(s => s.category)))];
  const statuses = ['all', 'new', 'flagship', 'premium'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100">
      {/* Hero Section */}
      <div className="relative overflow-hidden py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-purple-600 to-pink-600">
        <div className="max-w-7xl mx-auto">
          <div className="text-white mb-8">
            <h1 className="text-5xl font-bold mb-2">{streetData.name}</h1>
            <p className="text-xl text-white/90">{streetData.city}, {streetData.country}</p>
            <p className="text-white/80 mt-3 max-w-2xl">{streetData.description}</p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-white/95 backdrop-blur border-0 p-6 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-gray-600">ACTIVE STORES</span>
                <MapPin className="w-5 h-5 text-purple-600" />
              </div>
              <div className="text-3xl font-bold text-purple-600">{streetData.stores}</div>
              <div className="text-sm text-gray-600">Luxury Retailers</div>
            </Card>

            <Card className="bg-white/95 backdrop-blur border-0 p-6 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-gray-600">PEAK RENT</span>
                <TrendingUp className="w-5 h-5 text-purple-600" />
              </div>
              <div className="text-3xl font-bold text-purple-600">{streetData.peakRent}</div>
              <div className="text-sm text-gray-600">Per Square Meter</div>
            </Card>

            <Card className="bg-white/95 backdrop-blur border-0 p-6 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-gray-600">VACANCY RATE</span>
                <AlertCircle className="w-5 h-5 text-purple-600" />
              </div>
              <div className="text-3xl font-bold text-purple-600">{streetData.vacancyRate}</div>
              <div className="text-sm text-gray-600">Available Space</div>
            </Card>

            <Card className="bg-white/95 backdrop-blur border-0 p-6 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-gray-600">FOOTFALL</span>
                <Users className="w-5 h-5 text-purple-600" />
              </div>
              <div className="text-3xl font-bold text-purple-600">{streetData.footfall}</div>
              <div className="text-sm text-gray-600">Annual Visitors</div>
            </Card>
          </div>
        </div>
      </div>

      {/* Filters Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white/90 backdrop-blur border border-purple-200 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Filter Stores</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Category Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">Category</label>
              <div className="flex flex-wrap gap-2">
                {categories.map(cat => (
                  <Button
                    key={cat}
                    onClick={() => setFilterCategory(cat)}
                    variant={filterCategory === cat ? 'default' : 'outline'}
                    className={filterCategory === cat ? 'bg-purple-600 hover:bg-purple-700' : ''}
                  >
                    {cat === 'all' ? 'All Categories' : cat}
                  </Button>
                ))}
              </div>
            </div>

            {/* Status Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">Status</label>
              <div className="flex flex-wrap gap-2">
                {statuses.map(status => (
                  <Button
                    key={status}
                    onClick={() => setFilterStatus(status)}
                    variant={filterStatus === status ? 'default' : 'outline'}
                    className={filterStatus === status ? 'bg-purple-600 hover:bg-purple-700' : ''}
                  >
                    {status === 'all' ? 'All Status' : status.charAt(0).toUpperCase() + status.slice(1)}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stores Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">
          {filteredStores.length} Store{filteredStores.length !== 1 ? 's' : ''} on {streetData.name}
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredStores.map(store => (
            <a
              key={store.id}
              href={`/store/${store.id}`}
              className="group"
            >
              <Card className="h-full bg-white/90 backdrop-blur border-2 border-purple-200 hover:border-purple-400 hover:shadow-xl transition-all duration-300 overflow-hidden">
                {/* Store Header */}
                <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-6 text-white">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="text-xl font-bold">{store.name}</h3>
                      <p className="text-sm text-white/90">{store.brand}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      store.status === 'flagship' ? 'bg-yellow-400 text-yellow-900' :
                      store.status === 'new' ? 'bg-green-400 text-green-900' :
                      'bg-blue-400 text-blue-900'
                    }`}>
                      {store.status.charAt(0).toUpperCase() + store.status.slice(1)}
                    </span>
                  </div>
                </div>

                {/* Store Details */}
                <div className="p-6 space-y-4">
                  <div className="space-y-2 border-b border-purple-200 pb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="w-4 h-4 mr-2 text-purple-600" />
                      {store.address}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Calendar className="w-4 h-4 mr-2 text-purple-600" />
                      {store.openingDate}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-purple-50 p-3 rounded-lg">
                      <div className="text-xs font-semibold text-gray-600 mb-1">Size</div>
                      <div className="text-lg font-bold text-purple-600">{store.size} m²</div>
                    </div>
                    <div className="bg-purple-50 p-3 rounded-lg">
                      <div className="text-xs font-semibold text-gray-600 mb-1">Category</div>
                      <div className="text-lg font-bold text-purple-600 text-xs">{store.category}</div>
                    </div>
                  </div>

                  <Button className="w-full mt-4 bg-purple-600 hover:bg-purple-700 text-white group-hover:shadow-lg transition-all">
                    View Details →
                  </Button>
                </div>
              </Card>
            </a>
          ))}
        </div>

        {filteredStores.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">No stores found matching your filters.</p>
          </div>
        )}
      </div>
    </div>
  );
}
