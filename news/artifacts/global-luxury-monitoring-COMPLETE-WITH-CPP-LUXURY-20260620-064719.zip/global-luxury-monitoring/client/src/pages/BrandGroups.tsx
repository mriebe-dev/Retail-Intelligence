import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

// Brand group taxonomy
const BRAND_TAXONOMY = [
  {
    group: "LVMH",
    fullName: "LVMH Moët Hennessy Louis Vuitton",
    color: "from-amber-900 to-amber-700",
    accent: "amber",
    logo: "🏆",
    brands: [
      { name: "Louis Vuitton", category: "Fashion/Leather" },
      { name: "Dior", category: "Fashion/Couture" },
      { name: "Fendi", category: "Fashion/Leather" },
      { name: "Celine", category: "Fashion/Leather" },
      { name: "Givenchy", category: "Fashion/Couture" },
      { name: "Loewe", category: "Fashion/Leather" },
      { name: "Marc Jacobs", category: "Fashion" },
      { name: "Kenzo", category: "Fashion" },
      { name: "Berluti", category: "Shoes/Leather" },
      { name: "Loro Piana", category: "Fashion/Cashmere" },
      { name: "Rimowa", category: "Luggage" },
      { name: "Bulgari", category: "Jewelry/Watches" },
      { name: "TAG Heuer", category: "Watches" },
      { name: "Hublot", category: "Watches" },
      { name: "Zenith", category: "Watches" },
      { name: "Chaumet", category: "Jewelry" },
      { name: "Guerlain", category: "Beauty/Perfume" },
      { name: "Acqua di Parma", category: "Beauty/Perfume" },
      { name: "Sephora", category: "Beauty Retail" },
    ],
  },
  {
    group: "Kering",
    fullName: "Kering S.A.",
    color: "from-red-900 to-red-700",
    accent: "red",
    logo: "👑",
    brands: [
      { name: "Gucci", category: "Fashion/Leather" },
      { name: "Saint Laurent", category: "Fashion/Couture" },
      { name: "Bottega Veneta", category: "Fashion/Leather" },
      { name: "Balenciaga", category: "Fashion" },
      { name: "Alexander McQueen", category: "Fashion/Couture" },
      { name: "Brioni", category: "Fashion/Menswear" },
      { name: "Boucheron", category: "Jewelry" },
      { name: "Pomellato", category: "Jewelry" },
      { name: "Qeelin", category: "Jewelry" },
      { name: "Valentino", category: "Fashion/Couture" },
    ],
  },
  {
    group: "Richemont",
    fullName: "Compagnie Financière Richemont",
    color: "from-slate-800 to-slate-600",
    accent: "slate",
    logo: "💎",
    brands: [
      { name: "Cartier", category: "Jewelry/Watches" },
      { name: "Van Cleef & Arpels", category: "Jewelry" },
      { name: "Piaget", category: "Jewelry/Watches" },
      { name: "Vacheron Constantin", category: "Watches" },
      { name: "IWC", category: "Watches" },
      { name: "Jaeger-LeCoultre", category: "Watches" },
      { name: "Panerai", category: "Watches" },
      { name: "Roger Dubuis", category: "Watches" },
      { name: "Baume & Mercier", category: "Watches" },
      { name: "Montblanc", category: "Writing/Leather" },
      { name: "Dunhill", category: "Fashion/Accessories" },
      { name: "Chloé", category: "Fashion" },
      { name: "Alaïa", category: "Fashion/Couture" },
    ],
  },
  {
    group: "Swatch Group",
    fullName: "The Swatch Group Ltd.",
    color: "from-blue-900 to-blue-700",
    accent: "blue",
    logo: "⌚",
    brands: [
      { name: "Omega", category: "Watches" },
      { name: "Longines", category: "Watches" },
      { name: "Tissot", category: "Watches" },
      { name: "Rado", category: "Watches" },
      { name: "Hamilton", category: "Watches" },
      { name: "Swatch", category: "Watches" },
      { name: "Breguet", category: "Watches" },
      { name: "Blancpain", category: "Watches" },
      { name: "Harry Winston", category: "Jewelry/Watches" },
    ],
  },
  {
    group: "Hermès",
    fullName: "Hermès International S.A.",
    color: "from-orange-800 to-orange-600",
    accent: "orange",
    logo: "🐴",
    brands: [
      { name: "Hermès", category: "Fashion/Leather/Silk" },
      { name: "John Lobb", category: "Shoes" },
    ],
  },
  {
    group: "Chanel",
    fullName: "Chanel S.A.",
    color: "from-neutral-900 to-neutral-700",
    accent: "neutral",
    logo: "⚜️",
    brands: [
      { name: "Chanel", category: "Fashion/Couture/Beauty" },
      { name: "Eres", category: "Swimwear" },
    ],
  },
  {
    group: "Tapestry",
    fullName: "Tapestry, Inc.",
    color: "from-emerald-800 to-emerald-600",
    accent: "emerald",
    logo: "👜",
    brands: [
      { name: "Coach", category: "Fashion/Leather" },
      { name: "Kate Spade", category: "Fashion/Accessories" },
      { name: "Stuart Weitzman", category: "Shoes" },
    ],
  },
  {
    group: "Capri Holdings",
    fullName: "Capri Holdings Limited",
    color: "from-purple-900 to-purple-700",
    accent: "purple",
    logo: "✨",
    brands: [
      { name: "Versace", category: "Fashion/Couture" },
      { name: "Jimmy Choo", category: "Shoes" },
      { name: "Michael Kors", category: "Fashion/Accessories" },
    ],
  },
  {
    group: "H&M Group",
    fullName: "H & M Hennes & Mauritz AB",
    color: "from-rose-800 to-rose-600",
    accent: "rose",
    logo: "🛍️",
    brands: [
      { name: "H&M", category: "Fashion" },
      { name: "COS", category: "Fashion" },
      { name: "Arket", category: "Fashion/Lifestyle" },
      { name: "Weekday", category: "Fashion" },
      { name: "& Other Stories", category: "Fashion" },
      { name: "Monki", category: "Fashion" },
    ],
  },
  {
    group: "Inditex",
    fullName: "Industria de Diseño Textil, S.A.",
    color: "from-indigo-900 to-indigo-700",
    accent: "indigo",
    logo: "🌐",
    brands: [
      { name: "Zara", category: "Fashion" },
      { name: "Massimo Dutti", category: "Fashion" },
      { name: "Pull&Bear", category: "Fashion" },
      { name: "Bershka", category: "Fashion" },
      { name: "Stradivarius", category: "Fashion" },
      { name: "Oysho", category: "Sportswear" },
      { name: "Zara Home", category: "Home" },
    ],
  },
  {
    group: "Independent Luxury",
    fullName: "Independent Luxury Houses",
    color: "from-violet-900 to-violet-700",
    accent: "violet",
    logo: "🏛️",
    brands: [
      { name: "Prada", category: "Fashion/Leather" },
      { name: "Miu Miu", category: "Fashion" },
      { name: "Burberry", category: "Fashion" },
      { name: "Ralph Lauren", category: "Fashion/Lifestyle" },
      { name: "Tiffany & Co", category: "Jewelry" },
      { name: "Rolex", category: "Watches" },
      { name: "Chopard", category: "Jewelry/Watches" },
      { name: "De Beers", category: "Jewelry" },
      { name: "Graff", category: "Jewelry" },
      { name: "Messika", category: "Jewelry" },
      { name: "Dolce & Gabbana", category: "Fashion/Couture" },
      { name: "Giorgio Armani", category: "Fashion/Couture" },
      { name: "Max Mara", category: "Fashion" },
      { name: "Moncler", category: "Fashion/Outerwear" },
      { name: "Brunello Cucinelli", category: "Fashion/Cashmere" },
      { name: "Zegna", category: "Fashion/Menswear" },
      { name: "Boglioli", category: "Fashion/Menswear" },
      { name: "Hackett", category: "Fashion/Menswear" },
      { name: "Issey Miyake", category: "Fashion" },
      { name: "Jacquemus", category: "Fashion" },
      { name: "Acne Studios", category: "Fashion" },
      { name: "SKIMS", category: "Shapewear" },
      { name: "On", category: "Sports/Running" },
      { name: "New Balance", category: "Sports/Lifestyle" },
      { name: "Sporty & Rich", category: "Wellness/Lifestyle" },
    ],
  },
];

export default function BrandGroups() {
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: newsData } = trpc.news.list.useQuery({});
  const allNews = newsData || [];

  const getNewsCountForBrand = (brandName: string) => {
    return allNews.filter(n =>
      n.brandName?.toLowerCase().includes(brandName.toLowerCase()) ||
      brandName.toLowerCase().includes(n.brandName?.toLowerCase() || '')
    ).length;
  };

  const getNewsCountForGroup = (brands: { name: string }[]) => {
    return brands.reduce((sum, b) => sum + getNewsCountForBrand(b.name), 0);
  };

  const filteredTaxonomy = BRAND_TAXONOMY.filter(g => {
    if (selectedGroup && g.group !== selectedGroup) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return g.group.toLowerCase().includes(q) ||
             g.brands.some(b => b.name.toLowerCase().includes(q));
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Hero */}
      <div className="relative bg-gradient-to-br from-violet-950 via-purple-900 to-indigo-950 py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-4">
            <span className="text-xs font-semibold tracking-widest text-purple-300 uppercase">
              Global Luxury Monitoring
            </span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Brand Intelligence
          </h1>
          <p className="text-lg text-purple-200 mb-8 max-w-2xl">
            Complete brand hierarchy — from luxury conglomerates to independent houses.
            Track store openings, expansions, and market presence by brand group.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Brand Groups", value: BRAND_TAXONOMY.length.toString() },
              { label: "Total Brands", value: BRAND_TAXONOMY.reduce((s, g) => s + g.brands.length, 0).toString() },
              { label: "Store Openings", value: allNews.length.toLocaleString() },
              { label: "Coverage", value: "2016–2026" },
            ].map(m => (
              <div key={m.label} className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                <div className="text-2xl font-bold text-white">{m.value}</div>
                <div className="text-sm text-purple-300">{m.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="bg-gray-900 border-b border-gray-800 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-wrap gap-3 items-center">
          <input
            type="text"
            placeholder="Search brand or group..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="flex-1 min-w-48 bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-sm text-white placeholder-gray-400 focus:outline-none focus:border-purple-500"
          />
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedGroup(null)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                !selectedGroup ? 'bg-purple-600 text-white' : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              All Groups
            </button>
            {BRAND_TAXONOMY.map(g => (
              <button
                key={g.group}
                onClick={() => setSelectedGroup(selectedGroup === g.group ? null : g.group)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  selectedGroup === g.group ? 'bg-purple-600 text-white' : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                {g.logo} {g.group}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Brand Groups */}
      <div className="max-w-7xl mx-auto px-6 py-10 space-y-8">
        {filteredTaxonomy.map(group => {
          const newsCount = getNewsCountForGroup(group.brands);
          return (
            <div key={group.group} className="bg-gray-900 rounded-2xl overflow-hidden border border-gray-800">
              {/* Group Header */}
              <div className={`bg-gradient-to-r ${group.color} p-6`}>
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <span className="text-2xl">{group.logo}</span>
                      <h2 className="text-2xl font-bold text-white">{group.group}</h2>
                    </div>
                    <p className="text-white/70 text-sm">{group.fullName}</p>
                  </div>
                  <div className="flex gap-4">
                    <div className="text-center">
                      <div className="text-xl font-bold text-white">{group.brands.length}</div>
                      <div className="text-xs text-white/60">Brands</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xl font-bold text-white">{newsCount}</div>
                      <div className="text-xs text-white/60">Openings</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Brands Grid */}
              <div className="p-6">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                  {group.brands
                    .filter(b => !searchQuery || b.name.toLowerCase().includes(searchQuery.toLowerCase()))
                    .map(brand => {
                      const count = getNewsCountForBrand(brand.name);
                      return (
                        <Link
                          key={brand.name}
                          href={`/brands/${encodeURIComponent(brand.name)}`}
                          className="group bg-gray-800 hover:bg-gray-750 border border-gray-700 hover:border-purple-500 rounded-xl p-4 transition-all cursor-pointer"
                        >
                          <div className="font-semibold text-white text-sm group-hover:text-purple-300 transition-colors mb-1">
                            {brand.name}
                          </div>
                          <div className="text-xs text-gray-400 mb-2">{brand.category}</div>
                          {count > 0 && (
                            <div className="inline-flex items-center gap-1 bg-purple-900/50 text-purple-300 text-xs px-2 py-0.5 rounded-full">
                              <span className="w-1.5 h-1.5 bg-purple-400 rounded-full"></span>
                              {count} openings
                            </div>
                          )}
                        </Link>
                      );
                    })}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
