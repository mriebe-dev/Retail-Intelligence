import React, { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Loader2, MapPin, Store } from 'lucide-react';

export const MapPage: React.FC = () => {
  const [, setLocation] = useLocation();
  const [selectedCity, setSelectedCity] = useState<string>('');
  const [selectedCountry, setSelectedCountry] = useState<string>('');
  const [mapLoading, setMapLoading] = useState(true);

  const { data: citiesData } = trpc.cities.getAll.useQuery();
  const { data: cityData } = trpc.cities.getByName.useQuery(
    { country: selectedCountry, city: selectedCity },
    { enabled: !!selectedCity && !!selectedCountry }
  );

  useEffect(() => {
    // Simulate map loading
    const timer = setTimeout(() => setMapLoading(false), 1000);
    return () => clearTimeout(timer);
  }, []);

  const countries = Array.isArray(citiesData) ? citiesData.map((item: any) => item.country) : [];
  const citiesForCountry = Array.isArray(citiesData) 
    ? citiesData.find((item: any) => item.country === selectedCountry)?.cities || []
    : [];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Global Luxury Monitoring Maps</h1>
              <p className="text-sm text-muted-foreground">Interactive store location visualization</p>
            </div>
            <Button
              variant="outline"
              onClick={() => setLocation('/')}
            >
              Back to Home
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-4 sticky top-24">
              <h2 className="text-lg font-semibold mb-4">Select City</h2>

              {/* Country Selector */}
              <div className="mb-4">
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Country
                </label>
                <select
                  className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground"
                  onChange={(e) => {
                    setSelectedCountry(e.target.value);
                    setSelectedCity('');
                  }}
                  value={selectedCountry}
                >
                  <option value="">Select Country...</option>
                  {countries.map((country: string) => (
                    <option key={country} value={country}>
                      {country}
                    </option>
                  ))}
                </select>
              </div>

              {/* City Selector */}
              {selectedCountry && (
                <div className="mb-4">
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    City
                  </label>
                  <select
                    className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground"
                    onChange={(e) => setSelectedCity(e.target.value)}
                    value={selectedCity}
                  >
                    <option value="">Select City...</option>
                    {citiesForCountry.map((city: string) => (
                      <option key={city} value={city}>
                        {city}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* City Stats */}
              {cityData && (
                <div className="space-y-3 mt-6 pt-6 border-t border-border">
                  <div className="flex items-center gap-2">
                    <Store className="w-4 h-4 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">Premium Streets</p>
                      <p className="text-lg font-semibold">{cityData.streets}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">Streets Listed</p>
                      <p className="text-lg font-semibold">{cityData.streetList?.length || 0}</p>
                    </div>
                  </div>
                </div>
              )}
            </Card>
          </div>

          {/* Map Container */}
          <div className="lg:col-span-3">
            <Card className="overflow-hidden h-[600px]">
              {mapLoading && (
                <div className="w-full h-full flex items-center justify-center bg-muted">
                  <div className="text-center">
                    <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">Loading map...</p>
                  </div>
                </div>
              )}

              {!mapLoading && (
                <div className="w-full h-full bg-muted flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="w-12 h-12 mx-auto mb-3 text-muted-foreground" />
                    <p className="text-muted-foreground mb-2">
                      {selectedCity && selectedCountry
                        ? `Map for ${selectedCity}, ${selectedCountry}`
                        : 'Select a city to view the map'}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Google Maps integration coming soon
                    </p>
                  </div>
                </div>
              )}
            </Card>

            {/* Map Legend */}
            <Card className="mt-4 p-4">
              <h3 className="font-semibold mb-3">Map Legend</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-primary"></div>
                  <span>Store Location</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-amber-500"></div>
                  <span>Premium Street</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};
