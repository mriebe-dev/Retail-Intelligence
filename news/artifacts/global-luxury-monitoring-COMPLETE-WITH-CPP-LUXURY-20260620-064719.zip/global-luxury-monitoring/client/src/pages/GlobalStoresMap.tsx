import React, { useEffect, useState, useRef } from 'react';
import { MapView } from '@/components/Map';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { MapPin, Store, Filter, X, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Store {
  id: string;
  brand: string;
  city: string;
  country: string;
  latitude: number;
  longitude: number;
  category: string;
  status: string;
  location?: string;
  address_full?: string;
  size_sqm?: number;
  opening_date?: string;
  store_type?: string;
  property_owner?: string;
  data_source?: string;
  verification_status?: string;
}

interface MapData {
  total_stores: number;
  enriched_count: number;
  stores: Store[];
}

export const GlobalStoresMap: React.FC = () => {
  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.marker.AdvancedMarkerElement[]>([]);
  
  const [mapData, setMapData] = useState<MapData | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedStore, setSelectedStore] = useState<Store | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    country: '',
    category: '',
    status: '',
    verification: ''
  });
  const [showFilters, setShowFilters] = useState(false);

  // Load map data
  useEffect(() => {
    const loadMapData = async () => {
      try {
        const response = await fetch('/api/map-data');
        if (!response.ok) throw new Error('Failed to load map data');
        const data = await response.json();
        setMapData(data);
      } catch (error) {
        console.error('Error loading map data:', error);
        // Fallback: load from local file
        try {
          const response = await fetch('/map_data.json');
          const data = await response.json();
          setMapData(data);
        } catch (e) {
          console.error('Fallback failed:', e);
        }
      } finally {
        setLoading(false);
      }
    };
    loadMapData();
  }, []);

  // Filter stores
  const filteredStores = mapData?.stores.filter(store => {
    const matchesSearch = 
      store.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      store.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      store.country.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCountry = !filters.country || store.country === filters.country;
    const matchesCategory = !filters.category || store.category === filters.category;
    const matchesStatus = !filters.status || store.status === filters.status;
    const matchesVerification = !filters.verification || store.verification_status === filters.verification;
    
    return matchesSearch && matchesCountry && matchesCategory && matchesStatus && matchesVerification;
  }) || [];

  // Get unique values for filters
  const countries = Array.from(new Set(mapData?.stores.map(s => s.country) || [])).sort();
  const categories = Array.from(new Set(mapData?.stores.map(s => s.category) || [])).sort();
  const statuses = Array.from(new Set(mapData?.stores.map(s => s.status) || [])).sort();
  const verifications = Array.from(new Set(mapData?.stores.map(s => s.verification_status) || [])).sort();

  // Add markers to map
  useEffect(() => {
    if (!mapRef.current || !filteredStores.length) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.map = null);
    markersRef.current = [];

    // Add new markers
    filteredStores.forEach(store => {
      const marker = new google.maps.marker.AdvancedMarkerElement({
        map: mapRef.current!,
        position: { lat: store.latitude, lng: store.longitude },
        title: `${store.brand} - ${store.city}`,
      });

      marker.addListener('click', () => {
        setSelectedStore(store);
        mapRef.current?.setCenter({ lat: store.latitude, lng: store.longitude });
        mapRef.current?.setZoom(15);
      });

      markersRef.current.push(marker);
    });
  }, [filteredStores]);

  // Fit bounds to all markers
  const fitBounds = () => {
    if (!mapRef.current || !filteredStores.length) return;
    
    const bounds = new google.maps.LatLngBounds();
    filteredStores.forEach(store => {
      bounds.extend({ lat: store.latitude, lng: store.longitude });
    });
    mapRef.current.fitBounds(bounds);
  };

  useEffect(() => {
    fitBounds();
  }, [filteredStores]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Store className="w-12 h-12 mx-auto mb-3 text-muted-foreground animate-pulse" />
          <p className="text-muted-foreground">Loading global stores map...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Global Luxury Stores Map</h1>
              <p className="text-sm text-muted-foreground">
                {filteredStores.length} of {mapData?.total_stores || 0} stores ({mapData?.enriched_count || 0} enriched)
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={fitBounds}
            >
              Fit All Stores
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            {/* Search */}
            <Card className="p-4">
              <Input
                placeholder="Search stores, cities..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full"
              />
            </Card>

            {/* Filters */}
            <Card className="p-4">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center justify-between w-full mb-4"
              >
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4" />
                  <span className="font-semibold">Filters</span>
                </div>
                <ChevronDown className={cn("w-4 h-4 transition-transform", showFilters && "rotate-180")} />
              </button>

              {showFilters && (
                <div className="space-y-4">
                  {/* Country Filter */}
                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">Country</label>
                    <select
                      className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground text-sm"
                      value={filters.country}
                      onChange={(e) => setFilters({ ...filters, country: e.target.value })}
                    >
                      <option value="">All Countries</option>
                      {countries.map(country => (
                        <option key={country} value={country}>{country}</option>
                      ))}
                    </select>
                  </div>

                  {/* Category Filter */}
                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">Category</label>
                    <select
                      className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground text-sm"
                      value={filters.category}
                      onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                    >
                      <option value="">All Categories</option>
                      {categories.map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>

                  {/* Status Filter */}
                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">Status</label>
                    <select
                      className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground text-sm"
                      value={filters.status}
                      onChange={(e) => setFilters({ ...filters, status: e.target.value })}
                    >
                      <option value="">All Status</option>
                      {statuses.map(status => (
                        <option key={status} value={status}>{status}</option>
                      ))}
                    </select>
                  </div>

                  {/* Verification Filter */}
                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">Verification</label>
                    <select
                      className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground text-sm"
                      value={filters.verification}
                      onChange={(e) => setFilters({ ...filters, verification: e.target.value })}
                    >
                      <option value="">All</option>
                      {verifications.map(v => (
                        <option key={v} value={v}>{v}</option>
                      ))}
                    </select>
                  </div>

                  {/* Reset Filters */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setFilters({ country: '', category: '', status: '', verification: '' })}
                    className="w-full"
                  >
                    Reset Filters
                  </Button>
                </div>
              )}
            </Card>

            {/* Store List */}
            <Card className="p-4 max-h-[600px] overflow-y-auto">
              <h3 className="font-semibold mb-3">Stores ({filteredStores.length})</h3>
              <div className="space-y-2">
                {filteredStores.slice(0, 50).map(store => (
                  <button
                    key={store.id}
                    onClick={() => {
                      setSelectedStore(store);
                      mapRef.current?.setCenter({ lat: store.latitude, lng: store.longitude });
                      mapRef.current?.setZoom(15);
                    }}
                    className={cn(
                      "w-full text-left p-2 rounded-md text-sm transition-colors",
                      selectedStore?.id === store.id
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-muted"
                    )}
                  >
                    <div className="font-medium">{store.brand}</div>
                    <div className="text-xs opacity-75">{store.city}, {store.country}</div>
                  </button>
                ))}
              </div>
            </Card>
          </div>

          {/* Map Container */}
          <div className="lg:col-span-3 space-y-4">
            <Card className="overflow-hidden h-[600px]">
              <MapView
                initialCenter={{ lat: 20, lng: 0 }}
                initialZoom={2}
                onMapReady={(map) => {
                  mapRef.current = map;
                  fitBounds();
                }}
                className="h-full"
              />
            </Card>

            {/* Store Details Panel */}
            {selectedStore && (
              <Card className="p-4">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold">{selectedStore.brand}</h3>
                    <p className="text-sm text-muted-foreground">
                      {selectedStore.city}, {selectedStore.country}
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedStore(null)}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  {selectedStore.address_full && (
                    <div>
                      <p className="text-muted-foreground">Address</p>
                      <p className="font-medium">{selectedStore.address_full}</p>
                    </div>
                  )}
                  {selectedStore.size_sqm && (
                    <div>
                      <p className="text-muted-foreground">Size</p>
                      <p className="font-medium">{selectedStore.size_sqm} sqm</p>
                    </div>
                  )}
                  {selectedStore.opening_date && (
                    <div>
                      <p className="text-muted-foreground">Opening Date</p>
                      <p className="font-medium">{new Date(selectedStore.opening_date).toLocaleDateString()}</p>
                    </div>
                  )}
                  {selectedStore.store_type && (
                    <div>
                      <p className="text-muted-foreground">Store Type</p>
                      <p className="font-medium">{selectedStore.store_type}</p>
                    </div>
                  )}
                  {selectedStore.property_owner && (
                    <div>
                      <p className="text-muted-foreground">Property Owner</p>
                      <p className="font-medium">{selectedStore.property_owner}</p>
                    </div>
                  )}
                  <div>
                    <p className="text-muted-foreground">Verification</p>
                    <p className="font-medium">{selectedStore.verification_status || 'UNVERIFIED'}</p>
                  </div>
                </div>

                {selectedStore.data_source && (
                  <p className="text-xs text-muted-foreground mt-4">
                    Source: {selectedStore.data_source}
                  </p>
                )}
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
