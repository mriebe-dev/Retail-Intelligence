import { useRoute, Link } from "wouter";
import { LuxuryMap } from "@/components/LuxuryMap";
import { LuxuryFilters, type FilterOptions } from "@/components/LuxuryFilters";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, MapPin, Building2, Calendar } from "lucide-react";
import { useState, useMemo } from "react";

export default function CityDetail() {
  const [, params] = useRoute("/city/:city");
  const city = params?.city || "";
  const [filters, setFilters] = useState<FilterOptions>({
    searchText: "",
    newsType: "",
    source: "",
    dateFrom: "",
    dateTo: "",
    brand: "",
  });

  const { data: stores, isLoading } = trpc.luxury.list.useQuery({ city });
  const { data: brands } = trpc.luxury.brands.useQuery();

  // Extract unique values for filters
  const uniqueNewsTypes = useMemo(
    () => (stores ? Array.from(new Set(stores.map((s) => s.newsType))) : []),
    [stores]
  );
  const uniqueSources = useMemo(
    () => (stores ? Array.from(new Set(stores.map((s) => s.sourceName || ""))) : []),
    [stores]
  );

  // Apply filters
  const filteredStores = useMemo(() => {
    if (!stores) return [];
    return stores.filter((store) => {
      // Search text filter
      if (filters.searchText) {
        const searchLower = filters.searchText.toLowerCase();
        const matchesSearch =
          store.brandName.toLowerCase().includes(searchLower) ||
          store.locationAddress?.toLowerCase().includes(searchLower) ||
          store.summary?.toLowerCase().includes(searchLower);
        if (!matchesSearch) return false;
      }

      // News type filter
      if (filters.newsType && store.newsType !== filters.newsType) return false;

      // Source filter
      if (filters.source && store.sourceName !== filters.source) return false;

      // Brand filter
      if (filters.brand && store.brandName !== filters.brand) return false;

      // Date range filter
      if (filters.dateFrom) {
        const storeDate = new Date(store.date);
        const fromDate = new Date(filters.dateFrom);
        if (storeDate < fromDate) return false;
      }

      if (filters.dateTo) {
        const storeDate = new Date(store.date);
        const toDate = new Date(filters.dateTo);
        if (storeDate > toDate) return false;
      }

      return true;
    });
  }, [stores, filters]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="animate-spin w-8 h-8" />
      </div>
    );
  }

  // Group stores by street
  const storesByStreet = useMemo(() => {
    if (!filteredStores) return {};
    const grouped: { [key: string]: typeof filteredStores } = {};
    filteredStores.forEach(store => {
      const street = store.locationAddress?.split(',')[0] || 'Other';
      if (!grouped[street]) grouped[street] = [];
      grouped[street].push(store);
    });
    return grouped;
  }, [filteredStores]);

  const streets = Object.keys(storesByStreet);
  const [selectedStreet, setSelectedStreet] = useState<string>(streets[0] || '');
  const activeStreetStores = storesByStreet[selectedStreet] || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center gap-3 mb-2">
            <MapPin className="w-8 h-8 text-white" />
            <div>
              <h1 className="text-4xl font-bold text-white capitalize">{city}</h1>
              <p className="text-white/80">Global Luxury Retail Hub</p>
            </div>
          </div>
          <p className="text-white/90 text-lg">{filteredStores?.length || 0} luxury retail locations tracked</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Map Section */}
        <Card className="mb-8 bg-white/80 backdrop-blur border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-purple-600" />
              Store Locations Map
            </CardTitle>
          </CardHeader>
          <CardContent>
            <LuxuryMap city={city} height="h-96" />
          </CardContent>
        </Card>

        {/* Key Metrics */}
        <Card className="mb-8 bg-white/80 backdrop-blur border-purple-200">
          <CardContent className="pt-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">{filteredStores?.length || 0}</div>
                <div className="text-sm text-gray-600 mt-1">Total Stores</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">{streets.length}</div>
                <div className="text-sm text-gray-600 mt-1">Premium Streets</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">{brands?.length || 0}</div>
                <div className="text-sm text-gray-600 mt-1">Luxury Brands</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">2026</div>
                <div className="text-sm text-gray-600 mt-1">Latest Year</div>
              </div>
            </div>
          </CardContent>
        </Card>
        {/* Street Selection */}
        {streets.length > 0 && (
          <Card className="mb-8 bg-white/80 backdrop-blur border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-purple-600" />
                Premium Streets ({streets.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {streets.map(street => (
                  <button
                    key={street}
                    onClick={() => setSelectedStreet(street)}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      selectedStreet === street
                        ? 'border-purple-600 bg-purple-50'
                        : 'border-gray-200 hover:border-purple-300'
                    }`}
                  >
                    <h3 className="font-bold text-lg mb-2">{street}</h3>
                    <div className="text-sm text-gray-600">
                      {storesByStreet[street]?.length || 0} stores
                    </div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Filters */}
        <Card className="mb-8 bg-white/80 backdrop-blur border-purple-200">
          <CardHeader>
            <CardTitle>Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <LuxuryFilters
              onFilterChange={setFilters}
              brands={brands || []}
              newsTypes={uniqueNewsTypes}
              sources={uniqueSources}
            />
          </CardContent>
        </Card>

        {/* Active Street Stores */}
        {selectedStreet && (
          <Card className="bg-white/80 backdrop-blur border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{selectedStreet}</span>
                <Badge className="bg-purple-100 text-purple-700">
                  {activeStreetStores.length} stores
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {activeStreetStores.map((store) => (
                  <Link key={store.id} href={`/store/${store.id}`}>
                    <div className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                      {store.imageUrl && (
                        <div className="w-full h-40 bg-gray-200 overflow-hidden">
                          <img src={store.imageUrl} alt={store.brandName} className="w-full h-full object-cover" />
                        </div>
                      )}
                      <div className="p-4">
                        <h4 className="font-bold text-lg mb-2">{store.brandName}</h4>
                        <p className="text-sm text-gray-600 mb-3">{store.locationAddress}</p>
                        <div className="space-y-2 mb-4 text-sm">
                          <div className="flex items-center gap-2 text-gray-600">
                            <Building2 className="w-4 h-4" />
                            {store.newsType}
                          </div>
                          <div className="flex items-center gap-2 text-gray-600">
                            <Calendar className="w-4 h-4" />
                            {new Date(store.date).toLocaleDateString()}
                          </div>
                        </div>
                        <Badge className="bg-blue-100 text-blue-700 mb-3">
                          {store.sourceName}
                        </Badge>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
