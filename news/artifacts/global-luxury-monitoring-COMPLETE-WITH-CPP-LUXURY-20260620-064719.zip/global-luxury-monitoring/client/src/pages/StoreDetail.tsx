import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, MapPin, Calendar, Link as LinkIcon, Users } from "lucide-react";

export default function StoreDetail() {
  const [, params] = useRoute("/store/:id");
  const storeId = params?.id ? parseInt(params.id) : null;

  const { data: store, isLoading } = trpc.luxury.getById.useQuery(
    { id: storeId || 0 },
    { enabled: !!storeId }
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="animate-spin w-8 h-8" />
      </div>
    );
  }

  if (!store) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-500">Store not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="border-b">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <Button variant="outline" className="mb-4">
            ← Back
          </Button>
          <h1 className="text-4xl font-bold mb-2">{store.brandName}</h1>
          <p className="text-gray-600">{store.locationAddress}</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Left Column - Main Info */}
          <div className="md:col-span-2">
            {/* Summary */}
            <Card className="p-6 mb-6">
              <h2 className="text-2xl font-bold mb-4">Overview</h2>
              <p className="text-gray-700 leading-relaxed">{store.summary}</p>
            </Card>

            {/* Details */}
            <Card className="p-6">
              <h2 className="text-2xl font-bold mb-6">Details</h2>
              <div className="space-y-4">
                {/* Date */}
                <div className="flex items-start gap-4">
                  <Calendar className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-gray-900">Date</p>
                    <p className="text-gray-600">
                      {new Date(store.date).toLocaleDateString("de-CH", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                </div>

                {/* Location */}
                <div className="flex items-start gap-4">
                  <MapPin className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-gray-900">Location</p>
                    <p className="text-gray-600">{store.locationAddress}</p>
                    <p className="text-gray-600">
                      {store.city}, {store.country}
                    </p>
                  </div>
                </div>

                {/* News Type */}
                <div className="flex items-start gap-4">
                  <div className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-1.5"></div>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">News Type</p>
                    <p className="text-gray-600">{store.newsType}</p>
                  </div>
                </div>

                {/* Source */}
                {store.sourceName && (
                  <div className="flex items-start gap-4">
                    <LinkIcon className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-gray-900">Source</p>
                      <p className="text-gray-600">{store.sourceName}</p>
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* Right Column - Metadata */}
          <div>
            {/* Key Info */}
            <Card className="p-6 mb-6">
              <h3 className="font-bold text-lg mb-4">Key Information</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600">Brand</p>
                  <p className="font-semibold">{store.brandName}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">City</p>
                  <p className="font-semibold">{store.city}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Country</p>
                  <p className="font-semibold">{store.country}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">News Type</p>
                  <span className="inline-block bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm font-semibold">
                    {store.newsType}
                  </span>
                </div>
              </div>
            </Card>

            {/* Source Link */}
            {store.sourceUrl && (
              <Card className="p-6">
                <h3 className="font-bold text-lg mb-4">Source</h3>
                <a
                  href={store.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 font-semibold"
                >
                  <LinkIcon className="w-4 h-4" />
                  View Original Source
                </a>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
