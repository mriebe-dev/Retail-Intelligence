import React, { useState, useMemo } from "react";
import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, ChevronDown, ChevronUp, MapPin, Calendar, Building2 } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Store {
  id: string;
  name: string;
  street: string;
  address: string;
  city: string;
  brand: string;
  category?: string;
  openingDate?: string;
  size?: string;
  status?: "new" | "premium" | "featured";
  description?: string;
}

interface StreetGroup {
  street: string;
  stores: Store[];
  totalStores: number;
}

const CITY_METADATA: Record<string, {
  name: string;
  country: string;
  heroImage: string;
  description: string;
  mainStreet: string;
  stats: {
    newOpenings: number;
    flagshipStores: number;
    avgRent: string;
    vacancyRate: string;
    footfall: string;
  };
}> = {
  zurich: {
    name: "Zürich",
    country: "Switzerland",
    heroImage: "https://images.unsplash.com/photo-1488747807830-63789f68bb65?w=1200&h=400&fit=crop",
    description: "Where Precision Meets Global Style",
    mainStreet: "Bahnhofstrasse",
    stats: {
      newOpenings: 33,
      flagshipStores: 12,
      avgRent: "CHF 13'000/m²",
      vacancyRate: "<0.5%",
      footfall: "13.8 Mio.",
    },
  },
  geneva: {
    name: "Genf",
    country: "Switzerland",
    heroImage: "https://images.unsplash.com/photo-1488747807830-63789f68bb65?w=1200&h=400&fit=crop",
    description: "Luxury Watch & Jewelry Capital",
    mainStreet: "Rue du Rhône",
    stats: {
      newOpenings: 16,
      flagshipStores: 8,
      avgRent: "CHF 12'000/m²",
      vacancyRate: "<1%",
      footfall: "9.2 Mio.",
    },
  },
};

export default function CityPageLayout() {
  const [, params] = useRoute("/city/:country/:city") || useRoute("/city/:city");
  const citySlug = params?.city || "zurich";
  const country = params?.country ? decodeURIComponent(params.country) : "";
  const cityName = citySlug === "zurich" ? "Zürich" : citySlug === "geneva" ? "Genf" : citySlug?.charAt(0).toUpperCase() + citySlug?.slice(1) || "Unknown";

  // Filters
  const [selectedYear, setSelectedYear] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [expandedStreets, setExpandedStreets] = useState<Set<string>>(new Set([CITY_METADATA[citySlug]?.mainStreet || ""]));

  // Fetch city data
  const { data: cityData } = trpc.cities.getByName.useQuery(
    { country, city: cityName },
    { enabled: !!country && !!cityName }
  );

  // Fetch news by city
  const { data: newsData, isLoading } = trpc.news.getByCity.useQuery(
    { city: cityName || citySlug },
    { enabled: !!cityName }
  );

  const cityInfo = CITY_METADATA[citySlug] || CITY_METADATA.zurich;

  // Group stores by street
  const streetGroups = useMemo(() => {
    if (!newsData?.byStreet) return [];

    // Group by street
    const grouped: Record<string, Store[]> = {};
    
    newsData.byStreet.forEach((streetData: any) => {
      const street = streetData.street || "Other";
      if (!grouped[street]) {
        grouped[street] = [];
      }
      // Create store entries from brands
      streetData.brands?.forEach((brand: string) => {
        grouped[street].push({
          id: `${street}-${brand}`,
          name: brand,
          street: street,
          address: street,
          city: newsData.city || "",
          brand: brand,
          category: "",
          openingDate: "",
          size: "",
          status: "new",
          description: "",
        });
      });
    });

    // Convert to array and sort by main street first
    const mainStreet = cityInfo.mainStreet;
    const result: StreetGroup[] = [];
    
    // Add main street first
    if (grouped[mainStreet]) {
      result.push({
        street: mainStreet,
        stores: grouped[mainStreet],
        totalStores: grouped[mainStreet].length,
      });
      delete grouped[mainStreet];
    }

    // Add other streets sorted alphabetically
    Object.keys(grouped)
      .sort()
      .forEach(street => {
        result.push({
          street,
          stores: grouped[street],
          totalStores: grouped[street].length,
        });
      });

    return result;
  }, [newsData, cityInfo.mainStreet]);

  // Filter stores by year and category
  const filteredStreetGroups = useMemo(() => {
    return streetGroups.map(group => ({
      ...group,
      stores: group.stores.filter(store => {
        // Category filter (simplified since we don't have detailed data)
        if (selectedCategory !== "all") {
          // Could add category logic here if data is available
        }
        return true;
      }),
    })).filter(group => group.stores.length > 0);
  }, [streetGroups, selectedCategory]);

  const toggleStreet = (street: string) => {
    const newExpanded = new Set(expandedStreets);
    if (newExpanded.has(street)) {
      newExpanded.delete(street);
    } else {
      newExpanded.add(street);
    }
    setExpandedStreets(newExpanded);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-magenta-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative h-96 overflow-hidden">
        <img
          src={cityInfo.heroImage}
          alt={cityInfo.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        
        {/* Hero Content */}
        <div className="absolute inset-0 flex flex-col justify-center items-center text-white text-center px-4">
          <h1 className="text-5xl font-bold mb-4">{cityInfo.name}</h1>
          <p className="text-xl mb-8">{cityInfo.description}</p>
          
          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-8">
            <div className="bg-white/10 backdrop-blur-md rounded-lg p-4">
              <div className="text-3xl font-bold text-amber-400">{cityInfo.stats.newOpenings}+</div>
              <div className="text-sm text-white/80">New Openings 2024-2026</div>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-lg p-4">
              <div className="text-3xl font-bold text-amber-400">{cityInfo.stats.flagshipStores}</div>
              <div className="text-sm text-white/80">Flagship Stores</div>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-lg p-4">
              <div className="text-xl font-bold text-amber-400">{cityInfo.stats.avgRent}</div>
              <div className="text-sm text-white/80">Peak Rent</div>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-lg p-4">
              <div className="text-xl font-bold text-amber-400">{cityInfo.stats.vacancyRate}</div>
              <div className="text-sm text-white/80">Vacancy Rate</div>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-lg p-4">
              <div className="text-xl font-bold text-amber-400">{cityInfo.stats.footfall}</div>
              <div className="text-sm text-white/80">Footfall/Year</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters Section */}
      <div className="bg-white border-b border-border sticky top-0 z-40">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row gap-4 items-end">
            <div className="flex-1">
              <label className="block text-sm font-medium text-foreground mb-2">Year</label>
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Years</SelectItem>
                  <SelectItem value="2022">2022</SelectItem>
                  <SelectItem value="2023">2023</SelectItem>
                  <SelectItem value="2024">2024</SelectItem>
                  <SelectItem value="2025">2025</SelectItem>
                  <SelectItem value="2026">2026</SelectItem>
                  <SelectItem value="2028">2028</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1">
              <label className="block text-sm font-medium text-foreground mb-2">Category</label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="fashion">Fashion</SelectItem>
                  <SelectItem value="food">Food & Beverage</SelectItem>
                  <SelectItem value="beauty">Beauty & Cosmetics</SelectItem>
                  <SelectItem value="watches">Watches & Jewelry</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      {/* Streets & Stores Section */}
      <div className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold mb-8">Key Openings {cityInfo.name}</h2>

        {filteredStreetGroups.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-muted-foreground">No stores found for the selected filters.</p>
          </Card>
        ) : (
          <div className="space-y-6">
            {filteredStreetGroups.map((group) => (
              <div key={group.street} className="border border-border rounded-lg overflow-hidden">
                {/* Street Header */}
                <button
                  onClick={() => toggleStreet(group.street)}
                  className="w-full bg-gradient-to-r from-magenta-50 to-amber-50 hover:from-magenta-100 hover:to-amber-100 p-4 flex items-center justify-between transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <MapPin className="h-5 w-5 text-magenta-600" />
                    <div className="text-left">
                      <h3 className="font-bold text-lg text-foreground">{group.street}</h3>
                      <p className="text-sm text-muted-foreground">{group.totalStores} stores</p>
                    </div>
                  </div>
                  {expandedStreets.has(group.street) ? (
                    <ChevronUp className="h-5 w-5 text-magenta-600" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-magenta-600" />
                  )}
                </button>

                {/* Stores List */}
                {expandedStreets.has(group.street) && (
                  <div className="divide-y divide-border">
                    {group.stores.map((store) => (
                      <div key={store.id} className="p-4 hover:bg-muted/50 transition-colors">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <h4 className="font-bold text-foreground mb-1">{store.brand}</h4>
                            <div className="flex flex-wrap gap-2 text-sm text-muted-foreground mb-2">
                              {store.address && (
                                <span className="flex items-center gap-1">
                                  <MapPin className="h-3 w-3" />
                                  {store.address}
                                </span>
                              )}
                              {store.size && (
                                <span className="flex items-center gap-1">
                                  <Building2 className="h-3 w-3" />
                                  {store.size}
                                </span>
                              )}
                            </div>
                            {store.description && (
                              <p className="text-sm text-muted-foreground">{store.description}</p>
                            )}
                          </div>
                          <div className="text-right">
                            {store.openingDate && (
                              <div className="flex items-center gap-1 text-sm font-medium text-magenta-600 mb-2">
                                <Calendar className="h-4 w-4" />
                                {new Date(store.openingDate).toLocaleDateString("de-CH")}
                              </div>
                            )}
                            {store.status === "new" && (
                              <span className="inline-block bg-green-100 text-green-800 text-xs font-semibold px-2 py-1 rounded">
                                New
                              </span>
                            )}
                            {store.status === "premium" && (
                              <span className="inline-block bg-amber-100 text-amber-800 text-xs font-semibold px-2 py-1 rounded">
                                Premium
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
