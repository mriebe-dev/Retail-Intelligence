/**
 * FAST CPP-LUXURY Scraper
 * - Only reads listing pages (not individual articles)
 * - Parallel requests (5 at a time)
 * - Extracts: title, URL, date, brand, city from listing page
 * - Saves directly to JSON file for batch DB import
 */

import * as cheerio from 'cheerio';
import * as fs from 'fs';

const BASE_URL = 'https://cpp-luxury.com/news';
const OUTPUT_FILE = '/home/ubuntu/global-luxury-monitoring/cpp-luxury-scraped.json';
const CONCURRENT = 5;
const DELAY_MS = 300;

// Keywords to identify store opening articles
const OPENING_KEYWORDS = [
  'opens', 'opening', 'open', 'launch', 'launches', 'debut', 'debuts',
  'new boutique', 'new store', 'new flagship', 'new shop', 'new location',
  'unveils', 'inaugurates', 'new pop-up', 'new concept', 'expands',
  'relocates', 'reopens', 'reopen', 'new maison', 'new space'
];

// Known luxury brands for extraction
const LUXURY_BRANDS = [
  'Louis Vuitton', 'Dior', 'Fendi', 'Celine', 'Céline', 'Givenchy', 'Loewe',
  'Marc Jacobs', 'Kenzo', 'Berluti', 'Loro Piana', 'Rimowa', 'Bulgari',
  'TAG Heuer', 'Hublot', 'Zenith', 'Chaumet', 'Guerlain', 'Acqua di Parma',
  'Gucci', 'Saint Laurent', 'YSL', 'Bottega Veneta', 'Balenciaga',
  'Alexander McQueen', 'Brioni', 'Boucheron', 'Pomellato', 'Valentino',
  'Cartier', 'Van Cleef', 'Piaget', 'Vacheron', 'IWC', 'Jaeger-LeCoultre',
  'Panerai', 'Roger Dubuis', 'Baume & Mercier', 'Montblanc', 'Dunhill',
  'Chloé', 'Alaïa', 'Omega', 'Longines', 'Tissot', 'Rado', 'Hamilton',
  'Swatch', 'Breguet', 'Blancpain', 'Harry Winston', 'Hermès', 'Hermes',
  'Chanel', 'Prada', 'Miu Miu', 'Burberry', 'Ralph Lauren', 'Tiffany',
  'Rolex', 'Chopard', 'De Beers', 'Graff', 'Messika', 'Dolce & Gabbana',
  'Dolce&Gabbana', 'Giorgio Armani', 'Armani', 'Max Mara', 'Moncler',
  'Brunello Cucinelli', 'Zegna', 'Boglioli', 'Hackett', 'Issey Miyake',
  'ISSEY MIYAKE', 'Jacquemus', 'Acne Studios', 'SKIMS', 'On Running',
  'New Balance', 'Sporty & Rich', 'Arc\'teryx', 'Arcteryx', 'Ami Paris',
  'Rick Owens', 'Ami', 'Bolia', 'BOLIA', 'Arket', 'COS', 'Zara',
  'Massimo Dutti', 'Coach', 'Kate Spade', 'Versace', 'Jimmy Choo',
  'Michael Kors', 'Tory Burch', 'Zimmermann', 'Ganni', 'Nanushka',
  'Toteme', 'Staud', 'Jacquemus', 'Loewe', 'Chloe', 'Ferragamo',
  'Tod\'s', 'Tods', 'Hogan', 'Roger Vivier', 'Manolo Blahnik',
  'Christian Louboutin', 'Louboutin', 'Giuseppe Zanotti', 'Stuart Weitzman',
  'Aquazzura', 'Gianvito Rossi', 'Sergio Rossi', 'Casadei', 'Rene Caovilla',
  'Bally', 'Church\'s', 'Grenson', 'Crockett & Jones', 'Edward Green',
  'John Lobb', 'Berluti', 'Santoni', 'Magnanni', 'Carmina', 'Meermin',
  'Patek Philippe', 'Audemars Piguet', 'AP', 'A. Lange & Söhne', 'Lange',
  'F.P. Journe', 'Richard Mille', 'Urwerk', 'MB&F', 'HYT', 'Greubel Forsey',
  'Bulgari', 'Bvlgari', 'Pomellato', 'Dodo', 'Repossi', 'Messika',
  'Tasaki', 'Mikimoto', 'Tiffany & Co', 'Tiffany', 'Cartier', 'Piaget',
  'Chopard', 'De Beers', 'Graff', 'Harry Winston', 'Boodles', 'Garrard',
  'Mappin & Webb', 'Asprey', 'Wartski', 'Moussaieff', 'Laurence Graff',
  'Sotheby\'s', 'Christie\'s', 'Bonhams', 'Phillips', 'Artcurial',
  'Galeries Lafayette', 'Printemps', 'Le Bon Marché', 'Selfridges',
  'Harrods', 'Harvey Nichols', 'Bergdorf Goodman', 'Saks Fifth Avenue',
  'Neiman Marcus', 'Nordstrom', 'Barneys', 'Bloomingdale\'s',
  'Isetan', 'Mitsukoshi', 'Takashimaya', 'Daimaru', 'Matsuzakaya',
  'Lane Crawford', 'Joyce', 'Club 21', 'Tangs', 'Robinsons',
  'Beymen', 'Vakko', 'Boyner', 'Ipekyol', 'Mavi', 'LC Waikiki',
  'Miniso', 'MINISO', 'Muji', 'MUJI', 'Uniqlo', 'UNIQLO',
  'H&M', 'Zara', 'Mango', 'Bershka', 'Pull&Bear', 'Stradivarius',
  'Oysho', 'Massimo Dutti', 'Uterqüe', 'Lefties',
  'Nike', 'Adidas', 'Puma', 'Reebok', 'New Balance', 'Asics', 'Saucony',
  'Brooks', 'Hoka', 'On', 'Salomon', 'The North Face', 'Patagonia',
  'Arc\'teryx', 'Mammut', 'Black Diamond', 'Icebreaker', 'Smartwool',
  'Lululemon', 'Athleta', 'Sweaty Betty', 'Gymshark', 'Vuori',
  'Alo Yoga', 'Fabletics', 'Carbon38', 'Outdoor Voices',
  'Aesop', 'L\'Occitane', 'Diptyque', 'Jo Malone', 'Penhaligon\'s',
  'Creed', 'Byredo', 'Le Labo', 'Maison Margiela', 'Kilian',
  'Frederic Malle', 'Serge Lutens', 'Annick Goutal', 'Guerlain',
  'Sisley', 'La Prairie', 'La Mer', 'SK-II', 'Shiseido', 'Clé de Peau',
  'Tatcha', 'Sunday Riley', 'Drunk Elephant', 'Charlotte Tilbury',
  'NARS', 'MAC', 'Bobbi Brown', 'Laura Mercier', 'Hourglass',
  'Westman Atelier', 'Ilia', 'RMS Beauty', 'Kosas', 'Tower 28',
  'Glossier', 'Milk Makeup', 'Morphe', 'ColourPop', 'NYX',
  'Fenty Beauty', 'Rare Beauty', 'KKW Beauty', 'Kylie Cosmetics',
];

function extractBrand(title) {
  const titleLower = title.toLowerCase();
  for (const brand of LUXURY_BRANDS) {
    if (titleLower.includes(brand.toLowerCase())) {
      return brand;
    }
  }
  // Try first word if it looks like a brand
  const firstWord = title.split(' ')[0];
  if (firstWord && firstWord.length > 2 && firstWord[0] === firstWord[0].toUpperCase()) {
    return firstWord;
  }
  return null;
}

function extractCity(title) {
  const CITIES = [
    'New York', 'Los Angeles', 'Beverly Hills', 'Miami', 'Chicago', 'San Francisco',
    'Las Vegas', 'Aspen', 'Palm Beach', 'East Hampton', 'Southampton', 'Nantucket',
    'London', 'Paris', 'Milan', 'Milano', 'Rome', 'Roma', 'Florence', 'Firenze',
    'Venice', 'Venezia', 'Naples', 'Napoli', 'Turin', 'Torino', 'Bologna',
    'Madrid', 'Barcelona', 'Ibiza', 'Marbella', 'Seville', 'Valencia',
    'Amsterdam', 'Rotterdam', 'The Hague', 'Utrecht',
    'Berlin', 'Munich', 'Hamburg', 'Frankfurt', 'Düsseldorf', 'Cologne', 'Stuttgart',
    'Vienna', 'Wien', 'Zurich', 'Zürich', 'Geneva', 'Genf', 'Basel', 'Bern',
    'Lausanne', 'Lugano', 'St. Moritz', 'Gstaad', 'Zermatt', 'Verbier',
    'Brussels', 'Bruxelles', 'Antwerp', 'Ghent',
    'Stockholm', 'Copenhagen', 'Oslo', 'Helsinki', 'Gothenburg',
    'Lisbon', 'Lisboa', 'Porto',
    'Athens', 'Mykonos', 'Santorini', 'Rhodes',
    'Monaco', 'Cannes', 'Nice', 'Saint-Tropez', 'Courchevel', 'Megève',
    'Tokyo', 'Osaka', 'Kyoto', 'Nagoya', 'Yokohama', 'Fukuoka', 'Sapporo',
    'Shanghai', 'Beijing', 'Shenzhen', 'Guangzhou', 'Chengdu', 'Hangzhou',
    'Wuhan', 'Nanjing', 'Xi\'an', 'Chongqing', 'Tianjin', 'Suzhou',
    'Hong Kong', 'Macau', 'Taipei', 'Seoul', 'Busan', 'Singapore',
    'Bangkok', 'Jakarta', 'Kuala Lumpur', 'Manila', 'Ho Chi Minh',
    'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata', 'Hyderabad',
    'Dubai', 'Abu Dhabi', 'Doha', 'Riyadh', 'Jeddah', 'Kuwait City',
    'Cairo', 'Casablanca', 'Marrakech', 'Cape Town', 'Johannesburg',
    'Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Auckland',
    'Toronto', 'Vancouver', 'Montreal', 'Calgary',
    'São Paulo', 'Rio de Janeiro', 'Buenos Aires', 'Bogotá', 'Lima',
    'Mexico City', 'Monterrey', 'Guadalajara',
    'Moscow', 'St. Petersburg', 'Warsaw', 'Prague', 'Budapest', 'Bucharest',
    'Istanbul', 'Ankara', 'Izmir', 'Antalya',
    'Tel Aviv', 'Jerusalem', 'Beirut', 'Amman',
    'Myeongdong', 'Gangnam', 'Itaewon', 'Hongdae',
    'Ginza', 'Shibuya', 'Shinjuku', 'Omotesando', 'Harajuku', 'Aoyama',
    'Orchard', 'Marina Bay', 'Sentosa',
    'Mayfair', 'Knightsbridge', 'Chelsea', 'Soho', 'Covent Garden',
    'Marais', 'Saint-Germain', 'Champs-Élysées', 'Montaigne',
    'Brera', 'Navigli', 'Quadrilatero',
  ];

  for (const city of CITIES) {
    if (title.toLowerCase().includes(city.toLowerCase())) {
      return city;
    }
  }
  return null;
}

function extractCountry(city) {
  const CITY_COUNTRY = {
    'New York': 'USA', 'Los Angeles': 'USA', 'Beverly Hills': 'USA',
    'Miami': 'USA', 'Chicago': 'USA', 'San Francisco': 'USA',
    'Las Vegas': 'USA', 'Aspen': 'USA', 'Palm Beach': 'USA',
    'East Hampton': 'USA', 'Southampton': 'USA', 'Nantucket': 'USA',
    'London': 'UK', 'Mayfair': 'UK', 'Knightsbridge': 'UK',
    'Paris': 'France', 'Cannes': 'France', 'Nice': 'France',
    'Saint-Tropez': 'France', 'Courchevel': 'France', 'Monaco': 'Monaco',
    'Milan': 'Italy', 'Milano': 'Italy', 'Rome': 'Italy', 'Roma': 'Italy',
    'Florence': 'Italy', 'Venice': 'Italy', 'Naples': 'Italy',
    'Madrid': 'Spain', 'Barcelona': 'Spain', 'Ibiza': 'Spain',
    'Marbella': 'Spain', 'Seville': 'Spain', 'Valencia': 'Spain',
    'Amsterdam': 'Netherlands', 'Rotterdam': 'Netherlands',
    'Berlin': 'Germany', 'Munich': 'Germany', 'Hamburg': 'Germany',
    'Frankfurt': 'Germany', 'Düsseldorf': 'Germany',
    'Vienna': 'Austria', 'Wien': 'Austria',
    'Zurich': 'Switzerland', 'Zürich': 'Switzerland',
    'Geneva': 'Switzerland', 'Genf': 'Switzerland',
    'Basel': 'Switzerland', 'Bern': 'Switzerland',
    'St. Moritz': 'Switzerland', 'Gstaad': 'Switzerland',
    'Zermatt': 'Switzerland', 'Verbier': 'Switzerland',
    'Stockholm': 'Sweden', 'Copenhagen': 'Denmark', 'Oslo': 'Norway',
    'Helsinki': 'Finland', 'Lisbon': 'Portugal', 'Porto': 'Portugal',
    'Athens': 'Greece', 'Mykonos': 'Greece', 'Santorini': 'Greece',
    'Tokyo': 'Japan', 'Osaka': 'Japan', 'Kyoto': 'Japan',
    'Nagoya': 'Japan', 'Ginza': 'Japan', 'Shibuya': 'Japan',
    'Shanghai': 'China', 'Beijing': 'China', 'Shenzhen': 'China',
    'Guangzhou': 'China', 'Chengdu': 'China', 'Hangzhou': 'China',
    'Hong Kong': 'Hong Kong', 'Macau': 'Macau', 'Taipei': 'Taiwan',
    'Seoul': 'South Korea', 'Busan': 'South Korea',
    'Myeongdong': 'South Korea', 'Gangnam': 'South Korea',
    'Singapore': 'Singapore', 'Bangkok': 'Thailand',
    'Jakarta': 'Indonesia', 'Kuala Lumpur': 'Malaysia',
    'Mumbai': 'India', 'Delhi': 'India', 'Bangalore': 'India',
    'Dubai': 'UAE', 'Abu Dhabi': 'UAE', 'Doha': 'Qatar',
    'Riyadh': 'Saudi Arabia', 'Jeddah': 'Saudi Arabia',
    'Sydney': 'Australia', 'Melbourne': 'Australia',
    'Toronto': 'Canada', 'Vancouver': 'Canada', 'Montreal': 'Canada',
    'São Paulo': 'Brazil', 'Rio de Janeiro': 'Brazil',
    'Buenos Aires': 'Argentina', 'Mexico City': 'Mexico',
    'Istanbul': 'Turkey', 'Moscow': 'Russia',
    'Warsaw': 'Poland', 'Prague': 'Czech Republic',
    'Budapest': 'Hungary', 'Bucharest': 'Romania',
    'Brussels': 'Belgium', 'Antwerp': 'Belgium',
    'Tel Aviv': 'Israel', 'Beirut': 'Lebanon',
    'Cairo': 'Egypt', 'Casablanca': 'Morocco', 'Marrakech': 'Morocco',
    'Cape Town': 'South Africa', 'Johannesburg': 'South Africa',
  };
  return CITY_COUNTRY[city] || null;
}

function isOpeningArticle(title) {
  const titleLower = title.toLowerCase();
  return OPENING_KEYWORDS.some(kw => titleLower.includes(kw));
}

async function fetchPage(url) {
  const response = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    }
  });
  if (!response.ok) return null;
  return await response.text();
}

async function scrapePage(pageNum) {
  const url = pageNum === 1 ? `${BASE_URL}/` : `${BASE_URL}/page/${pageNum}/`;
  const html = await fetchPage(url);
  if (!html) return [];

  const $ = cheerio.load(html);
  const articles = [];

  // Find all article links
  $('a[href*="cpp-luxury.com"]').each((i, el) => {
    const href = $(el).attr('href') || '';
    const title = $(el).text().trim();

    // Skip navigation, category, pagination links
    if (!href.includes('/20') && !href.match(/\/[a-z-]+\/$/) ) return;
    if (title.length < 20) return;
    if (!isOpeningArticle(title)) return;

    const brand = extractBrand(title);
    const city = extractCity(title);
    const country = city ? extractCountry(city) : null;

    // Extract date from URL if possible (e.g. /2024/03/15/...)
    const dateMatch = href.match(/\/(\d{4})\/(\d{2})\/(\d{2})\//);
    const openingDate = dateMatch
      ? `${dateMatch[1]}-${dateMatch[2]}-${dateMatch[3]}`
      : new Date().toISOString().split('T')[0];

    articles.push({
      title,
      url: href,
      brand: brand || title.split(' ')[0],
      city: city || '',
      country: country || '',
      openingDate,
      source: 'cpp-luxury.com',
      category: 'Luxury Retail',
    });
  });

  // Remove duplicates by URL
  const seen = new Set();
  return articles.filter(a => {
    if (seen.has(a.url)) return false;
    seen.add(a.url);
    return true;
  });
}

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function scrapeAll() {
  console.log('🚀 Fast CPP-LUXURY Scraper Starting...');
  console.log('=========================================');

  // First, find total number of pages
  const firstPage = await fetchPage(`${BASE_URL}/`);
  if (!firstPage) {
    console.error('Failed to fetch first page');
    process.exit(1);
  }

  const $ = cheerio.load(firstPage);
  let maxPage = 1;

  // Find pagination
  $('a[href*="/news/page/"]').each((i, el) => {
    const href = $(el).attr('href') || '';
    const match = href.match(/\/page\/(\d+)\//);
    if (match) {
      const pageNum = parseInt(match[1]);
      if (pageNum > maxPage) maxPage = pageNum;
    }
  });

  // Also check "last page" link
  const lastPageLink = $('a.last, a[aria-label="Last Page"], .nav-links a:last-child').attr('href') || '';
  const lastMatch = lastPageLink.match(/\/page\/(\d+)\//);
  if (lastMatch) maxPage = parseInt(lastMatch[1]);

  // If we can't find pagination, estimate based on content
  if (maxPage === 1) maxPage = 600; // Conservative estimate

  console.log(`📄 Estimated pages: ${maxPage}`);

  const allArticles = [];
  const seenUrls = new Set();

  // Process pages in batches
  for (let startPage = 1; startPage <= maxPage; startPage += CONCURRENT) {
    const batch = [];
    for (let p = startPage; p < startPage + CONCURRENT && p <= maxPage; p++) {
      batch.push(p);
    }

    const results = await Promise.all(batch.map(p => scrapePage(p)));
    let newCount = 0;

    for (const articles of results) {
      for (const article of articles) {
        if (!seenUrls.has(article.url)) {
          seenUrls.add(article.url);
          allArticles.push(article);
          newCount++;
        }
      }
    }

    const lastPage = batch[batch.length - 1];
    console.log(`Pages ${batch[0]}-${lastPage}: +${newCount} articles (total: ${allArticles.length})`);

    // Save progress every 50 pages
    if (lastPage % 50 === 0 || lastPage >= maxPage) {
      fs.writeFileSync(OUTPUT_FILE, JSON.stringify(allArticles, null, 2));
      console.log(`💾 Saved ${allArticles.length} articles to ${OUTPUT_FILE}`);
    }

    // Stop if we get empty pages (reached end of content)
    if (results.every(r => r.length === 0) && startPage > 10) {
      console.log('✅ No more content found, stopping...');
      break;
    }

    await sleep(DELAY_MS);
  }

  // Final save
  fs.writeFileSync(OUTPUT_FILE, JSON.stringify(allArticles, null, 2));
  console.log(`\n✅ SCRAPING COMPLETE!`);
  console.log(`📊 Total articles: ${allArticles.length}`);
  console.log(`📁 Saved to: ${OUTPUT_FILE}`);

  // Summary by brand
  const brandCounts = {};
  for (const a of allArticles) {
    brandCounts[a.brand] = (brandCounts[a.brand] || 0) + 1;
  }
  const topBrands = Object.entries(brandCounts).sort((a, b) => b[1] - a[1]).slice(0, 20);
  console.log('\n🏆 Top Brands:');
  for (const [brand, count] of topBrands) {
    console.log(`  ${brand}: ${count}`);
  }
}

scrapeAll().catch(console.error);
