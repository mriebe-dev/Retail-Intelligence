CREATE TABLE `luxury_news` (
	`id` int AUTO_INCREMENT NOT NULL,
	`url_hash` varchar(64) NOT NULL,
	`brand_name` varchar(255) NOT NULL,
	`city` varchar(255) NOT NULL,
	`country` varchar(255) NOT NULL,
	`street` text,
	`date` varchar(10) NOT NULL,
	`source` varchar(255) NOT NULL,
	`link` text NOT NULL,
	`description` text NOT NULL,
	`latitude` varchar(20),
	`longitude` varchar(20),
	`photo_url` text,
	`status` enum('new','archived','featured') NOT NULL DEFAULT 'new',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `luxury_news_id` PRIMARY KEY(`id`),
	CONSTRAINT `luxury_news_url_hash_unique` UNIQUE(`url_hash`)
);
--> statement-breakpoint
CREATE TABLE `store_photos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`store_id` int NOT NULL,
	`photo_url` text NOT NULL,
	`photo_type` enum('street_view','brand_logo') NOT NULL,
	`description` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `store_photos_id` PRIMARY KEY(`id`)
);
