ALTER TABLE `luxury_news` ADD `opening_hours` text;--> statement-breakpoint
ALTER TABLE `luxury_news` ADD `square_meters` int;