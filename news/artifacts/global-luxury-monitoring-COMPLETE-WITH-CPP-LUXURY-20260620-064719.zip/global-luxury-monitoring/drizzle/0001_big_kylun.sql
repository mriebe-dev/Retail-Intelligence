CREATE TABLE `luxury_stores` (
	`id` int AUTO_INCREMENT NOT NULL,
	`date` varchar(10) NOT NULL,
	`brand_name` varchar(255) NOT NULL,
	`city` varchar(255) NOT NULL,
	`country` varchar(255) NOT NULL,
	`location_address` text,
	`news_type` varchar(100) NOT NULL,
	`summary` text,
	`source_name` varchar(255),
	`source_url` text,
	`partners` text,
	`latitude` varchar(20),
	`longitude` varchar(20),
	`image_url` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `luxury_stores_id` PRIMARY KEY(`id`)
);
