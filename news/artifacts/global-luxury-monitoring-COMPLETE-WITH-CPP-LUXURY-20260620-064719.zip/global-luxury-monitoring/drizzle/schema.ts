import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Luxury Retail Store Locations table
 * Stores information about luxury brand store openings, relocations, and closures
 */
export const luxuryStores = mysqlTable("luxury_stores", {
  id: int("id").autoincrement().primaryKey(),
  /** Date of the news/opening (YYYY-MM-DD) */
  date: varchar("date", { length: 10 }).notNull(),
  /** Brand name (e.g., 'Zegna', 'Louis Vuitton') */
  brandName: varchar("brand_name", { length: 255 }).notNull(),
  /** City (e.g., 'Zurich', 'Geneva', 'Paris') */
  city: varchar("city", { length: 255 }).notNull(),
  /** Country (e.g., 'Switzerland', 'France') */
  country: varchar("country", { length: 255 }).notNull(),
  /** Street address or location (e.g., 'Bahnhofstrasse 52') */
  locationAddress: text("location_address"),
  /** Type of news: 'New Opening', 'Relocation', 'Closure', 'Deal' */
  newsType: varchar("news_type", { length: 100 }).notNull(),
  /** Summary of the news including partners (architects, brokers) */
  summary: text("summary"),
  /** Source name (e.g., 'LinkedIn (Retail Journal)', 'Savills Report') */
  sourceName: varchar("source_name", { length: 255 }),
  /** URL to the source */
  sourceUrl: text("source_url"),
  /** Partner names (architects, project managers, brokers) */
  partners: text("partners"),
  /** Latitude for map integration */
  latitude: varchar("latitude", { length: 20 }),
  /** Longitude for map integration */
  longitude: varchar("longitude", { length: 20 }),
  /** Image URL for the store */
  imageUrl: text("image_url"),
  /** Created timestamp */
  createdAt: timestamp("created_at").defaultNow().notNull(),
  /** Updated timestamp */
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type LuxuryStore = typeof luxuryStores.$inferSelect;
export type InsertLuxuryStore = typeof luxuryStores.$inferInsert;

/**
 * Luxury News Archive table
 * Stores all luxury retail news with automatic collection and deduplication
 */
export const luxuryNews = mysqlTable("luxury_news", {
  id: int("id").autoincrement().primaryKey(),
  /** Unique hash of the source URL to prevent duplicates */
  urlHash: varchar("url_hash", { length: 64 }).notNull().unique(),
  /** Brand name (e.g., 'Louis Vuitton', 'Chanel') */
  brandName: varchar("brand_name", { length: 255 }).notNull(),
  /** City (e.g., 'Zurich', 'Paris', 'New York') */
  city: varchar("city", { length: 255 }).notNull(),
  /** Country (e.g., 'Switzerland', 'France', 'USA') */
  country: varchar("country", { length: 255 }).notNull(),
  /** Street address or location */
  street: text("street"),
  /** Date of the news/opening (YYYY-MM-DD) */
  date: varchar("date", { length: 10 }).notNull(),
  /** Source name (e.g., 'LinkedIn', 'Retail Journal', 'WWD') */
  source: varchar("source", { length: 255 }).notNull(),
  /** Direct link to the news source */
  link: text("link").notNull(),
  /** News description in English */
  description: text("description").notNull(),
  /** Latitude for map integration */
  latitude: varchar("latitude", { length: 20 }),
  /** Longitude for map integration */
  longitude: varchar("longitude", { length: 20 }),
  /** Photo URL for the store/location */
  photoUrl: text("photo_url"),
  /** Opening hours (JSON format: {mon: "09:00-18:00", ...}) */
  openingHours: text("opening_hours"),
  /** Store size in square meters */
  squareMeters: int("square_meters"),
  /** Status: 'new', 'archived', 'featured' */
  status: mysqlEnum("status", ["new", "archived", "featured"]).default("new").notNull(),
  /** Category: 'Fashion', 'Watches', 'Jewelry', 'Home', 'Other' */
  category: mysqlEnum("category", ["Fashion", "Watches", "Jewelry", "Home", "Other"]).default("Other").notNull(),
  /** Created timestamp */
  createdAt: timestamp("created_at").defaultNow().notNull(),
  /** Updated timestamp */
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type LuxuryNews = typeof luxuryNews.$inferSelect;
export type InsertLuxuryNews = typeof luxuryNews.$inferInsert;

/**
 * Store Photos table
 * Stores Street-View and brand logo photos for each store
 */
export const storePhotos = mysqlTable("store_photos", {
  id: int("id").autoincrement().primaryKey(),
  /** Reference to luxury_stores table */
  storeId: int("store_id").notNull(),
  /** Photo URL (stored in S3) */
  photoUrl: text("photo_url").notNull(),
  /** Photo type: 'street_view' or 'brand_logo' */
  photoType: mysqlEnum("photo_type", ["street_view", "brand_logo"]).notNull(),
  /** Photo description */
  description: text("description"),
  /** Created timestamp */
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type StorePhoto = typeof storePhotos.$inferSelect;
export type InsertStorePhoto = typeof storePhotos.$inferInsert;

/**
 * Investment Deals table
 * Tracks luxury real estate investment transactions and property sales
 */
export const investmentDeals = mysqlTable('investment_deals', {
  id: int('id').autoincrement().primaryKey(),
  urlHash: varchar('url_hash', { length: 64 }).notNull().unique(),
  propertyName: varchar('property_name', { length: 255 }).notNull(),
  brandName: varchar('brand_name', { length: 255 }).notNull(),
  city: varchar('city', { length: 255 }).notNull(),
  country: varchar('country', { length: 255 }).notNull(),
  street: text('street'),
  dealDate: varchar('deal_date', { length: 10 }).notNull(),
  completionDate: varchar('completion_date', { length: 10 }),
  dealType: mysqlEnum('deal_type', ['Sale', 'Lease', 'Development', 'Renovation', 'Acquisition']).notNull(),
  dealValue: int('deal_value'),
  currency: varchar('currency', { length: 3 }),
  squareMeters: int('square_meters'),
  seller: varchar('seller', { length: 255 }),
  buyer: varchar('buyer', { length: 255 }),
  terms: text('terms'),
  irr: int('irr'),
  description: text('description'),
  source: varchar('source', { length: 255 }).notNull(),
  link: text('link').notNull(),
  photoUrl: text('photo_url'),
  latitude: varchar('latitude', { length: 20 }),
  longitude: varchar('longitude', { length: 20 }),
  status: mysqlEnum('status', ['active', 'completed', 'archived']).default('active').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow().notNull(),
});

export type InvestmentDeal = typeof investmentDeals.$inferSelect;
export type InsertInvestmentDeal = typeof investmentDeals.$inferInsert;