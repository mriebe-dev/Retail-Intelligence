/**
 * CPP-LUXURY.COM Scraper
 * Scrapes all store opening news from 2016-2026
 * and imports them into the luxury_news database
 */

import * as cheerio from 'cheerio';
import fs from 'fs';

const BASE_URL = 'https://cpp-luxury.com';
const DELAY_MS = 1500; // Be polite - 1.5s between requests

// Store opening keywords to filter relevant articles
const STORE_OPENING_KEYWORDS = [
  'opens', 'opening', 'new store', 'new boutique', 'new flagship',
  'launches', 'debut', 'unveils', 'inaugurates', 'new shop',
  'new location', 'expands', 'new concept store', 'pop-up',
  'new retail', 'store opening', 'boutique opening'
];

// Brand group taxonomy
const BRAND_GROUPS = {
  'LVMH': ['Louis Vuitton', 'Dior', 'Christian Dior', 'Fendi', 'Celine', 'Céline', 'Givenchy', 
            'Loewe', 'Marc Jacobs', 'Kenzo', 'Berluti', 'Loro Piana', 'Rimowa', 'Moynat',
            'Bulgari', 'Bvlgari', 'TAG Heuer', 'Hublot', 'Zenith', 'Chaumet', 'Fred',
            'Sephora', 'DFS', 'Le Bon Marché', 'Benefit', 'Make Up For Ever',
            'Acqua di Parma', 'Guerlain', 'Parfums Christian Dior', 'Givenchy Beauty'],
  'Kering': ['Gucci', 'Saint Laurent', 'Yves Saint Laurent', 'YSL', 'Bottega Veneta', 
             'Balenciaga', 'Alexander McQueen', 'Brioni', 'Boucheron', 'Pomellato',
             'DoDo', 'Qeelin', 'Kering Eyewear', 'Valentino'],
  'Richemont': ['Cartier', 'Van Cleef & Arpels', 'Piaget', 'Vacheron Constantin',
                'A. Lange & Söhne', 'IWC', 'Jaeger-LeCoultre', 'Panerai', 'Roger Dubuis',
                'Baume & Mercier', 'Officine Panerai', 'Montblanc', 'Dunhill', 'Chloé',
                'Alaïa', 'Peter Millar', 'Watchfinder'],
  'Swatch Group': ['Omega', 'Longines', 'Tissot', 'Rado', 'Hamilton', 'Swatch', 'Breguet',
                   'Blancpain', 'Glashütte Original', 'Harry Winston', 'Certina', 'Mido'],
  'Hermès': ['Hermès', 'Hermes', 'John Lobb', 'Puiforcat', 'Cristalleries Saint-Louis'],
  'Chanel': ['Chanel', 'Eres', 'Holland & Holland', 'Patek Philippe'],
  'Tapestry': ['Coach', 'Kate Spade', 'Stuart Weitzman'],
  'Capri Holdings': ['Michael Kors', 'Versace', 'Jimmy Choo'],
  'PVH': ['Calvin Klein', 'Tommy Hilfiger'],
  'Inditex': ['Zara', 'Massimo Dutti', 'Pull&Bear', 'Bershka', 'Stradivarius', 'Oysho', 'Zara Home'],
  'H&M Group': ['H&M', 'COS', 'Arket', 'Weekday', '& Other Stories', 'Monki'],
  'Luxury Independent': ['Prada', 'Miu Miu', 'Church\'s', 'Car Shoe', 'Marchesi',
                          'Burberry', 'Mulberry', 'Vivienne Westwood',
                          'Ralph Lauren', 'Polo Ralph Lauren',
                          'Tiffany & Co', 'Tiffany',
                          'Rolex', 'Tudor',
                          'Chopard', 'De Beers', 'Graff', 'Messika',
                          'Dolce & Gabbana', 'Versace', 'Prada', 'Armani', 'Giorgio Armani',
                          'Emporio Armani', 'Max Mara', 'Moncler', 'Stone Island',
                          'Brunello Cucinelli', 'Loro Piana', 'Kiton', 'Brioni',
                          'Boglioli', 'Hackett', 'Canali', 'Ermenegildo Zegna', 'Zegna',
                          'Issey Miyake', 'Comme des Garçons', 'Yohji Yamamoto',
                          'Acne Studios', 'Toteme', 'Jacquemus', 'Isabel Marant',
                          'Ami Paris', 'A.P.C.', 'Sandro', 'Maje',
                          'Sporty & Rich', 'On', 'New Balance', 'Nike', 'Adidas',
                          'SKIMS', 'Savage X Fenty']
};

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function fetchPage(url) {
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
      }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.text();
  } catch (err) {
    console.error(`Failed to fetch ${url}: ${err.message}`);
    return null;
  }
}

function isStoreOpeningArticle(title, excerpt) {
  const text = (title + ' ' + excerpt).toLowerCase();
  return STORE_OPENING_KEYWORDS.some(kw => text.includes(kw));
}

function detectBrandGroup(brandName) {
  if (!brandName) return 'Independent';
  for (const [group, brands] of Object.entries(BRAND_GROUPS)) {
    if (brands.some(b => brandName.toLowerCase().includes(b.toLowerCase()) || 
                         b.toLowerCase().includes(brandName.toLowerCase()))) {
      return group;
    }
  }
  return 'Independent';
}

async function scrapeArticle(url) {
  const html = await fetchPage(url);
  if (!html) return null;

  const $ = cheerio.load(html);
  
  // Extract article content
  const title = $('h1.entry-title, h1.post-title, h1').first().text().trim();
  const content = $('.entry-content, .post-content, article').text();
  const dateStr = $('time, .entry-date, .post-date, [datetime]').first().attr('datetime') || 
                  $('time, .entry-date, .post-date').first().text().trim();
  const imageUrl = $('article img, .entry-content img, .post-thumbnail img').first().attr('src') || 
                   $('meta[property="og:image"]').attr('content');

  // Try to extract brand, city, street from title and content
  let brandName = '';
  let city = '';
  let country = '';
  let street = '';
  let squareMeters = null;

  // Extract brand from title (usually first word(s) before "opens")
  const opensMatch = title.match(/^(.+?)\s+(?:opens|launches|unveils|debuts|inaugurates)/i);
  if (opensMatch) brandName = opensMatch[1].trim();

  // Extract city from content
  const cityPatterns = [
    /(?:in|at|on)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?),?\s+([A-Z][a-z]+)/,
    /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?),\s+([A-Z][a-z]+)/
  ];
  
  // Common city detection
  const cities = ['New York', 'London', 'Paris', 'Milan', 'Tokyo', 'Singapore', 'Dubai', 
                  'Los Angeles', 'Hong Kong', 'Shanghai', 'Beijing', 'Seoul', 'Sydney',
                  'Amsterdam', 'Vienna', 'Zurich', 'Geneva', 'Madrid', 'Barcelona',
                  'Munich', 'Berlin', 'Hamburg', 'Rome', 'Florence', 'Venice',
                  'Cannes', 'Monaco', 'Saint-Tropez', 'Courchevel', 'Gstaad', 'St. Moritz',
                  'Beverly Hills', 'Miami', 'Chicago', 'San Francisco', 'Las Vegas',
                  'Aspen', 'Palm Beach', 'Scottsdale', 'Houston', 'Dallas', 'Atlanta',
                  'Toronto', 'Vancouver', 'Mexico City', 'São Paulo', 'Buenos Aires',
                  'Doha', 'Abu Dhabi', 'Riyadh', 'Kuwait City', 'Bahrain',
                  'Bangkok', 'Jakarta', 'Kuala Lumpur', 'Mumbai', 'Delhi', 'Bangalore'];
  
  for (const c of cities) {
    if (content.includes(c) || title.includes(c)) {
      city = c;
      break;
    }
  }

  // Country detection
  const countryMap = {
    'New York': 'USA', 'Los Angeles': 'USA', 'Beverly Hills': 'USA', 'Miami': 'USA',
    'Chicago': 'USA', 'San Francisco': 'USA', 'Las Vegas': 'USA', 'Aspen': 'USA',
    'Palm Beach': 'USA', 'Houston': 'USA', 'Dallas': 'USA', 'Atlanta': 'USA',
    'London': 'UK', 'Manchester': 'UK', 'Edinburgh': 'UK',
    'Paris': 'France', 'Cannes': 'France', 'Monaco': 'Monaco', 'Saint-Tropez': 'France',
    'Milan': 'Italy', 'Rome': 'Italy', 'Florence': 'Italy', 'Venice': 'Italy',
    'Tokyo': 'Japan', 'Osaka': 'Japan', 'Kyoto': 'Japan',
    'Singapore': 'Singapore', 'Hong Kong': 'Hong Kong',
    'Shanghai': 'China', 'Beijing': 'China', 'Shenzhen': 'China',
    'Seoul': 'South Korea', 'Busan': 'South Korea',
    'Dubai': 'UAE', 'Abu Dhabi': 'UAE', 'Doha': 'Qatar',
    'Amsterdam': 'Netherlands', 'Rotterdam': 'Netherlands',
    'Vienna': 'Austria', 'Zurich': 'Switzerland', 'Geneva': 'Switzerland',
    'Gstaad': 'Switzerland', 'St. Moritz': 'Switzerland',
    'Madrid': 'Spain', 'Barcelona': 'Spain',
    'Munich': 'Germany', 'Berlin': 'Germany', 'Hamburg': 'Germany',
    'Bangkok': 'Thailand', 'Jakarta': 'Indonesia', 'Kuala Lumpur': 'Malaysia',
    'Mumbai': 'India', 'Delhi': 'India', 'Bangalore': 'India',
    'Toronto': 'Canada', 'Vancouver': 'Canada',
    'Sydney': 'Australia', 'Melbourne': 'Australia',
    'São Paulo': 'Brazil', 'Buenos Aires': 'Argentina',
    'Mexico City': 'Mexico', 'Courchevel': 'France'
  };
  if (city && countryMap[city]) country = countryMap[city];

  // Extract square meters
  const sqmMatch = content.match(/(\d[\d,]+)\s*(?:sq\.?\s*m|sqm|m²|square\s+meters?|square\s+metres?)/i);
  if (sqmMatch) squareMeters = parseInt(sqmMatch[1].replace(',', ''));

  // Extract street address
  const streetPatterns = [
    /(\d+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*(?:\s+(?:Street|Avenue|Boulevard|Road|Lane|Drive|Place|Way|Rue|Via|Corso|Strasse|Straße|Gasse|Platz))?)/,
    /((?:Fifth|Madison|Park|Lexington|Broadway|Bond|Oxford|Regent|Sloane|King's Road|Champs-Élysées|Rue du Faubourg|Via Montenapoleone|Bahnhofstrasse|Kurfürstendamm|P\.C\. Hooftstraat)[^,\.]*)/i
  ];
  for (const pattern of streetPatterns) {
    const match = content.match(pattern);
    if (match) { street = match[1].trim(); break; }
  }

  // Detect brand group
  const brandGroup = detectBrandGroup(brandName);

  return {
    title,
    brandName,
    brandGroup,
    city,
    country,
    street,
    squareMeters,
    date: dateStr ? new Date(dateStr).toISOString().split('T')[0] : null,
    link: url,
    description: title,
    source: 'CPP-LUXURY',
    photoUrl: imageUrl || null,
    status: 'new',
    category: 'Fashion'
  };
}

async function scrapeAllPages() {
  const allArticles = [];
  let pageUrl = `${BASE_URL}/news/`;
  let pageNum = 1;
  const maxPages = 500; // 10 years of news = ~500 pages

  console.log('Starting CPP-LUXURY scraping...');

  while (pageUrl && pageNum <= maxPages) {
    console.log(`Scraping page ${pageNum}: ${pageUrl}`);
    
    const html = await fetchPage(pageUrl);
    if (!html) break;

    const $ = cheerio.load(html);
    
    // Find all article links on this page
    const articleLinks = [];
    $('h2 a, h3 a, .entry-title a, .post-title a').each((i, el) => {
      const href = $(el).attr('href');
      const title = $(el).text().trim();
      const excerpt = $(el).closest('article, .post').find('.entry-summary, .post-excerpt, p').first().text();
      
      if (href && href.includes('cpp-luxury.com') && isStoreOpeningArticle(title, excerpt)) {
        articleLinks.push({ href, title });
      }
    });

    console.log(`  Found ${articleLinks.length} store opening articles on page ${pageNum}`);

    // Scrape each article
    for (const { href, title } of articleLinks) {
      console.log(`  Scraping: ${title.substring(0, 60)}...`);
      const article = await scrapeArticle(href);
      if (article && article.brandName && article.city) {
        allArticles.push(article);
        console.log(`    ✓ ${article.brandName} - ${article.city}, ${article.country}`);
      }
      await sleep(DELAY_MS);
    }

    // Find next page
    const olderPostsLink = $('a:contains("Older Posts"), a.next, a[rel="next"], .nav-previous a').attr('href');
    pageUrl = olderPostsLink || null;
    pageNum++;

    await sleep(DELAY_MS);
  }

  return allArticles;
}

// Main execution
console.log('CPP-LUXURY Store Opening Scraper');
console.log('================================');

const articles = await scrapeAllPages();

console.log(`\nTotal articles found: ${articles.length}`);

// Save to JSON file for import
fs.writeFileSync('/home/ubuntu/global-luxury-monitoring/cpp-luxury-scraped.json', 
  JSON.stringify(articles, null, 2));

console.log('Saved to cpp-luxury-scraped.json');

// Print summary
const byCity = {};
const byBrand = {};
const byGroup = {};

for (const a of articles) {
  if (a.city) byCity[a.city] = (byCity[a.city] || 0) + 1;
  if (a.brandName) byBrand[a.brandName] = (byBrand[a.brandName] || 0) + 1;
  if (a.brandGroup) byGroup[a.brandGroup] = (byGroup[a.brandGroup] || 0) + 1;
}

console.log('\nTop Cities:');
Object.entries(byCity).sort((a,b) => b[1]-a[1]).slice(0,10).forEach(([c,n]) => console.log(`  ${c}: ${n}`));

console.log('\nTop Brands:');
Object.entries(byBrand).sort((a,b) => b[1]-a[1]).slice(0,10).forEach(([b,n]) => console.log(`  ${b}: ${n}`));

console.log('\nBrand Groups:');
Object.entries(byGroup).sort((a,b) => b[1]-a[1]).forEach(([g,n]) => console.log(`  ${g}: ${n}`));
