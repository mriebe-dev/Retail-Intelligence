/**
 * CPP-LUXURY.COM Scraper v2
 * Fixed selectors based on actual HTML structure analysis
 */

import * as cheerio from 'cheerio';
import fs from 'fs';

const BASE_URL = 'https://cpp-luxury.com';
const DELAY_MS = 1200;

// Store opening keywords
const STORE_KEYWORDS = [
  'opens', 'opening', 'new store', 'new boutique', 'new flagship',
  'launches', 'debut', 'unveils', 'inaugurates', 'new shop',
  'new location', 'new concept store', 'pop-up', 'store opening',
  'boutique opening', 'new retail', 'new space', 'new outlet'
];

// Brand group taxonomy
const BRAND_GROUPS = {
  'LVMH': ['Louis Vuitton', 'Dior', 'Christian Dior', 'Fendi', 'Celine', 'Céline', 'Givenchy',
            'Loewe', 'Marc Jacobs', 'Kenzo', 'Berluti', 'Loro Piana', 'Rimowa', 'Moynat',
            'Bulgari', 'Bvlgari', 'TAG Heuer', 'Hublot', 'Zenith', 'Chaumet', 'Fred',
            'Sephora', 'Guerlain', 'Acqua di Parma'],
  'Kering': ['Gucci', 'Saint Laurent', 'Yves Saint Laurent', 'YSL', 'Bottega Veneta',
             'Balenciaga', 'Alexander McQueen', 'Brioni', 'Boucheron', 'Pomellato',
             'Qeelin', 'Valentino'],
  'Richemont': ['Cartier', 'Van Cleef & Arpels', 'Piaget', 'Vacheron Constantin',
                'A. Lange & Söhne', 'IWC', 'Jaeger-LeCoultre', 'Panerai', 'Roger Dubuis',
                'Baume & Mercier', 'Montblanc', 'Dunhill', 'Chloé', 'Alaïa'],
  'Swatch Group': ['Omega', 'Longines', 'Tissot', 'Rado', 'Hamilton', 'Swatch', 'Breguet',
                   'Blancpain', 'Harry Winston'],
  'Hermès': ['Hermès', 'Hermes'],
  'Chanel': ['Chanel'],
  'Tapestry': ['Coach', 'Kate Spade', 'Stuart Weitzman'],
  'Capri Holdings': ['Michael Kors', 'Versace', 'Jimmy Choo'],
  'H&M Group': ['H&M', 'COS', 'Arket', 'Weekday', '& Other Stories', 'Monki'],
  'Inditex': ['Zara', 'Massimo Dutti'],
};

const CITY_COUNTRY_MAP = {
  'New York': 'USA', 'Los Angeles': 'USA', 'Beverly Hills': 'USA', 'Miami': 'USA',
  'Chicago': 'USA', 'San Francisco': 'USA', 'Las Vegas': 'USA', 'Aspen': 'USA',
  'Palm Beach': 'USA', 'Houston': 'USA', 'Dallas': 'USA', 'Atlanta': 'USA',
  'Scottsdale': 'USA', 'Nashville': 'USA', 'Boston': 'USA', 'Seattle': 'USA',
  'London': 'UK', 'Manchester': 'UK', 'Edinburgh': 'UK',
  'Paris': 'France', 'Cannes': 'France', 'Nice': 'France', 'Lyon': 'France',
  'Saint-Tropez': 'France', 'Courchevel': 'France', 'Megève': 'France',
  'Monaco': 'Monaco',
  'Milan': 'Italy', 'Rome': 'Italy', 'Florence': 'Italy', 'Venice': 'Italy',
  'Naples': 'Italy', 'Turin': 'Italy',
  'Tokyo': 'Japan', 'Osaka': 'Japan', 'Kyoto': 'Japan', 'Nagoya': 'Japan',
  'Singapore': 'Singapore',
  'Hong Kong': 'Hong Kong',
  'Shanghai': 'China', 'Beijing': 'China', 'Shenzhen': 'China', 'Chengdu': 'China',
  'Hangzhou': 'China', 'Guangzhou': 'China', 'Wuhan': 'China',
  'Seoul': 'South Korea', 'Busan': 'South Korea',
  'Dubai': 'UAE', 'Abu Dhabi': 'UAE',
  'Doha': 'Qatar', 'Riyadh': 'Saudi Arabia', 'Kuwait City': 'Kuwait',
  'Amsterdam': 'Netherlands', 'Rotterdam': 'Netherlands', 'The Hague': 'Netherlands',
  'Vienna': 'Austria',
  'Zurich': 'Switzerland', 'Geneva': 'Switzerland', 'Basel': 'Switzerland',
  'Gstaad': 'Switzerland', 'St. Moritz': 'Switzerland', 'Zermatt': 'Switzerland',
  'Madrid': 'Spain', 'Barcelona': 'Spain', 'Marbella': 'Spain', 'Ibiza': 'Spain',
  'Munich': 'Germany', 'Berlin': 'Germany', 'Hamburg': 'Germany', 'Frankfurt': 'Germany',
  'Düsseldorf': 'Germany', 'Cologne': 'Germany', 'Stuttgart': 'Germany',
  'Brussels': 'Belgium', 'Antwerp': 'Belgium',
  'Copenhagen': 'Denmark', 'Stockholm': 'Sweden', 'Oslo': 'Norway', 'Helsinki': 'Finland',
  'Warsaw': 'Poland', 'Prague': 'Czech Republic', 'Budapest': 'Hungary',
  'Bangkok': 'Thailand', 'Jakarta': 'Indonesia', 'Kuala Lumpur': 'Malaysia',
  'Mumbai': 'India', 'Delhi': 'India', 'Bangalore': 'India',
  'Toronto': 'Canada', 'Vancouver': 'Canada', 'Montreal': 'Canada',
  'Sydney': 'Australia', 'Melbourne': 'Australia',
  'São Paulo': 'Brazil', 'Rio de Janeiro': 'Brazil',
  'Buenos Aires': 'Argentina', 'Mexico City': 'Mexico',
  'Taipei': 'Taiwan', 'Macau': 'Macau',
  'Lisbon': 'Portugal', 'Porto': 'Portugal',
  'Athens': 'Greece', 'Istanbul': 'Turkey',
  'Tel Aviv': 'Israel', 'Beirut': 'Lebanon',
  'Cape Town': 'South Africa', 'Johannesburg': 'South Africa',
  'Nairobi': 'Kenya', 'Lagos': 'Nigeria',
};

const ALL_CITIES = Object.keys(CITY_COUNTRY_MAP);

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function fetchPage(url) {
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'en-US,en;q=0.9',
      }
    });
    if (!response.ok) return null;
    return await response.text();
  } catch {
    return null;
  }
}

function isStoreOpening(title) {
  const t = title.toLowerCase();
  return STORE_KEYWORDS.some(kw => t.includes(kw));
}

function detectBrandGroup(brandName) {
  if (!brandName) return 'Independent';
  for (const [group, brands] of Object.entries(BRAND_GROUPS)) {
    if (brands.some(b => brandName.toLowerCase().includes(b.toLowerCase()) ||
                         b.toLowerCase().includes(brandName.toLowerCase()))) {
      return group;
    }
  }
  return 'Independent';
}

function extractFromTitle(title) {
  // "Brand opens/launches/debuts in City"
  const patterns = [
    /^(.+?)\s+(?:opens?|launches?|unveils?|debuts?|inaugurates?)\s+(?:new\s+)?(?:flagship\s+)?(?:boutique|store|shop|concept|space|location)?\s*(?:in|at|on)\s+(.+)/i,
    /^(.+?)\s+(?:opens?|launches?|debuts?)\s+(?:in|at)\s+(.+)/i,
    /^(.+?)\s+(?:new\s+)?(?:flagship|boutique|store|shop)\s+(?:in|at|on)\s+(.+)/i,
  ];

  for (const pattern of patterns) {
    const m = title.match(pattern);
    if (m) {
      const brandRaw = m[1].trim();
      const locationRaw = m[2].trim().replace(/[,\.]+$/, '');
      return { brandName: brandRaw, locationHint: locationRaw };
    }
  }
  return { brandName: '', locationHint: '' };
}

function detectCity(text) {
  for (const city of ALL_CITIES) {
    if (text.includes(city)) return city;
  }
  return '';
}

async function scrapeArticle(url, titleHint) {
  const html = await fetchPage(url);
  if (!html) return null;

  const $ = cheerio.load(html);

  const title = $('h1').first().text().trim() || titleHint;
  const content = $('.entry-content, .post-content, article .content, .single-content').text() || $('article').text();
  const dateEl = $('time[datetime]').first();
  const dateStr = dateEl.attr('datetime') || dateEl.text().trim();
  const imageUrl = $('meta[property="og:image"]').attr('content') ||
                   $('.entry-content img, .post-thumbnail img').first().attr('src');

  const { brandName, locationHint } = extractFromTitle(title);

  // Detect city from content + title + location hint
  const fullText = title + ' ' + content + ' ' + locationHint;
  const city = detectCity(fullText);
  const country = city ? (CITY_COUNTRY_MAP[city] || '') : '';

  // Extract square meters
  const sqmMatch = content.match(/(\d[\d,]+)\s*(?:sq\.?\s*m|sqm|m²|square\s+m(?:eters?|etres?))/i);
  const squareMeters = sqmMatch ? parseInt(sqmMatch[1].replace(',', '')) : null;

  // Extract street
  let street = '';
  const streetPatterns = [
    /((?:Fifth|Madison|Park|Lexington|Rodeo|Melrose|Sunset|Wilshire|Bond|Oxford|Regent|Sloane|King's Road|Champs-Élysées|Rue du Faubourg Saint-Honoré|Rue Saint-Honoré|Avenue Montaigne|Via Montenapoleone|Via della Spiga|Corso Vittorio|Bahnhofstrasse|Kurfürstendamm|P\.C\. Hooftstraat|Kalverstraat|Lijnbaan|Ginza|Omotesando|Orchard Road|Nanjing Road)[^,\.\n]*)/i,
    /(\d+\s+(?:Fifth|Madison|Park|Lexington|Bond|Oxford|Regent|Sloane|Rodeo|Melrose)[^,\.\n]*)/i,
  ];
  for (const p of streetPatterns) {
    const m = content.match(p) || title.match(p);
    if (m) { street = m[1].trim().substring(0, 100); break; }
  }

  const urlHash = Buffer.from(url).toString('base64').substring(0, 64);

  return {
    urlHash,
    brandName: brandName || titleHint.split(' ')[0],
    brandGroup: detectBrandGroup(brandName),
    city,
    country,
    street,
    squareMeters,
    date: dateStr ? (() => { try { return new Date(dateStr).toISOString().split('T')[0]; } catch { return null; } })() : null,
    link: url,
    description: title,
    source: 'CPP-LUXURY',
    photoUrl: imageUrl || null,
    status: 'new',
    category: 'Fashion'
  };
}

async function scrapeAllPages() {
  const allArticles = [];
  const seenUrls = new Set();
  let pageNum = 1;
  const maxPages = 600; // ~10 years

  console.log('CPP-LUXURY Store Opening Scraper v2');
  console.log('=====================================');

  while (pageNum <= maxPages) {
    const pageUrl = pageNum === 1
      ? `${BASE_URL}/news/`
      : `${BASE_URL}/news/page/${pageNum}/`;

    console.log(`Page ${pageNum}: ${pageUrl}`);

    const html = await fetchPage(pageUrl);
    if (!html) {
      console.log('  Failed to fetch - stopping');
      break;
    }

    const $ = cheerio.load(html);

    // Check if page exists (404 detection)
    if ($('body').text().includes('Page not found') || $('body').text().includes('404')) {
      console.log('  Page not found - reached end');
      break;
    }

    // Find all article links - CPP-LUXURY uses direct <a> links
    const articleLinks = [];
    $('a[href*="cpp-luxury.com"]').each((i, el) => {
      const href = $(el).attr('href');
      const text = $(el).text().trim();
      // Filter: article links have meaningful text, not navigation
      if (href && text.length > 20 && text.length < 200 &&
          !href.includes('/news/') && !href.includes('/page/') &&
          !href.includes('/category/') && !href.includes('/tag/') &&
          !seenUrls.has(href) && isStoreOpening(text)) {
        seenUrls.add(href);
        articleLinks.push({ href, title: text });
      }
    });

    console.log(`  Found ${articleLinks.length} store opening articles`);

    for (const { href, title } of articleLinks) {
      process.stdout.write(`  Scraping: ${title.substring(0, 55)}... `);
      const article = await scrapeArticle(href, title);
      if (article) {
        allArticles.push(article);
        console.log(`✓ ${article.brandName || '?'} - ${article.city || '?'}`);
      } else {
        console.log('✗ failed');
      }
      await sleep(DELAY_MS);
    }

    // Check for next page
    const hasOlderPosts = $('a:contains("Older Posts"), a.next, a[rel="next"]').length > 0;
    if (!hasOlderPosts && articleLinks.length === 0) {
      console.log('  No more pages');
      break;
    }

    pageNum++;
    await sleep(DELAY_MS);

    // Save progress every 10 pages
    if (pageNum % 10 === 0) {
      fs.writeFileSync('/home/ubuntu/global-luxury-monitoring/cpp-luxury-scraped.json',
        JSON.stringify(allArticles, null, 2));
      console.log(`\n--- Progress saved: ${allArticles.length} articles ---\n`);
    }
  }

  return allArticles;
}

const articles = await scrapeAllPages();

console.log(`\n✅ Total store opening articles found: ${articles.length}`);

// Save final results
fs.writeFileSync('/home/ubuntu/global-luxury-monitoring/cpp-luxury-scraped.json',
  JSON.stringify(articles, null, 2));

// Summary stats
const byCity = {}, byGroup = {};
for (const a of articles) {
  if (a.city) byCity[a.city] = (byCity[a.city] || 0) + 1;
  if (a.brandGroup) byGroup[a.brandGroup] = (byGroup[a.brandGroup] || 0) + 1;
}

console.log('\nTop Cities:');
Object.entries(byCity).sort((a,b) => b[1]-a[1]).slice(0,15)
  .forEach(([c,n]) => console.log(`  ${c}: ${n}`));

console.log('\nBrand Groups:');
Object.entries(byGroup).sort((a,b) => b[1]-a[1])
  .forEach(([g,n]) => console.log(`  ${g}: ${n}`));

console.log('\nSaved to cpp-luxury-scraped.json');
