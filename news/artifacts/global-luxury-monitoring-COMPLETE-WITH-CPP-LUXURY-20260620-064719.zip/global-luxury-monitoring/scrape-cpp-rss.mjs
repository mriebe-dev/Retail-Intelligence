/**
 * CPP-LUXURY RSS Feed Scraper
 * Uses RSS feed pagination for fast, reliable scraping
 * RSS feed: https://cpp-luxury.com/feed/?paged=N
 */

import * as fs from 'fs';

const RSS_BASE = 'https://cpp-luxury.com/feed/';
const OUTPUT_FILE = '/home/ubuntu/global-luxury-monitoring/cpp-luxury-scraped.json';
const CONCURRENT = 8;
const DELAY_MS = 200;

// Opening keywords
const OPENING_KEYWORDS = [
  'opens', 'opening', 'open', 'launch', 'launches', 'debut', 'debuts',
  'new boutique', 'new store', 'new flagship', 'new shop', 'new location',
  'unveils', 'inaugurates', 'new pop-up', 'new concept', 'expands',
  'relocates', 'reopens', 'reopen', 'new maison', 'new space',
  'grand opening', 'store opening', 'boutique opening',
];

const LUXURY_BRANDS = [
  'Louis Vuitton', 'Dior', 'Fendi', 'Celine', 'Céline', 'Givenchy', 'Loewe',
  'Marc Jacobs', 'Kenzo', 'Berluti', 'Loro Piana', 'Rimowa', 'Bulgari', 'Bvlgari',
  'TAG Heuer', 'Hublot', 'Zenith', 'Chaumet', 'Guerlain', 'Acqua di Parma',
  'Gucci', 'Saint Laurent', 'YSL', 'Bottega Veneta', 'Balenciaga',
  'Alexander McQueen', 'Brioni', 'Boucheron', 'Pomellato', 'Valentino',
  'Cartier', 'Van Cleef', 'Piaget', 'Vacheron', 'IWC', 'Jaeger-LeCoultre',
  'Panerai', 'Roger Dubuis', 'Baume & Mercier', 'Montblanc', 'Dunhill',
  'Chloé', 'Chloe', 'Alaïa', 'Alaia', 'Omega', 'Longines', 'Tissot', 'Rado',
  'Hamilton', 'Swatch', 'Breguet', 'Blancpain', 'Harry Winston',
  'Hermès', 'Hermes', 'Chanel', 'CHANEL', 'Prada', 'PRADA', 'Miu Miu',
  'Burberry', 'Ralph Lauren', 'Tiffany', 'Rolex', 'Chopard', 'De Beers',
  'Graff', 'Messika', 'Dolce & Gabbana', 'Giorgio Armani', 'Armani',
  'Max Mara', 'Moncler', 'Brunello Cucinelli', 'Zegna', 'Boglioli',
  'Hackett', 'Issey Miyake', 'ISSEY MIYAKE', 'Jacquemus', 'Acne Studios',
  'SKIMS', 'On Running', 'New Balance', 'Sporty & Rich', 'Arc\'teryx',
  'Arcteryx', 'Ami Paris', 'Rick Owens', 'Bolia', 'BOLIA', 'Arket',
  'COS', 'Zara', 'Massimo Dutti', 'Coach', 'Kate Spade', 'Versace',
  'Jimmy Choo', 'Michael Kors', 'Tory Burch', 'Zimmermann', 'Ganni',
  'Toteme', 'Loewe', 'Ferragamo', 'Salvatore Ferragamo', 'Tod\'s', 'Tods',
  'Roger Vivier', 'Manolo Blahnik', 'Christian Louboutin', 'Louboutin',
  'Giuseppe Zanotti', 'Stuart Weitzman', 'Aquazzura', 'Gianvito Rossi',
  'Bally', 'Church\'s', 'John Lobb', 'Santoni', 'Patek Philippe',
  'Audemars Piguet', 'A. Lange', 'F.P. Journe', 'Richard Mille',
  'Aesop', 'L\'Occitane', 'Diptyque', 'Jo Malone', 'Penhaligon\'s',
  'Creed', 'Byredo', 'Le Labo', 'Maison Margiela', 'Kilian',
  'La Prairie', 'La Mer', 'SK-II', 'Shiseido', 'Charlotte Tilbury',
  'Fenty Beauty', 'Rare Beauty', 'Glossier', 'Miniso', 'MINISO',
  'Muji', 'MUJI', 'Uniqlo', 'UNIQLO', 'H&M', 'Mango',
  'Nike', 'Adidas', 'Puma', 'Lululemon', 'Hoka', 'Salomon',
  'The North Face', 'Patagonia', 'Mammut',
  'Galeries Lafayette', 'Printemps', 'Selfridges', 'Harrods',
  'Harvey Nichols', 'Bergdorf Goodman', 'Saks Fifth Avenue',
  'Neiman Marcus', 'Nordstrom', 'Isetan', 'Mitsukoshi',
  'Lane Crawford', 'Joyce', 'Beymen', 'Vakko',
  'Ami', 'Jacquemus', 'Nanushka', 'Ganni', 'Staud',
  'Repossi', 'Tasaki', 'Mikimoto', 'Boodles', 'Garrard', 'Asprey',
  'Jacques Marie Mage', 'Amouage', 'La DoubleJ', 'Zimmermann',
];

const CITIES = [
  'New York', 'Los Angeles', 'Beverly Hills', 'Miami', 'Chicago',
  'San Francisco', 'Las Vegas', 'Aspen', 'Palm Beach', 'East Hampton',
  'Southampton', 'Nantucket', 'Boston', 'Seattle', 'Dallas', 'Houston',
  'Atlanta', 'Washington', 'Philadelphia', 'Denver', 'Phoenix',
  'London', 'Paris', 'Milan', 'Milano', 'Rome', 'Roma', 'Florence',
  'Firenze', 'Venice', 'Venezia', 'Naples', 'Turin', 'Bologna',
  'Madrid', 'Barcelona', 'Ibiza', 'Marbella', 'Seville', 'Valencia',
  'Amsterdam', 'Rotterdam', 'The Hague', 'Utrecht', 'Antwerp',
  'Berlin', 'Munich', 'Hamburg', 'Frankfurt', 'Düsseldorf', 'Cologne',
  'Stuttgart', 'Vienna', 'Wien', 'Zurich', 'Zürich', 'Geneva', 'Genf',
  'Basel', 'Bern', 'Lausanne', 'Lugano', 'St. Moritz', 'Gstaad',
  'Zermatt', 'Verbier', 'Interlaken', 'Davos', 'Kitzbühel',
  'Brussels', 'Bruxelles', 'Ghent', 'Bruges',
  'Stockholm', 'Copenhagen', 'Oslo', 'Helsinki', 'Gothenburg',
  'Lisbon', 'Lisboa', 'Porto', 'Athens', 'Mykonos', 'Santorini',
  'Monaco', 'Cannes', 'Nice', 'Saint-Tropez', 'Courchevel', 'Megève',
  'Lyon', 'Bordeaux', 'Marseille', 'Strasbourg',
  'Tokyo', 'Osaka', 'Kyoto', 'Nagoya', 'Yokohama', 'Fukuoka',
  'Sapporo', 'Ginza', 'Shibuya', 'Shinjuku', 'Omotesando',
  'Shanghai', 'Beijing', 'Shenzhen', 'Guangzhou', 'Chengdu',
  'Hangzhou', 'Wuhan', 'Nanjing', 'Suzhou', 'Chongqing',
  'Hong Kong', 'Macau', 'Taipei', 'Seoul', 'Busan', 'Myeongdong',
  'Singapore', 'Bangkok', 'Jakarta', 'Kuala Lumpur', 'Manila',
  'Ho Chi Minh', 'Hanoi', 'Mumbai', 'Delhi', 'Bangalore', 'Chennai',
  'Dubai', 'Abu Dhabi', 'Doha', 'Riyadh', 'Jeddah', 'Kuwait City',
  'Cairo', 'Casablanca', 'Marrakech', 'Cape Town', 'Johannesburg',
  'Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Auckland',
  'Toronto', 'Vancouver', 'Montreal', 'Calgary',
  'São Paulo', 'Rio de Janeiro', 'Buenos Aires', 'Bogotá', 'Lima',
  'Mexico City', 'Monterrey', 'Guadalajara',
  'Moscow', 'St. Petersburg', 'Warsaw', 'Prague', 'Budapest',
  'Bucharest', 'Istanbul', 'Ankara', 'Tel Aviv', 'Beirut',
];

const CITY_COUNTRY = {
  'New York': 'USA', 'Los Angeles': 'USA', 'Beverly Hills': 'USA',
  'Miami': 'USA', 'Chicago': 'USA', 'San Francisco': 'USA',
  'Las Vegas': 'USA', 'Aspen': 'USA', 'Palm Beach': 'USA',
  'East Hampton': 'USA', 'Southampton': 'USA', 'Nantucket': 'USA',
  'Boston': 'USA', 'Seattle': 'USA', 'Dallas': 'USA', 'Houston': 'USA',
  'Atlanta': 'USA', 'Washington': 'USA', 'Philadelphia': 'USA',
  'Denver': 'USA', 'Phoenix': 'USA',
  'London': 'UK', 'Paris': 'France', 'Cannes': 'France', 'Nice': 'France',
  'Saint-Tropez': 'France', 'Courchevel': 'France', 'Lyon': 'France',
  'Bordeaux': 'France', 'Marseille': 'France', 'Strasbourg': 'France',
  'Monaco': 'Monaco',
  'Milan': 'Italy', 'Milano': 'Italy', 'Rome': 'Italy', 'Roma': 'Italy',
  'Florence': 'Italy', 'Firenze': 'Italy', 'Venice': 'Italy',
  'Venezia': 'Italy', 'Naples': 'Italy', 'Turin': 'Italy', 'Bologna': 'Italy',
  'Madrid': 'Spain', 'Barcelona': 'Spain', 'Ibiza': 'Spain',
  'Marbella': 'Spain', 'Seville': 'Spain', 'Valencia': 'Spain',
  'Amsterdam': 'Netherlands', 'Rotterdam': 'Netherlands',
  'The Hague': 'Netherlands', 'Utrecht': 'Netherlands',
  'Antwerp': 'Belgium', 'Brussels': 'Belgium', 'Bruxelles': 'Belgium',
  'Ghent': 'Belgium', 'Bruges': 'Belgium',
  'Berlin': 'Germany', 'Munich': 'Germany', 'Hamburg': 'Germany',
  'Frankfurt': 'Germany', 'Düsseldorf': 'Germany', 'Cologne': 'Germany',
  'Stuttgart': 'Germany',
  'Vienna': 'Austria', 'Wien': 'Austria',
  'Zurich': 'Switzerland', 'Zürich': 'Switzerland',
  'Geneva': 'Switzerland', 'Genf': 'Switzerland',
  'Basel': 'Switzerland', 'Bern': 'Switzerland', 'Lausanne': 'Switzerland',
  'Lugano': 'Switzerland', 'St. Moritz': 'Switzerland', 'Gstaad': 'Switzerland',
  'Zermatt': 'Switzerland', 'Verbier': 'Switzerland', 'Interlaken': 'Switzerland',
  'Davos': 'Switzerland', 'Kitzbühel': 'Austria',
  'Stockholm': 'Sweden', 'Gothenburg': 'Sweden',
  'Copenhagen': 'Denmark', 'Oslo': 'Norway', 'Helsinki': 'Finland',
  'Lisbon': 'Portugal', 'Lisboa': 'Portugal', 'Porto': 'Portugal',
  'Athens': 'Greece', 'Mykonos': 'Greece', 'Santorini': 'Greece',
  'Tokyo': 'Japan', 'Osaka': 'Japan', 'Kyoto': 'Japan',
  'Nagoya': 'Japan', 'Yokohama': 'Japan', 'Fukuoka': 'Japan',
  'Sapporo': 'Japan', 'Ginza': 'Japan', 'Shibuya': 'Japan',
  'Shinjuku': 'Japan', 'Omotesando': 'Japan',
  'Shanghai': 'China', 'Beijing': 'China', 'Shenzhen': 'China',
  'Guangzhou': 'China', 'Chengdu': 'China', 'Hangzhou': 'China',
  'Wuhan': 'China', 'Nanjing': 'China', 'Suzhou': 'China', 'Chongqing': 'China',
  'Hong Kong': 'Hong Kong', 'Macau': 'Macau', 'Taipei': 'Taiwan',
  'Seoul': 'South Korea', 'Busan': 'South Korea', 'Myeongdong': 'South Korea',
  'Singapore': 'Singapore', 'Bangkok': 'Thailand',
  'Jakarta': 'Indonesia', 'Kuala Lumpur': 'Malaysia', 'Manila': 'Philippines',
  'Ho Chi Minh': 'Vietnam', 'Hanoi': 'Vietnam',
  'Mumbai': 'India', 'Delhi': 'India', 'Bangalore': 'India', 'Chennai': 'India',
  'Dubai': 'UAE', 'Abu Dhabi': 'UAE', 'Doha': 'Qatar',
  'Riyadh': 'Saudi Arabia', 'Jeddah': 'Saudi Arabia', 'Kuwait City': 'Kuwait',
  'Cairo': 'Egypt', 'Casablanca': 'Morocco', 'Marrakech': 'Morocco',
  'Cape Town': 'South Africa', 'Johannesburg': 'South Africa',
  'Sydney': 'Australia', 'Melbourne': 'Australia', 'Brisbane': 'Australia',
  'Perth': 'Australia', 'Auckland': 'New Zealand',
  'Toronto': 'Canada', 'Vancouver': 'Canada', 'Montreal': 'Canada', 'Calgary': 'Canada',
  'São Paulo': 'Brazil', 'Rio de Janeiro': 'Brazil',
  'Buenos Aires': 'Argentina', 'Bogotá': 'Colombia', 'Lima': 'Peru',
  'Mexico City': 'Mexico', 'Monterrey': 'Mexico', 'Guadalajara': 'Mexico',
  'Moscow': 'Russia', 'St. Petersburg': 'Russia',
  'Warsaw': 'Poland', 'Prague': 'Czech Republic',
  'Budapest': 'Hungary', 'Bucharest': 'Romania',
  'Istanbul': 'Turkey', 'Ankara': 'Turkey',
  'Tel Aviv': 'Israel', 'Beirut': 'Lebanon',
};

function extractBrand(title) {
  for (const brand of LUXURY_BRANDS) {
    if (title.toLowerCase().includes(brand.toLowerCase())) {
      return brand;
    }
  }
  const firstWord = title.split(' ')[0];
  if (firstWord && firstWord.length > 2 && /^[A-Z]/.test(firstWord)) {
    return firstWord;
  }
  return title.split(' ').slice(0, 2).join(' ');
}

function extractCity(text) {
  for (const city of CITIES) {
    if (text.toLowerCase().includes(city.toLowerCase())) {
      return city;
    }
  }
  return null;
}

function isOpeningArticle(title, description) {
  const combined = (title + ' ' + description).toLowerCase();
  return OPENING_KEYWORDS.some(kw => combined.includes(kw));
}

function parseRSSDate(dateStr) {
  try {
    return new Date(dateStr).toISOString().split('T')[0];
  } catch {
    return new Date().toISOString().split('T')[0];
  }
}

function parseXMLItems(xml) {
  const items = [];
  const itemMatches = xml.matchAll(/<item>([\s\S]*?)<\/item>/g);

  for (const match of itemMatches) {
    const itemXml = match[1];

    const titleMatch = itemXml.match(/<title><!\[CDATA\[(.*?)\]\]><\/title>/) ||
                       itemXml.match(/<title>(.*?)<\/title>/);
    const linkMatch = itemXml.match(/<link>(.*?)<\/link>/);
    const dateMatch = itemXml.match(/<pubDate>(.*?)<\/pubDate>/);
    const descMatch = itemXml.match(/<description><!\[CDATA\[([\s\S]*?)\]\]><\/description>/) ||
                      itemXml.match(/<description>([\s\S]*?)<\/description>/);

    if (!titleMatch || !linkMatch) continue;

    const title = titleMatch[1].trim();
    const url = linkMatch[1].trim();
    const pubDate = dateMatch ? parseRSSDate(dateMatch[1]) : new Date().toISOString().split('T')[0];
    const description = descMatch ? descMatch[1].replace(/<[^>]+>/g, '').trim() : '';

    if (!isOpeningArticle(title, description)) continue;

    const brand = extractBrand(title);
    const city = extractCity(title + ' ' + description);
    const country = city ? (CITY_COUNTRY[city] || null) : null;

    items.push({
      title,
      url,
      brand,
      city: city || '',
      country: country || '',
      openingDate: pubDate,
      source: 'cpp-luxury.com',
      category: 'Luxury Retail',
      description: description.slice(0, 500),
    });
  }

  return items;
}

async function fetchRSSPage(pageNum) {
  const url = pageNum === 1 ? RSS_BASE : `${RSS_BASE}?paged=${pageNum}`;
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; LuxuryRetailBot/1.0)',
        'Accept': 'application/rss+xml, application/xml, text/xml',
      }
    });
    if (!response.ok) return null;
    return await response.text();
  } catch {
    return null;
  }
}

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function scrapeAll() {
  console.log('🚀 CPP-LUXURY RSS Scraper Starting...');
  console.log('=========================================');

  const allArticles = [];
  const seenUrls = new Set();
  let emptyPages = 0;
  let page = 1;

  // Process pages in batches
  while (emptyPages < 3) {
    const batch = [];
    for (let p = page; p < page + CONCURRENT; p++) {
      batch.push(p);
    }

    const results = await Promise.all(batch.map(p => fetchRSSPage(p)));
    let batchNew = 0;
    let batchEmpty = 0;

    for (let i = 0; i < results.length; i++) {
      const xml = results[i];
      if (!xml || !xml.includes('<item>')) {
        batchEmpty++;
        continue;
      }

      const items = parseXMLItems(xml);
      if (items.length === 0) {
        batchEmpty++;
        continue;
      }

      for (const item of items) {
        if (!seenUrls.has(item.url)) {
          seenUrls.add(item.url);
          allArticles.push(item);
          batchNew++;
        }
      }
    }

    console.log(`Pages ${batch[0]}-${batch[batch.length-1]}: +${batchNew} articles (total: ${allArticles.length})`);

    if (batchEmpty >= CONCURRENT) {
      emptyPages++;
      console.log(`⚠️ Empty batch (${emptyPages}/3)`);
    } else {
      emptyPages = 0;
    }

    // Save every 100 pages
    if (page % 100 === 0) {
      fs.writeFileSync(OUTPUT_FILE, JSON.stringify(allArticles, null, 2));
      console.log(`💾 Saved ${allArticles.length} articles`);
    }

    page += CONCURRENT;
    await sleep(DELAY_MS);
  }

  // Final save
  fs.writeFileSync(OUTPUT_FILE, JSON.stringify(allArticles, null, 2));
  console.log(`\n✅ SCRAPING COMPLETE!`);
  console.log(`📊 Total store opening articles: ${allArticles.length}`);
  console.log(`📁 Saved to: ${OUTPUT_FILE}`);

  // Summary
  const brandCounts = {};
  const cityCounts = {};
  for (const a of allArticles) {
    brandCounts[a.brand] = (brandCounts[a.brand] || 0) + 1;
    if (a.city) cityCounts[a.city] = (cityCounts[a.city] || 0) + 1;
  }

  console.log('\n🏆 Top 20 Brands:');
  Object.entries(brandCounts).sort((a, b) => b[1] - a[1]).slice(0, 20)
    .forEach(([b, c]) => console.log(`  ${b}: ${c}`));

  console.log('\n🌍 Top 20 Cities:');
  Object.entries(cityCounts).sort((a, b) => b[1] - a[1]).slice(0, 20)
    .forEach(([c, n]) => console.log(`  ${c}: ${n}`));
}

scrapeAll().catch(console.error);
