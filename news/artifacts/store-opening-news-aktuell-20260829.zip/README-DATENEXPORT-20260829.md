# Aktueller Store-Opening-Datenexport

Erstellt am 2026-08-29 aus dem abgeschlossenen Importbestand.

## Umfang

- 18.396 deduplizierte Exportdatensätze
- 18.088 Portal-News-Datensätze
- 346 Store-Archivdatensätze
- 6.108 Datensätze mit GPS-Koordinaten
- 1.011 Datensätze mit Foto-Referenz
- 757 Datensätze mit hausnummerngenauer Adressvalidierung
- 724 unterschiedliche Marke–Stadt–Strasse–Hausnummer-Kombinationen

## Spalten

Der Export enthält `record_id`, `record_types`, `source`, `brand`, `city`, `country`, `street_address`, `house_number`, `address_verified`, `square_meters`, `floors`, `opening_date`, `publication_date`, `title`, `description`, `url`, `latitude`, `longitude`, `photo_url`, `opening_hours`, `category`, `status` und `partners`.

## Datenqualität

`address_verified=Yes` bedeutet, dass die Adresse hausnummerngenau geprüft wurde. Nur diese Datensätze dürfen in der strassenpräzisen Momentum- und Grade-Berechnung verwendet werden. Leere GPS- oder Foto-Felder bedeuten, dass für den jeweiligen Datensatz keine belastbare Referenz vorliegt. Die eigentlichen Store-Fotodateien sind im separaten vollständigen Foto-Backup enthalten und werden nicht künstlich News-Datensätzen zugeordnet.

Die CSV ist für Datenverarbeitung geeignet; die XLSX-Datei enthält zusätzlich ein Tabellenblatt `Abdeckung`.

